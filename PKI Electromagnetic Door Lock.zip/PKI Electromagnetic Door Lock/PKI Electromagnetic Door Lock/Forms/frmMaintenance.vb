﻿Public Class frmMaintenance

    Sub New()
        InitializeComponent()
        Dim frm As New frmOption
        frm.TopLevel = False
        pnlBody.Controls.Add(frm)
        frm.Show()
    End Sub

    Private Sub picClose_MouseEnter(sender As Object, e As EventArgs) Handles picClose.MouseEnter
        picClose.BackColor = Color.White
    End Sub

    Private Sub picClose_MouseLeave(sender As Object, e As EventArgs) Handles picClose.MouseLeave
        picClose.BackColor = Color.Transparent
    End Sub

    Private Sub picClose_Click(sender As Object, e As EventArgs) Handles picClose.Click
        Application.Exit()
    End Sub
End Class