﻿Imports System.Runtime.InteropServices
Imports System.IO

Public Class frmAuthorizedPersonnel
    <DllImport("user32.dll", EntryPoint:="SendMessage")> _
    Private Shared Function SendMessage(hWnd As IntPtr, msg As Integer, wParam As Integer, <MarshalAs(UnmanagedType.LPWStr)> IParam As String) As Int32
    End Function
    Private Const EM_SETCUEBANNER As Integer = &H1501 'for TextBox
    Public Sub WaterMark(ByVal strMark As String, ByVal txtBox As System.Windows.Forms.TextBox)
        SendMessage(txtBox.Handle, EM_SETCUEBANNER, 1, strMark)
    End Sub


    Private Sub picBack_Click(sender As Object, e As EventArgs) Handles picBack.Click
        For Each f As Form In My.Application.OpenForms
            If Not f.InvokeRequired Then
                'Can access the form directly.
                'Get main form , use main form
                If f.Tag = "Main" Then
                    Dim fcast As New frmMaintenance '<< whatever your form name
                    fcast = f
                    fcast.pnlBody.Controls.Clear()
                    Dim frm As New frmOption
                    frm.TopLevel = False
                    fcast.pnlBody.Controls.Add(frm)
                    frm.Show()
                    Me.Close()
                    Exit For
                End If
            End If
        Next
    End Sub
#Region "NumberOnly"
    Private _validString As String = String.Empty
    Public Sub TextBoxValidation(ByVal textBox As System.Windows.Forms.TextBox, ByVal validString As String)
        _validString = validString
        AddHandler textBox.KeyPress, AddressOf TextValidation
    End Sub
    Private Sub TextValidation(sender As Object, e As KeyPressEventArgs)
        If e.KeyChar <> ControlChars.Back Then e.Handled = (_validString.IndexOf(e.KeyChar) = -1)
    End Sub
#End Region


    Private Sub frmAuthorizedPersonnel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBoxValidation(txtIDNumber, "1234567890")
        WaterMark("ID Number", txtIDNumber)
        'LoadAreaList()
        Reload()
    End Sub

    Private Sub txtIDNumber_TextChanged(sender As Object, e As EventArgs) Handles txtIDNumber.TextChanged
        If txtIDNumber.TextLength = 6 Then
            txtIDNumber.Focus() : txtIDNumber.SelectAll()
            Dim emp As New Employee
            emp.IDNumber = txtIDNumber.Text
            If emp.Search Then
                txtName.Text = emp.FullName.ToUpper
            Else
                MessageBox.Show("Record not found.", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtName.Clear()
            End If
            picImg.Image = GetImage(txtIDNumber.Text)
        ElseIf txtIDNumber.TextLength <= 1 Then
            txtName.Clear()
            picImg.Image = imgDefault.Images("default")
        End If
    End Sub

    Private Function GetImage(ByVal id_number As String) As Image
        Dim imgPath As String = My.Settings.PICTURES_LOCATION
        If File.Exists(Path.Combine(imgPath, id_number & ".jpg")) Then
            Dim img As Image = Image.FromFile(Path.Combine(imgPath, id_number & ".jpg"))
            Return img
        Else
            Dim img As Image = Image.FromFile(Path.Combine(imgPath, "unknown.jpg"))
            Return img
        End If
    End Function


    Private Function GetBiometric(ByVal id_number As String) As Byte()
        Dim biometPath As String = My.Settings.BIOMETIC_LOCATION
        If File.Exists(Path.Combine(biometPath, id_number & ".fpt")) Then
            Dim fs As IO.FileStream
            Dim br As IO.BinaryReader
            Dim data() As Byte
            fs = New IO.FileStream(Path.Combine(biometPath, id_number & ".fpt"), IO.FileMode.Open, IO.FileAccess.Read)
            br = New IO.BinaryReader(fs)
            data = br.ReadBytes(CType(fs.Length, Integer))
            br.Close()
            fs.Close()
            Return data
        End If
        Return Nothing
    End Function


    Private intAreaID As Integer = 0
    Private Sub cboArea_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboArea.SelectedIndexChanged
        If cboArea.Text.Trim <> String.Empty Then
            txtIDNumber.Enabled = True
            txtIDNumber.Focus()
            Dim rowArr() As DataRow = dtArea.Select(String.Format("description = '{0}'", cboArea.Text))
            If rowArr.Length = 1 Then
                Dim dtArea As DataTable = rowArr.CopyToDataTable
                intAreaID = dtArea.Rows(0).Item("id").ToString
            Else
                intAreaID = 0
            End If
        Else
            txtIDNumber.Enabled = False
            txtIDNumber.Clear()
        End If

        LoadAuthorizedPersonnelPerArea()
    End Sub


    Private Sub Reload()
        LoadAreaList()
        Dim auth As New AuthorizedPersonnel
        Dim dtTemp As DataTable = auth.View
        dgvAuthorizedPersonnel.Rows.Clear()
        For Each row As DataRow In dtTemp.Rows
            Dim data() As String = {row.Item("area_id").ToString, row.Item("id_number").ToString, row.Item("description").ToString, row.Item("name").ToString, Nothing}
            dgvAuthorizedPersonnel.Rows.Add(data)
        Next
        'clear
        txtIDNumber.Clear()
    End Sub

    Private Sub LoadAuthorizedPersonnelPerArea()
        Dim auth As New AuthorizedPersonnel
        Dim dtTemp As DataTable = auth.View(intAreaID)
        dgvAuthorizedPersonnel.Rows.Clear()
        For Each row As DataRow In dtTemp.Rows
            Dim data() As String = {row.Item("area_id").ToString, row.Item("id_number").ToString, row.Item("description").ToString, row.Item("name").ToString, Nothing}
            dgvAuthorizedPersonnel.Rows.Add(data)
        Next
        txtIDNumber.Clear()
    End Sub

    Dim dtArea As DataTable
    Private Sub LoadAreaList()
        Dim area As New Area
        dtArea = New DataTable
        dtArea = area.View
        cboArea.Items.Clear()
        For Each row As DataRow In dtArea.Rows
            cboArea.Items.Add(row.Item("description").ToString)
        Next
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If cboArea.Text.Trim = String.Empty Or txtIDNumber.Text.Trim = String.Empty Then
            MessageBox.Show("Area description and id number are required.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Dim auth As New AuthorizedPersonnel
            If auth.IsExist(txtIDNumber.Text, intAreaID) = False Then
                Dim emp As New Employee
                auth.ProfilePicture = emp.imgToByteArray(picImg.Image)
                auth.Biometric = GetBiometric(txtIDNumber.Text)
                If auth.Save(txtIDNumber.Text, intAreaID) Then
                    MessageBox.Show("Saved successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Reload()
                End If
            Else
                MessageBox.Show("Record is already exist.", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        Reload()
    End Sub

    Private Sub dgvAuthorizedPersonnel_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvAuthorizedPersonnel.CellClick
        If e.RowIndex >= 0 And e.ColumnIndex = dgvAuthorizedPersonnel.Columns("delete").Index Then
            Dim msg = MessageBox.Show("Are you sure you want to delete?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If msg = Windows.Forms.DialogResult.Yes Then
                Dim auth As New AuthorizedPersonnel
                Dim id_number As String = dgvAuthorizedPersonnel.Rows(e.RowIndex).Cells("id_number").Value.ToString
                Dim area_id As String = dgvAuthorizedPersonnel.Rows(e.RowIndex).Cells("area_id").Value.ToString
                If auth.Delete(id_number, area_id) Then
                    MessageBox.Show("Permanently deleted.", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Reload()
                End If
            End If
        End If
    End Sub
End Class