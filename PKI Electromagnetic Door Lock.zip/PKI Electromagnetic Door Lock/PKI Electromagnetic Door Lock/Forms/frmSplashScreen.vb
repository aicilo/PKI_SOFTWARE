﻿Public Class frmSplashScreen
    Private IsByPassed As Boolean = False
    Private Sub bgwLoad_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles bgwLoad.DoWork
        'Dim saveLocation = Application.StartupPath & "\Fingerprint"
        'If System.IO.Directory.Exists(saveLocation) Then
        '    System.IO.Directory.Delete(saveLocation)
        'End If
        System.Threading.Thread.Sleep(3000)
    End Sub

    Private Sub bgwLoad_RunWorkerCompleted(sender As Object, e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles bgwLoad.RunWorkerCompleted
        If bgwLoad.IsBusy = False Then
            Me.Hide()
            If IsByPassed = False Then
                Dim tms As New frmTMS
                'tms.WindowState = FormWindowState.Maximized
                tms.Show()
            Else
                Dim main As New frmMaintenance
                main.Show()
            End If

        End If

    End Sub

    Private Sub frmSplashScreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bgwLoad.RunWorkerAsync()
    End Sub

    Private Sub frmSplashScreen_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If (e.KeyCode = Keys.F8) Then
            IsByPassed = True
        End If
    End Sub

    Private Sub frmSplashScreen_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        IsByPassed = False
    End Sub
End Class