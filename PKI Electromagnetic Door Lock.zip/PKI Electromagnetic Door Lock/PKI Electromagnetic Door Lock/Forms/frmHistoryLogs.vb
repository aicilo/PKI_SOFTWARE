﻿Public Class frmHistoryLogs

    Private Sub picBack_Click(sender As Object, e As EventArgs) Handles picBack.Click
        For Each f As Form In My.Application.OpenForms
            If Not f.InvokeRequired Then
                'Can access the form directly.
                'Get main form , use main form
                If f.Tag = "Main" Then
                    Dim fcast As New frmMaintenance '<< whatever your form name
                    fcast = f
                    fcast.pnlBody.Controls.Clear()
                    Dim frm As New frmOption
                    frm.TopLevel = False
                    fcast.pnlBody.Controls.Add(frm)
                    frm.Show()
                    Me.Close()
                    Exit For
                End If
            End If
        Next
    End Sub


    Dim dtArea As DataTable
    Private Sub LoadAreaList()
        Dim area As New Area
        dtArea = New DataTable
        dtArea = area.View
        cboArea.Items.Clear()
        For Each row As DataRow In dtArea.Rows
            cboArea.Items.Add(row.Item("description").ToString)
        Next
    End Sub

    Private intAreaID As Integer
    Private Sub cboArea_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboArea.SelectedIndexChanged
        If cboArea.Text.Trim <> String.Empty Then
            Dim rowArr() As DataRow = dtArea.Select(String.Format("description = '{0}'", cboArea.Text))
            If rowArr.Length = 1 Then
                Dim dtArea As DataTable = rowArr.CopyToDataTable
                intAreaID = dtArea.Rows(0).Item("id").ToString
            Else
                intAreaID = 0
            End If
        Else
           intAreaID = 0
        End If
    End Sub

    Private Sub frmHistoryLogs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadAreaList()
    End Sub




    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim log As New Log
        Dim dtTemp As DataTable = log.SearchLogs(intAreaID, CDate(dtpFrom.Value), CDate(dtpTo.Value))
        dgvLogs.Rows.Clear()
        For Each row As DataRow In dtTemp.Rows
            Dim data() As String = {row.Item("name").ToString, row.Item("time_in").ToString, row.Item("time_out").ToString}
            dgvLogs.Rows.Add(data)
        Next

        'For Each row As DataGridViewRow In dgvLogs.Rows
        '    If row.Cells("TimeOut").Value = "NO TIME OUT" Then
        '        row.Cells("TimeOut").Style.ForeColor = Color.Firebrick
        '        row.Cells("TimeOut").Style.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold)
        '        row.Cells("TimeIn").Style.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold)
        '        row.Cells("Employee").Style.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold)
        '    Else
        '        row.Cells("Employee").Style.ForeColor = Color.Gray
        '        row.Cells("TimeIn").Style.ForeColor = Color.Gray
        '        row.Cells("TimeOut").Style.ForeColor = Color.Gray
        '    End If
        'Next

        dgvLogs.ClearSelection()
    End Sub
End Class