﻿Public Class frmArea

    Private Sub picBack_Click(sender As Object, e As EventArgs) Handles picBack.Click
        For Each f As Form In My.Application.OpenForms
            If Not f.InvokeRequired Then
                'Can access the form directly.
                'Get main form , use main form
                If f.Tag = "Main" Then
                    Dim fcast As New frmMaintenance '<< whatever your form name
                    fcast = f
                    fcast.pnlBody.Controls.Clear()
                    Dim frm As New frmOption
                    frm.TopLevel = False
                    fcast.pnlBody.Controls.Add(frm)
                    frm.Show()
                    Me.Close()
                    Exit For
                End If
            End If
        Next
    End Sub

    Private Sub txtComputerName_Enter(sender As Object, e As EventArgs) Handles txtComputerName.Enter

        If txtAreaDescription.Text.Trim <> String.Empty Then
            If txtComputerName.Text.Trim = String.Empty Then
                txtComputerName.Text = My.Computer.Name.ToUpper
            Else
                txtComputerName.Focus() : txtComputerName.SelectAll()
            End If
        End If

    End Sub


    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtAreaDescription.Text.Trim = String.Empty Or txtComputerName.Text.Trim = String.Empty Then
            MessageBox.Show("Area description and computer name are required.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Dim area As New Area
            area.Description = txtAreaDescription.Text.Trim
            area.ComputerName = txtComputerName.Text.Trim
            If area.IsExist = False Then
                area.Save()
                MessageBox.Show("Saved successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reload()
            Else
                MessageBox.Show("Area description or assigned computer is already exist.", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub Reload()
        Dim area As New Area
        Dim dtTemp As DataTable = area.View
        dgvArea.Rows.Clear()
        For Each row As DataRow In dtTemp.Rows 'description,computer_name
            Dim data() As String = {row.Item("description").ToString, row.Item("computer_name").ToString}
            dgvArea.Rows.Add(data)
        Next
    End Sub

    Private Sub frmArea_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
    End Sub
End Class