﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAuthorizedPersonnel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAuthorizedPersonnel))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.picBack = New System.Windows.Forms.PictureBox()
        Me.dgvAuthorizedPersonnel = New System.Windows.Forms.DataGridView()
        Me.area_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.id_number = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.area_description = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Employee = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.delete = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.picImg = New System.Windows.Forms.PictureBox()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboArea = New System.Windows.Forms.ComboBox()
        Me.txtIDNumber = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.imgDefault = New System.Windows.Forms.ImageList(Me.components)
        CType(Me.picBack, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvAuthorizedPersonnel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.picImg, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picBack
        '
        Me.picBack.Image = CType(resources.GetObject("picBack.Image"), System.Drawing.Image)
        Me.picBack.Location = New System.Drawing.Point(1, 1)
        Me.picBack.Name = "picBack"
        Me.picBack.Size = New System.Drawing.Size(60, 60)
        Me.picBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBack.TabIndex = 5
        Me.picBack.TabStop = False
        '
        'dgvAuthorizedPersonnel
        '
        Me.dgvAuthorizedPersonnel.AllowUserToAddRows = False
        Me.dgvAuthorizedPersonnel.AllowUserToDeleteRows = False
        Me.dgvAuthorizedPersonnel.AllowUserToResizeColumns = False
        Me.dgvAuthorizedPersonnel.AllowUserToResizeRows = False
        Me.dgvAuthorizedPersonnel.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gold
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvAuthorizedPersonnel.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvAuthorizedPersonnel.ColumnHeadersHeight = 30
        Me.dgvAuthorizedPersonnel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvAuthorizedPersonnel.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.area_id, Me.id_number, Me.area_description, Me.Employee, Me.delete})
        Me.dgvAuthorizedPersonnel.EnableHeadersVisualStyles = False
        Me.dgvAuthorizedPersonnel.GridColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.dgvAuthorizedPersonnel.Location = New System.Drawing.Point(29, 255)
        Me.dgvAuthorizedPersonnel.Name = "dgvAuthorizedPersonnel"
        Me.dgvAuthorizedPersonnel.ReadOnly = True
        Me.dgvAuthorizedPersonnel.RowHeadersVisible = False
        Me.dgvAuthorizedPersonnel.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvAuthorizedPersonnel.Size = New System.Drawing.Size(956, 328)
        Me.dgvAuthorizedPersonnel.TabIndex = 6
        '
        'area_id
        '
        Me.area_id.HeaderText = "AREA ID"
        Me.area_id.Name = "area_id"
        Me.area_id.ReadOnly = True
        Me.area_id.Visible = False
        '
        'id_number
        '
        Me.id_number.HeaderText = "ID NUMBER"
        Me.id_number.Name = "id_number"
        Me.id_number.ReadOnly = True
        Me.id_number.Visible = False
        '
        'area_description
        '
        Me.area_description.HeaderText = "AREA"
        Me.area_description.Name = "area_description"
        Me.area_description.ReadOnly = True
        Me.area_description.Width = 500
        '
        'Employee
        '
        Me.Employee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Employee.HeaderText = "AUTHORIZED PERSONNEL"
        Me.Employee.Name = "Employee"
        Me.Employee.ReadOnly = True
        '
        'delete
        '
        Me.delete.HeaderText = "REMOVE"
        Me.delete.Name = "delete"
        Me.delete.ReadOnly = True
        Me.delete.Width = 60
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.picImg)
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Controls.Add(Me.txtName)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.cboArea)
        Me.Panel1.Controls.Add(Me.txtIDNumber)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(29, 87)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(956, 162)
        Me.Panel1.TabIndex = 7
        '
        'picImg
        '
        Me.picImg.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picImg.Image = CType(resources.GetObject("picImg.Image"), System.Drawing.Image)
        Me.picImg.Location = New System.Drawing.Point(3, 3)
        Me.picImg.Name = "picImg"
        Me.picImg.Size = New System.Drawing.Size(120, 120)
        Me.picImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picImg.TabIndex = 8
        Me.picImg.TabStop = False
        '
        'btnRefresh
        '
        Me.btnRefresh.BackColor = System.Drawing.Color.ForestGreen
        Me.btnRefresh.FlatAppearance.BorderSize = 0
        Me.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefresh.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRefresh.ForeColor = System.Drawing.Color.White
        Me.btnRefresh.Location = New System.Drawing.Point(728, 103)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(108, 40)
        Me.btnRefresh.TabIndex = 8
        Me.btnRefresh.Text = "REFRESH"
        Me.btnRefresh.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnSave.FlatAppearance.BorderSize = 0
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.Location = New System.Drawing.Point(842, 103)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(90, 40)
        Me.btnSave.TabIndex = 7
        Me.btnSave.Text = "SAVE"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(246, 71)
        Me.txtName.Name = "txtName"
        Me.txtName.ReadOnly = True
        Me.txtName.Size = New System.Drawing.Size(686, 26)
        Me.txtName.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Rockwell", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(243, 100)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 14)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Full Name"
        '
        'cboArea
        '
        Me.cboArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboArea.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboArea.FormattingEnabled = True
        Me.cboArea.Location = New System.Drawing.Point(131, 38)
        Me.cboArea.Name = "cboArea"
        Me.cboArea.Size = New System.Drawing.Size(801, 27)
        Me.cboArea.TabIndex = 4
        '
        'txtIDNumber
        '
        Me.txtIDNumber.Enabled = False
        Me.txtIDNumber.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIDNumber.Location = New System.Drawing.Point(131, 71)
        Me.txtIDNumber.MaxLength = 6
        Me.txtIDNumber.Name = "txtIDNumber"
        Me.txtIDNumber.Size = New System.Drawing.Size(109, 26)
        Me.txtIDNumber.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(128, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 14)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "ID Number"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(128, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(140, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "AREA DESCRIPTION"
        '
        'imgDefault
        '
        Me.imgDefault.ImageStream = CType(resources.GetObject("imgDefault.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgDefault.TransparentColor = System.Drawing.Color.Transparent
        Me.imgDefault.Images.SetKeyName(0, "default")
        '
        'frmAuthorizedPersonnel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1017, 617)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.dgvAuthorizedPersonnel)
        Me.Controls.Add(Me.picBack)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmAuthorizedPersonnel"
        Me.Text = "frmArea"
        CType(Me.picBack, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvAuthorizedPersonnel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.picImg, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picBack As System.Windows.Forms.PictureBox
    Friend WithEvents dgvAuthorizedPersonnel As System.Windows.Forms.DataGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtIDNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cboArea As System.Windows.Forms.ComboBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents area_id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents id_number As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents area_description As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Employee As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents delete As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents picImg As System.Windows.Forms.PictureBox
    Friend WithEvents imgDefault As System.Windows.Forms.ImageList
End Class
