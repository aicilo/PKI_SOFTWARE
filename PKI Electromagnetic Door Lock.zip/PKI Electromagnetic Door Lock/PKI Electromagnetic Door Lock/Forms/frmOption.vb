﻿Public Class frmOption

    Private Sub picArea_Click(sender As Object, e As EventArgs) Handles picArea.Click
        For Each f As Form In My.Application.OpenForms
            If Not f.InvokeRequired Then
                'Can access the form directly.
                'Get main form , use main form
                If f.Tag = "Main" Then
                    Dim fcast As New frmMaintenance
                    fcast.pnlBody.Controls.Clear()
                    fcast = f
                    Dim frm As New frmArea
                    frm.TopLevel = False
                    fcast.pnlBody.Controls.Add(frm)
                    frm.Show()
                    Me.Close()
                    Exit For
                End If

            End If
        Next
    End Sub

    Private Sub picAuthorizedPersonnel_Click(sender As Object, e As EventArgs) Handles picAuthorizedPersonnel.Click
        For Each f As Form In My.Application.OpenForms
            If Not f.InvokeRequired Then
                If f.Tag = "Main" Then
                    Dim fcast As New frmMaintenance
                    fcast.pnlBody.Controls.Clear()
                    fcast = f
                    Dim frm As New frmAuthorizedPersonnel
                    frm.TopLevel = False
                    fcast.pnlBody.Controls.Add(frm)
                    frm.Show()
                    Me.Close()
                    Exit For
                End If

            End If
        Next
    End Sub

    Private Sub picFingerPrint_Click(sender As Object, e As EventArgs) Handles picFingerPrint.Click
        For Each f As Form In My.Application.OpenForms
            If Not f.InvokeRequired Then
                If f.Tag = "Main" Then
                    Dim fcast As New frmMaintenance
                    fcast.pnlBody.Controls.Clear()
                    fcast = f
                    Dim frm As New frmEnrollFingerprint
                    frm.TopLevel = False
                    fcast.pnlBody.Controls.Add(frm)
                    frm.Show()
                    Me.Close()
                    Exit For
                End If

            End If
        Next
    End Sub

    Private Sub picHistoryLogs_Click(sender As Object, e As EventArgs) Handles picHistoryLogs.Click
        For Each f As Form In My.Application.OpenForms
            If Not f.InvokeRequired Then
                If f.Tag = "Main" Then
                    Dim fcast As New frmMaintenance
                    fcast.pnlBody.Controls.Clear()
                    fcast = f
                    Dim frm As New frmHistoryLogs
                    frm.TopLevel = False
                    fcast.pnlBody.Controls.Add(frm)
                    frm.Show()
                    Me.Close()
                    Exit For
                End If

            End If
        Next
    End Sub
End Class