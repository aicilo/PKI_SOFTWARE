﻿Imports System.Runtime.InteropServices
Imports System.IO

Public Class frmTMS

    Implements DPFP.Capture.EventHandler
    Private Delegate Sub FunctionCall(ByVal param)

    Private Capturer As DPFP.Capture.Capture
    Private Template As DPFP.Template
    Private Verificator As DPFP.Verification.Verification

    Protected Sub UpdateStatus(ByVal FAR As Integer)
        ' Show "False accept rate" value
        SetStatus(String.Format("False Accept Rate (FAR) = {0}", FAR))
    End Sub
    Protected Sub SetStatus(ByVal status)
        Invoke(New FunctionCall(AddressOf _SetStatus), status)
    End Sub
    Private Sub _SetStatus(ByVal status)
        ' lblStatus.Text = status
    End Sub

    Private Sub Process(ByVal Sample As DPFP.Sample)
        DrawPicture(ConvertSampleToBitmap(Sample))
        ' Process the sample and create a feature set for the enrollment purpose.
        Dim features As DPFP.FeatureSet = ExtractFeatures(Sample, DPFP.Processing.DataPurpose.Verification)

        ' Check quality of the sample and start verification if it's good
        If Not features Is Nothing Then
            ' Compare the feature set with our template
            Dim result As DPFP.Verification.Verification.Result = New DPFP.Verification.Verification.Result()

            'finger print initialize
            For Each row As DataRow In dtAuthorizedList.Rows
                If Not row.Item("biometric") Is DBNull.Value Then
                    Dim stream As New MemoryStream(DirectCast(row.Item("biometric"), Byte()))
                    Dim template As New DPFP.Template(stream)
                    OnTemplate(template)
                    Verificator.Verify(features, template, result)
                    UpdateStatus(result.FARAchieved)
                    If result.Verified Then
                        MakeReport("The fingerprint was VERIFIED.")
                        isSuccess(row.Item("id_number").ToString)
                        Exit For
                    Else
                        MakeReport("The fingerprint was NOT VERIFIED.")
                    End If

                End If

            Next

           


        End If
    End Sub

    Private Sub MakeReport(ByVal status As String)
        Invoke(New FunctionCall(AddressOf _MakeReport), status)
    End Sub

    Private Sub _MakeReport(ByVal status As String)
        lblMessage.Text = status
    End Sub

    Private Function ExtractFeatures(ByVal Sample As DPFP.Sample, ByVal Purpose As DPFP.Processing.DataPurpose) As DPFP.FeatureSet
        Try
            Dim extractor As New DPFP.Processing.FeatureExtraction()        ' Create a feature extractor
            Dim feedback As DPFP.Capture.CaptureFeedback = DPFP.Capture.CaptureFeedback.None
            Dim features As New DPFP.FeatureSet()
            extractor.CreateFeatureSet(Sample, Purpose, feedback, features) ' TODO: return features as a result?
            If (feedback = DPFP.Capture.CaptureFeedback.Good) Then
                Return features
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Private Sub DrawPicture(ByVal bmp) 'PictureBox
        'Picture.Image = New Bitmap(bmp, Picture.Size)
    End Sub
    Private Function ConvertSampleToBitmap(ByVal Sample As DPFP.Sample) As Bitmap
        Dim convertor As New DPFP.Capture.SampleConversion()    ' Create a sample convertor.
        Dim bitmap As Bitmap = Nothing                          ' TODO: the size doesn't matter
        convertor.ConvertToPicture(Sample, bitmap)              ' TODO: return bitmap as a result
        Return bitmap
    End Function




    Private Sub StartCapture()
        If (Not Capturer Is Nothing) Then
            Try
                Capturer.StartCapture()
                SetPrompt("Using the fingerprint reader, scan your fingerprint.")
            Catch ex As Exception
                SetPrompt("Can't initiate capture!")
            End Try
        End If
    End Sub

    Private Sub StopCapture()
        If (Not Capturer Is Nothing) Then
            Try
                Capturer.StopCapture()
            Catch ex As Exception
                SetPrompt("Can't initiate capture!")
            End Try
        End If
    End Sub
    Private Sub OnTemplate(ByVal template)
        Invoke(New FunctionCall(AddressOf _OnTemplate), template)
    End Sub
    Private Sub _OnTemplate(ByVal template)
        Me.Template = template
    End Sub
    Private Sub SetPrompt(ByVal text As String)
        Invoke(New FunctionCall(AddressOf _SetPrompt), text)
    End Sub
    Private Sub _SetPrompt(ByVal text As String)
        lblInstruction.Text = text
    End Sub

    Private Sub isSuccess(ByVal id_number As String)
        Invoke(New FunctionCall(AddressOf _isSuccess), id_number)
    End Sub

    Private Sub _isSuccess(ByVal id_number As String)
        If id_number.Length = 6 Then
            Dim log As New Log
            Dim name As String = log.Search(AreaID, id_number)
            If name = String.Empty Then
                lblName.Text = String.Format("[{0}]", "RECORD NOT FOUND")
                lblName.ForeColor = Color.Firebrick
                picImg.Image = imgDefault.Images("default")
            Else
                lblName.Text = name.Trim.ToUpper
                Dim rowImg() As DataRow = dtAuthorizedList.Select(String.Format("id_number = '{0}'", id_number))
                If rowImg.Length = 1 Then
                    Dim dtTemp As DataTable = rowImg.CopyToDataTable
                    If Not dtTemp.Rows(0).Item("picture") Is DBNull.Value Then
                        Dim emp As New Employee
                        picImg.Image = emp.byteArrayToImage(dtTemp.Rows(0).Item("picture"))
                    Else
                        picImg.Image = imgDefault.Images("default")
                    End If
                Else
                    picImg.Image = imgDefault.Images("default")
                End If

                If log.IsTimeIN Then
                    lblName.Text &= vbNewLine & "[TIME OUT]"
                Else
                    lblName.Text &= vbNewLine & "[TIME IN]"
                End If
                lblName.ForeColor = Color.ForestGreen
                Dim error_msg As String = String.Empty
                Controller.Unlock(error_msg)
                If error_msg <> String.Empty Then
                    MakeReport(error_msg)
                End If
            End If
            Logs()
        Else
            picImg.Image = imgDefault.Images("default")
        End If
    End Sub


    Private Sub OnComplete(ByVal Capture As Object, ByVal ReaderSerialNumber As String, ByVal Sample As DPFP.Sample) Implements DPFP.Capture.EventHandler.OnComplete
        MakeReport("The fingerprint sample was captured.")
        Process(Sample)
    End Sub

    Private Sub OnFingerGone(ByVal Capture As Object, ByVal ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnFingerGone
        MakeReport("The finger was removed from the fingerprint reader.")
    End Sub

    Private Sub OnFingerTouch(ByVal Capture As Object, ByVal ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnFingerTouch
        MakeReport("The fingerprint reader was touched.")
    End Sub

    Private Sub OnReaderConnect(ByVal Capture As Object, ByVal ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnReaderConnect
        MakeReport("The fingerprint reader was connected.")
    End Sub

    Private Sub OnReaderDisconnect(ByVal Capture As Object, ByVal ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnReaderDisconnect
        MakeReport("The fingerprint reader was disconnected.")
    End Sub

    Private Sub OnSampleQuality(ByVal Capture As Object, ByVal ReaderSerialNumber As String, ByVal CaptureFeedback As DPFP.Capture.CaptureFeedback) Implements DPFP.Capture.EventHandler.OnSampleQuality
        If CaptureFeedback = DPFP.Capture.CaptureFeedback.Good Then
            MakeReport("The quality of the fingerprint sample is good.")
        Else
            MakeReport("The quality of the fingerprint sample is poor.")
        End If
    End Sub



    <DllImport("user32.dll", EntryPoint:="SendMessage")> _
    Private Shared Function SendMessage(hWnd As IntPtr, msg As Integer, wParam As Integer, <MarshalAs(UnmanagedType.LPWStr)> IParam As String) As Int32
    End Function
    Private Const EM_SETCUEBANNER As Integer = &H1501 'for TextBox
    Public Sub WaterMark(ByVal strMark As String, ByVal txtBox As System.Windows.Forms.TextBox)
        SendMessage(txtBox.Handle, EM_SETCUEBANNER, 1, strMark)
    End Sub



    Sub New()
        InitializeComponent()
        SetUp()
    End Sub

    Private t_Clock As Timer
    Private t_Refresh As Integer = 0

    Private Sub SetUp()
        t_Clock = New Timer
        t_Clock.Interval = 1000
        AddHandler t_Clock.Tick, AddressOf DateTimeSetup
        t_Clock.Start()
        TextBoxValidation(txtIDNumber, "1234567890")
        WaterMark("ID Number", txtIDNumber)
    End Sub

    Private Sub DateTimeSetup(sender As Object, e As EventArgs)
        lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt")
        lblDate.Text = DateTime.Now.ToString("[dddd] MMMM dd, yyyy")
        txtIDNumber.Focus()
        txtIDNumber.SelectAll()
        t_Refresh += 1

        If t_Refresh = 10 Then
            Logs()
            t_Refresh = 0
        End If
    End Sub



    Private Sub frmTMS_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F4 Then
            LogOut()
        End If
    End Sub

    Private t_Timer As Timer
    Private intCountdown As Integer = 0
    Private Sub LogOut()
        t_Timer = New Timer
        t_Timer.Interval = 500
        intCountdown = 6
        AddHandler t_Timer.Tick, AddressOf Shutdown
        t_Timer.Start()
    End Sub

    Private Sub Shutdown(sender As Object, e As EventArgs)
        System.Threading.Thread.Sleep(800)
        intCountdown -= 1

        lblMessage.Text = String.Format("SHUTTING DOWN IN {0}", intCountdown)
        If intCountdown = 0 Then
            t_Timer.Stop()
            RemoveHandler t_Timer.Tick, AddressOf Shutdown
            Application.Exit()
        End If

    End Sub

    Private Sub picClose_Click(sender As Object, e As EventArgs) Handles picClose.Click
        LogOut()
    End Sub



    Private Sub picClose_MouseEnter(sender As Object, e As EventArgs) Handles picClose.MouseEnter
        picClose.BackColor = Color.White
    End Sub

    Private Sub picClose_MouseLeave(sender As Object, e As EventArgs) Handles picClose.MouseLeave
        picClose.BackColor = Color.Transparent
    End Sub

#Region "NumberOnly"
    Private _validString As String = String.Empty
    Public Sub TextBoxValidation(ByVal textBox As System.Windows.Forms.TextBox, ByVal validString As String)
        _validString = validString
        AddHandler textBox.KeyPress, AddressOf TextValidation
    End Sub
    Private Sub TextValidation(sender As Object, e As KeyPressEventArgs)
        If e.KeyChar <> ControlChars.Back Then e.Handled = (_validString.IndexOf(e.KeyChar) = -1)
    End Sub
#End Region


    Private Sub txtIDNumber_KeyDown(sender As Object, e As KeyEventArgs) Handles txtIDNumber.KeyDown
        If e.KeyCode = Keys.Enter Then
            lblMessage.Text = String.Empty
            If txtIDNumber.TextLength = 6 Then
                Dim log As New Log
                Dim name As String = log.Search(AreaID, txtIDNumber.Text)
                If name = String.Empty Then
                    lblName.Text = String.Format("[{0}]", "RECORD NOT FOUND")
                    lblName.ForeColor = Color.Firebrick
                    picImg.Image = imgDefault.Images("default")
                Else
                    lblName.Text = name.Trim.ToUpper

                    Dim rowImg() As DataRow = dtAuthorizedList.Select(String.Format("id_number = '{0}'", txtIDNumber.Text))
                    If rowImg.Length = 1 Then
                        Dim dtTemp As DataTable = rowImg.CopyToDataTable
                        If Not dtTemp.Rows(0).Item("picture") Is DBNull.Value Then
                            Dim emp As New Employee
                            picImg.Image = emp.byteArrayToImage(dtTemp.Rows(0).Item("picture"))
                        Else
                            picImg.Image = imgDefault.Images("default")
                        End If
                    Else
                        picImg.Image = imgDefault.Images("default")
                    End If

                    If log.IsTimeIN Then
                        lblName.Text &= vbNewLine & "[TIME OUT]"
                    Else
                        lblName.Text &= vbNewLine & "[TIME IN]"
                    End If
                    lblName.ForeColor = Color.ForestGreen
                    Dim error_msg As String = String.Empty
                    Controller.Unlock(error_msg)
                    If error_msg <> String.Empty Then
                        MakeReport(error_msg)
                    End If
                End If
                Logs()
            ElseIf txtIDNumber.TextLength <= 1 Then
                txtIDNumber.Focus() : txtIDNumber.SelectAll()
            End If
        End If
    End Sub

    Private AreaID As Integer

    Private Sub frmTMS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
      
        Dim area As New Area
        Dim name As String = area.AreaName(My.Computer.Name.ToUpper.Trim)
        If name = String.Empty Then
            MessageBox.Show("Computer is not yet registered.", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Application.Exit()
        Else
            lblAreaName.Text = name.ToUpper.Trim
            AreaID = area.ID
        End If
        LoadAuthorizePersonnel()
        Logs()

        Try
            Capturer = New DPFP.Capture.Capture()                   ' Create a capture operation.
            Verificator = New DPFP.Verification.Verification()
            If (Not Capturer Is Nothing) Then
                Capturer.EventHandler = Me
                StartCapture() 'Subscribe for capturing events.' Subscribe for capturing events.
                SetPrompt("SCAN ID OR FINGERPRINT TO UNLOCK")
            Else
                SetPrompt("Can't initiate capture operation!")
            End If
        Catch ex As Exception
            MessageBox.Show("Can't initiate capture operation!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Dispose()
        End Try


    End Sub

    Private dtAuthorizedList As DataTable
    Private Sub LoadAuthorizePersonnel()
        Dim auth As New AuthorizedPersonnel
        dtAuthorizedList = New DataTable
        dtAuthorizedList = auth.View(AreaID)
        dgvAuthorizedPersonnel.Rows.Clear()
        For Each row As DataRow In dtAuthorizedList.Rows
            Dim data() As String = {row.Item("name").ToString, row.Item("position").ToString}
            dgvAuthorizedPersonnel.Rows.Add(data)
        Next
        dgvAuthorizedPersonnel.ClearSelection()
    End Sub


    Private Sub Logs()
        Dim log As New Log
        Dim dtTemp As DataTable = log.NoTimeOut(AreaID)
        dgvLogs.Rows.Clear()
        For Each row As DataRow In dtTemp.Rows
            Dim data() As String = {row.Item("name").ToString, row.Item("in").ToString, row.Item("out").ToString}
            dgvLogs.Rows.Add(data)
        Next

        For Each row As DataGridViewRow In dgvLogs.Rows
            If row.Cells("TimeOut").Value = "NO TIME OUT" Then
                row.Cells("TimeOut").Style.ForeColor = Color.Firebrick
                row.Cells("TimeOut").Style.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold)
                row.Cells("TimeIn").Style.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold)
                row.Cells("Employee").Style.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold)
            Else
                row.Cells("Employee").Style.ForeColor = Color.Gray
                row.Cells("TimeIn").Style.ForeColor = Color.Gray
                row.Cells("TimeOut").Style.ForeColor = Color.Gray
            End If
        Next

        dgvLogs.ClearSelection()
    End Sub

 

End Class