﻿Imports System.IO

Public Class frmEnrollFingerprint

    Implements DPFP.Capture.EventHandler
    Private Delegate Sub FunctionCall(ByVal param)
    Private Capturer As DPFP.Capture.Capture
    Private Enroller As DPFP.Processing.Enrollment

    Private Sub Process(ByVal Sample As DPFP.Sample)
        DrawPicture(ConvertSampleToBitmap(Sample))
        ' Process the sample and create a feature set for the enrollment purpose.
        Dim features As DPFP.FeatureSet = ExtractFeatures(Sample, DPFP.Processing.DataPurpose.Enrollment)

        ' Check quality of the sample and add to enroller if it's good
        If (Not features Is Nothing) Then
            Try
                Try
                    MakeReport("The fingerprint feature set was created.")
                    Enroller.AddFeatures(features)              ' Add feature set to template.
                Catch ex As Exception
                    StopCapture()

                    Enroller.Clear()

                    StartCapture()
                End Try
            Finally
                UpdateStatus()
                ' Check if template has been created.
                Select Case Enroller.TemplateStatus
                    Case DPFP.Processing.Enrollment.Status.Ready        ' Report success and stop capturing
                        SetPrompt("Fingerprint registered successfully.")
                        Using fs As IO.FileStream = IO.File.Open(saveLocation & "\" & ftpName & ".fpt", IO.FileMode.Create, IO.FileAccess.Write)
                            Enroller.Template.Serialize(fs)
                            isSuccess(True)
                        End Using
                        Save(saveLocation & "\" & ftpName & ".fpt")
                        StopCapture()
                    Case DPFP.Processing.Enrollment.Status.Failed       ' Report failure and restart capturing
                        StopCapture()
                        Enroller.Clear()
                        StartCapture()
                End Select
            End Try
        Else

        End If
    End Sub

    Protected Sub UpdateStatus()
        ' Show number of samples needed.
        SetStatus(String.Format("Fingerprint samples needed: {0}", Enroller.FeaturesNeeded))
    End Sub

    Protected Sub SetStatus(ByVal status As String)
        Invoke(New FunctionCall(AddressOf _SetStatus), status)
    End Sub

    Private Sub _SetStatus(ByVal status As String)
        lblStatus.Text = status
    End Sub

    Private Function ConvertSampleToBitmap(ByVal Sample As DPFP.Sample) As Bitmap
        Dim convertor As New DPFP.Capture.SampleConversion()    ' Create a sample convertor.
        Dim bitmap As Bitmap = Nothing                          ' TODO: the size doesn't matter
        convertor.ConvertToPicture(Sample, bitmap)              ' TODO: return bitmap as a result
        Return bitmap
    End Function

    Private Function ExtractFeatures(ByVal Sample As DPFP.Sample, ByVal Purpose As DPFP.Processing.DataPurpose) As DPFP.FeatureSet
        Try
            Dim extractor As New DPFP.Processing.FeatureExtraction()        ' Create a feature extractor
            Dim feedback As DPFP.Capture.CaptureFeedback = DPFP.Capture.CaptureFeedback.None
            Dim features As New DPFP.FeatureSet()
            extractor.CreateFeatureSet(Sample, Purpose, feedback, features) ' TODO: return features as a result?
            If (feedback = DPFP.Capture.CaptureFeedback.Good) Then
                Return features
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Private Sub StartCapture()
        If (Not Capturer Is Nothing) Then
            Try
                Capturer.StartCapture()
                SetPrompt("Using the fingerprint reader, scan your fingerprint.")
            Catch ex As Exception
                SetPrompt("Can't initiate capture!")
            End Try
        End If
    End Sub

    Private Sub StopCapture()
        If (Not Capturer Is Nothing) Then
            Try
                Capturer.StopCapture()
            Catch ex As Exception
                SetPrompt("Can't initiate capture!")
            End Try
        End If
    End Sub

    Private Sub DrawPicture(ByVal bmp) 'PictureBox
        'Picture.Image = New Bitmap(bmp, Picture.Size)
    End Sub

    Public Sub OnComplete(Capture As Object, ReaderSerialNumber As String, Sample As DPFP.Sample) Implements DPFP.Capture.EventHandler.OnComplete
        MakeReport("The fingerprint sample was captured.")
        SetPrompt("Scan the same fingerprint again.")
        Process(Sample)
    End Sub
    Private Sub isSuccess(ByVal success As Boolean)
        Invoke(New FunctionCall(AddressOf _isSuccess), success)
    End Sub

    Private Sub _isSuccess(ByVal success As Boolean)
        If success = True Then
            picSuccess.Visible = True
        Else
            picSuccess.Visible = False
        End If
    End Sub



    Private Sub Save(ByVal biometLocation As String)
        Invoke(New FunctionCall(AddressOf _save), biometLocation)
    End Sub

    Private Sub _save(ByVal biometLocation As String)
        If File.Exists(biometLocation) Then
            Dim fs As IO.FileStream
            Dim br As IO.BinaryReader
            Dim data() As Byte
            fs = New IO.FileStream(biometLocation, IO.FileMode.Open, IO.FileAccess.Read)
            br = New IO.BinaryReader(fs)
            data = br.ReadBytes(CType(fs.Length, Integer))
            br.Close()
            fs.Close()
            Dim auth As New AuthorizedPersonnel
            auth.Biometric = data
            If txtIDNumber.TextLength = 6 Then
                If auth.UpdateBiometric(txtIDNumber.Text) Then
                    txtIDNumber.Clear() : txtIDNumber.Enabled = True
                    btnEnrollFingerprint.Text = "ENROLL FINGERPRINT"
                    btnEnrollFingerprint.BackColor = Color.ForestGreen
                End If
            Else
                pnlInitialView.Visible = True
            End If
            

        End If
    End Sub


    Private Sub SetPrompt(ByVal text As String)
        Invoke(New FunctionCall(AddressOf _SetPrompt), text)
    End Sub
    Private Sub _SetPrompt(ByVal text As String)
        lblPrompt.Text = text
    End Sub

    Protected Sub MakeReport(ByVal status As String)
        ' Invoke(New FunctionCall(AddressOf _MakeReport), status)
        Invoke(New FunctionCall(AddressOf _MakeReport), status)
    End Sub

    Private Sub _MakeReport(ByVal status As String)
        lblReport.Text = status
    End Sub


    Public Sub OnFingerGone(Capture As Object, ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnFingerGone
        MakeReport("The fingerprint reader was touched.")
    End Sub

    Public Sub OnFingerTouch(Capture As Object, ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnFingerTouch
        MakeReport("The fingerprint reader was touched.")
    End Sub

    Public Sub OnReaderConnect(Capture As Object, ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnReaderConnect
        MakeReport("The fingerprint reader was connected.")
    End Sub

    Public Sub OnReaderDisconnect(Capture As Object, ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnReaderDisconnect
        MakeReport("The fingerprint reader was disconnected.")
    End Sub

    Public Sub OnSampleQuality(Capture As Object, ReaderSerialNumber As String, CaptureFeedback As DPFP.Capture.CaptureFeedback) Implements DPFP.Capture.EventHandler.OnSampleQuality
        If CaptureFeedback = DPFP.Capture.CaptureFeedback.Good Then
            MakeReport("The quality of the fingerprint sample is good.")
        Else
            MakeReport("The quality of the fingerprint sample is poor.")
        End If
    End Sub
    Private ftpName As String = String.Empty
    Private saveLocation As String = String.Empty

    Private Sub picBack_Click(sender As Object, e As EventArgs) Handles picBack.Click


        For Each f As Form In My.Application.OpenForms
            If Not f.InvokeRequired Then
                'Can access the form directly.
                'Get main form , use main form
                If f.Tag = "Main" Then
                    Dim fcast As New frmMaintenance '<< whatever your form name
                    fcast = f
                    fcast.pnlBody.Controls.Clear()
                    Dim frm As New frmOption
                    frm.TopLevel = False
                    fcast.pnlBody.Controls.Add(frm)
                    frm.Show()
                    Me.Close()
                    Exit For
                End If
            End If
        Next
    End Sub

    Private Sub txtIDNumber_TextChanged(sender As Object, e As EventArgs) Handles txtIDNumber.TextChanged
        If txtIDNumber.TextLength = 6 Then
            txtIDNumber.Focus() : txtIDNumber.SelectAll()
            Dim auth As New AuthorizedPersonnel
            Dim dtTemp As DataTable = auth.Search(txtIDNumber.Text)
            If dtTemp.Rows.Count = 1 Then
                txtName.Text = dtTemp.Rows(0).Item("name").ToString
                txtPosition.Text = dtTemp.Rows(0).Item("position").ToString
                txtStatus.Text = dtTemp.Rows(0).Item("status").ToString
            Else
                MessageBox.Show("Record not found.", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtName.Clear()
                txtPosition.Clear()
                txtStatus.Clear()
            End If
            picImg.Image = GetImage(txtIDNumber.Text)
        ElseIf txtIDNumber.TextLength <= 1 Then
            txtName.Clear()
            txtPosition.Clear()
            txtStatus.Clear()
            picImg.Image = imgDefault.Images("default")
        End If
    End Sub


    Private Function GetImage(ByVal id_number As String) As Image
        Dim imgPath As String = My.Settings.PICTURES_LOCATION
        If File.Exists(Path.Combine(imgPath, id_number & ".jpg")) Then
            Dim img As Image = Image.FromFile(Path.Combine(imgPath, id_number & ".jpg"))
            Return img
        Else
            Dim img As Image = Image.FromFile(Path.Combine(imgPath, "unknown.jpg"))
            Return img
        End If
    End Function

    Private Sub btnEnrollFingerprint_Click(sender As Object, e As EventArgs) Handles btnEnrollFingerprint.Click
        If btnEnrollFingerprint.Text = "CANCEL" Then
            pnlInitialView.Visible = True
            btnEnrollFingerprint.Text = "ENROLL FINGERPRINT"
            btnEnrollFingerprint.BackColor = Color.ForestGreen
            pnl1.BackColor = Color.DimGray
            pnl2.BackColor = Color.DimGray
            pnl3.BackColor = Color.DimGray
            pnl4.BackColor = Color.DimGray
            txtIDNumber.Enabled = True
            txtIDNumber.Clear() : txtIDNumber.Focus()
        Else
            If txtIDNumber.TextLength = 6 Then
                picSuccess.Visible = False
                pnlInitialView.Visible = False
                txtIDNumber.Enabled = False
                pnl1.BackColor = SystemColors.HotTrack
                pnl2.BackColor = SystemColors.HotTrack
                pnl3.BackColor = SystemColors.HotTrack
                pnl4.BackColor = SystemColors.HotTrack
                btnEnrollFingerprint.Text = "CANCEL"
                btnEnrollFingerprint.BackColor = Color.DimGray
            Else
                pnlInitialView.Visible = True
                txtIDNumber.Focus() : txtIDNumber.SelectAll()
            End If
        End If


        Try
            Capturer = New DPFP.Capture.Capture()
            Enroller = New DPFP.Processing.Enrollment
            If (Not Capturer Is Nothing) Then
                Capturer.EventHandler = Me
                StartCapture()
                SetPrompt("Scan your fingerprint.")
            Else
                SetPrompt("Can't initiate capture operation!")
            End If
        Catch ex As Exception
            MessageBox.Show("Can't initiate capture operation!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try


       
    End Sub

    Private Sub frmEnrollFingerprint_Load(sender As Object, e As EventArgs) Handles MyBase.Load
     
        saveLocation = Application.StartupPath & "\Fingerprint"
        If Not System.IO.Directory.Exists(saveLocation) Then
            System.IO.Directory.CreateDirectory(saveLocation)
        End If
        ftpName = DateTime.Now().ToString("yyyyMMddHHssmm")
    
    End Sub
End Class