﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class AuthorizedPersonnel

    Private _profilePicture As Byte()
    Public Property ProfilePicture() As Byte()
        Get
            Return _profilePicture
        End Get
        Set(ByVal value As Byte())
            _profilePicture = value
        End Set
    End Property


    Private _biometric As Byte()
    Public Property Biometric() As Byte()
        Get
            Return _biometric
        End Get
        Set(ByVal value As Byte())
            _biometric = value
        End Set
    End Property



    Public Function IsExist(ByVal id_number As String, ByVal area_id As String) As Boolean
        Dim dtTemp As New DataTable
        Dim query As String = "SELECT * FROM tbl_authorized WHERE id_number = @id_number AND area_id = @area_id;"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = id_number
                cmd.Parameters.Add("@area_id", MySqlDbType.VarChar).Value = area_id

                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using

        If dtTemp.Rows.Count = 1 Then
            Return True
        End If
        Return False
    End Function

    Public Function Save(ByVal id_number As String, ByVal area_id As Integer) As Boolean
        Dim emp As New Employee
        emp.IDNumber = id_number
        If emp.Search Then
            Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
                con.Open()
                Using trans As MySqlTransaction = con.BeginTransaction
                    Dim query As String = "INSERT INTO tbl_authorized (id_number,area_id,name,position,status,date_updated) VALUES (@id_number,@area_id,@name,@position,@status,NOW());"
                    Try
                        Using cmd As New MySqlCommand(query, con, trans)
                            cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = emp.IDNumber
                            cmd.Parameters.Add("@area_id", MySqlDbType.VarChar).Value = area_id
                            cmd.Parameters.Add("@name", MySqlDbType.VarChar).Value = emp.FullName
                            cmd.Parameters.Add("@position", MySqlDbType.VarChar).Value = emp.PositionDescription
                            cmd.Parameters.Add("@status", MySqlDbType.VarChar).Value = emp.Status
                            cmd.ExecuteNonQuery()
                        End Using

                        Dim dtTemp As New DataTable
                        query = "SELECT id_number FROM tbl_biomet_picture WHERE id_number = @id_number;"
                        Using cmd As New MySqlCommand(query, con, trans)
                            cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = id_number
                            Using da As New MySqlDataAdapter(cmd)
                                da.Fill(dtTemp)
                            End Using
                        End Using
                        If dtTemp.Rows.Count = 1 Then
                            query = "DELETE FROM tbl_biomet_picture WHERE id_number = @id_number;"
                            Using cmd As New MySqlCommand(query, con, trans)
                                cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = id_number
                                cmd.ExecuteNonQuery()
                            End Using

                            query = "INSERT INTO tbl_biomet_picture (id_number,biometric,picture) VALUES (@id_number,@biometric,@picture);"
                            Using cmd As New MySqlCommand(query, con, trans)
                                cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = id_number
                                cmd.Parameters.Add("@biometric", MySqlDbType.LongBlob).Value = IIf(Biometric Is Nothing, DBNull.Value, Biometric)
                                cmd.Parameters.Add("@picture", MySqlDbType.LongBlob).Value = ProfilePicture
                                cmd.ExecuteNonQuery()
                            End Using
                        Else
                            query = "INSERT INTO tbl_biomet_picture (id_number,biometric,picture) VALUES (@id_number,@biometric,@picture);"
                            Using cmd As New MySqlCommand(query, con, trans)
                                cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = id_number
                                cmd.Parameters.Add("@biometric", MySqlDbType.LongBlob).Value = IIf(Biometric Is Nothing, DBNull.Value, Biometric)
                                cmd.Parameters.Add("@picture", MySqlDbType.LongBlob).Value = ProfilePicture
                                cmd.ExecuteNonQuery()
                            End Using
                        End If

                        trans.Commit()
                        Return True
                    Catch ex As MySqlException
                        trans.Rollback()
                        MessageBox.Show(ex.ToString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
                con.Close()
            End Using
        End If
        Return False
    End Function

    Public Function UpdateBiometric(ByVal id_number As String) As Boolean
        Dim query As String = "UPDATE tbl_biomet_picture SET biometric = @biometric WHERE id_number = @id_number;"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = id_number
                cmd.Parameters.Add("@biometric", MySqlDbType.LongBlob).Value = IIf(Biometric Is Nothing, DBNull.Value, Biometric)
                cmd.ExecuteNonQuery()
                Return True
            End Using
            con.Open()
        End Using
        Return False
    End Function

    Public Function Delete(ByVal id_number As String, ByVal area_id As Integer) As Boolean
        Dim query As String = "DELETE FROM tbl_authorized WHERE id_number = @id_number AND area_id = @area_id;"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = id_number
                cmd.Parameters.Add("@area_id", MySqlDbType.VarChar).Value = area_id
                cmd.ExecuteNonQuery()
                Return True
            End Using
            con.Close()
        End Using
        Return False
    End Function





    Public Function View() As DataTable
        Dim dtTemp As New DataTable
        Dim query As String = "SELECT A.id_number,A.area_id,A.name,A.position,A.status,A.date_updated,B.description,computer_name FROM tbl_authorized AS A INNER JOIN tbl_area B ON A.area_id = B.id;"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using
        Return dtTemp
    End Function

    Public Function View(ByVal area_id As Integer) As DataTable
        Dim dtTemp As New DataTable
        'Dim query As String = "SELECT A.id_number,A.area_id,A.name,A.position,A.status,A.date_updated,B.description,computer_name FROM tbl_authorized AS A INNER JOIN tbl_area B ON A.area_id = B.id WHERE A.area_id = @area_id;"
        Dim query As String = "SELECT A.id_number,A.area_id,A.name,A.position,A.status,A.date_updated,B.description,B.computer_name, C.picture,C.biometric " & _
                            "FROM tbl_authorized AS A INNER JOIN tbl_area B ON A.area_id = B.id LEFT JOIN tbl_biomet_picture AS C ON A.id_number = C.id_number " & _
                            "WHERE A.area_id = 1;"

        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@area_id", MySqlDbType.Int64).Value = area_id
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using
        Return dtTemp
    End Function



    Public Function Search(ByVal id_number As String) As DataTable
        Dim dtTemp As New DataTable
        Dim query As String = "SELECT * FROM tbl_authorized WHERE id_number = @id_number GROUP BY id_number;"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = id_number
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using

        Return dtTemp
    End Function

End Class
