﻿Imports MySql.Data.MySqlClient
Public Class Log

    Public IsTimeIN As Boolean = False

    Public Function Search(ByVal area_id As Integer, ByVal id_number As String) As String
        Dim dtTemp As New DataTable
        Dim query As String = "SELECT * FROM tbl_authorized WHERE area_id = @area_id AND id_number = @id_number;"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@area_id", MySqlDbType.Int64).Value = area_id
                cmd.Parameters.Add("@id_number", MySqlDbType.Int64).Value = id_number
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using

        If dtTemp.Rows.Count = 1 Then
            Dim history_id As Integer = AlreadyTimeIN(area_id, id_number)
            If history_id = 0 Then
                'TIME IN
                query = "INSERT INTO tbl_history (area_id,id_number,name,time_in,time_out) VALUES (@area_id,@id_number,@name,NOW(),NULL);"
                Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
                    con.Open()
                    Using cmd As New MySqlCommand(query, con)
                        cmd.Parameters.Add("@area_id", MySqlDbType.Int64).Value = area_id
                        cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = id_number
                        cmd.Parameters.Add("@name", MySqlDbType.VarChar).Value = dtTemp.Rows(0).Item("name").ToString.ToUpper.Trim
                        cmd.ExecuteNonQuery()
                        IsTimeIN = False
                    End Using
                    con.Close()
                End Using
            Else
                'TIME OUT
                query = "UPDATE tbl_history SET time_out = NOW() WHERE id = @id;"
                Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
                    con.Open()
                    Using cmd As New MySqlCommand(query, con)
                        cmd.Parameters.Add("@id", MySqlDbType.Int64).Value = history_id
                        cmd.ExecuteNonQuery()
                        IsTimeIN = True
                    End Using
                    con.Close()
                End Using

            End If
            Return dtTemp.Rows(0).Item("name").ToString.ToUpper.Trim
        End If

        Return String.Empty
    End Function



    Private Function AlreadyTimeIN(ByVal area_id As Integer, ByVal id_number As String) As Integer
        Dim dtTemp As New DataTable
        Dim query As String = "SELECT * FROM tbl_history WHERE area_id = @area_id AND id_number = @id_number AND time_out IS NULL;"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@area_id", MySqlDbType.Int64).Value = area_id
                cmd.Parameters.Add("@id_number", MySqlDbType.Int64).Value = id_number
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using
        If dtTemp.Rows.Count = 1 Then
            Return CInt(dtTemp.Rows(0).Item("id").ToString)
        End If
        Return 0
    End Function


    Public Function NoTimeOut(ByVal area_id As Integer) As DataTable
        Dim dtTemp As New DataTable
        Dim query As String = "SELECT name, DATE_FORMAT(time_in,'%r') AS `in`, CASE WHEN time_out IS NULL THEN 'NO TIME OUT' ELSE DATE_FORMAT(time_out,'%r') END AS `out` FROM tbl_history WHERE area_id = @area_id AND time_out IS NULL OR DATE(time_out) = DATE(NOW()) ORDER BY time_out DESC, time_in DESC;"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@area_id", MySqlDbType.Int64).Value = area_id
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using
        Return dtTemp
    End Function



    Public Function SearchLogs(ByVal area_id As Integer, ByVal dfrom As Date, ByVal dto As Date) As DataTable
        Dim dtTemp As New DataTable
        Dim query As String = "SELECT name,DATE_FORMAT(time_in,'[%Y-%m-%d] %r') AS `time_in`,CASE WHEN time_out IS NULL THEN 'NO TIME OUT' ELSE DATE_FORMAT(time_out,'[%Y-%m-%d] %r') END AS `time_out` FROM tbl_history WHERE area_id = @area_id AND (DATE(time_in) BETWEEN @dfrom AND @dto) AND (DATE(time_in) BETWEEN @dfrom AND @dto);"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@area_id", MySqlDbType.Int64).Value = area_id
                cmd.Parameters.Add("@dfrom", MySqlDbType.Date).Value = dfrom.ToString("yyyy-MM-dd")
                cmd.Parameters.Add("@dto", MySqlDbType.Date).Value = dto.ToString("yyyy-MM-dd")
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using
        Return dtTemp
    End Function



End Class
