﻿Imports System
Imports System.IO.Ports
Public Class Controller
    Public Shared Sub Unlock(ByRef error_msg As String)
        Try
            Using sp As New SerialPort
                sp.PortName = My.Settings.COM_PORT.ToString.ToUpper.Trim 'change com port to match your Arduino port
                sp.BaudRate = 9600
                sp.DataBits = 8
                sp.Parity = Parity.None
                sp.StopBits = StopBits.One
                sp.Handshake = Handshake.None
                sp.Encoding = System.Text.Encoding.Default 'very important!
                sp.Open()
                sp.Write("UNLOCK")
                sp.Close()
            End Using
            error_msg = String.Empty
        Catch ex As Exception
            error_msg = ex.Message
        End Try
    End Sub


End Class
