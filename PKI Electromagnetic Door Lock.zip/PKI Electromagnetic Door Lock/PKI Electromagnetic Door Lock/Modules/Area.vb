﻿Imports MySql.Data.MySqlClient
Public Class Area
    Private _id As Integer
    Public Property ID() As Integer
        Get
            Return _id
        End Get
        Set(ByVal value As Integer)
            _id = value
        End Set
    End Property
    Private _description As String
    Public Property Description() As String
        Get
            Return _description
        End Get
        Set(ByVal value As String)
            _description = value
        End Set
    End Property
    Private _computerName As String
    Public Property ComputerName() As String
        Get
            Return _computerName
        End Get
        Set(ByVal value As String)
            _computerName = value
        End Set
    End Property


    Public Sub Save()
        Dim query As String = "INSERT INTO tbl_area (description,computer_name) VALUES (@description,@computer);"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@description", MySqlDbType.VarChar).Value = Description.ToUpper.Trim
                cmd.Parameters.Add("@computer", MySqlDbType.VarChar).Value = ComputerName.ToUpper.Trim
                cmd.ExecuteNonQuery()
            End Using
            con.Close()
        End Using
    End Sub

    Public Function IsExist() As Boolean
        Dim dtTemp As New DataTable
        Dim query As String = "SELECT * FROM tbl_area WHERE description = @description OR computer_name = @computer_name;"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@description", MySqlDbType.VarChar).Value = Description.ToUpper.Trim
                cmd.Parameters.Add("@computer_name", MySqlDbType.VarChar).Value = ComputerName.ToUpper.Trim
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using

        If dtTemp.Rows.Count > 0 Then
            Return True
        End If
        Return False
    End Function


    Public Function View() As DataTable
        Dim dtTemp As New DataTable
        Dim query As String = "SELECT * FROM tbl_area;"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using
        Return dtTemp
    End Function

    Public Function AreaName(ByVal computer_name As String) As String
        Dim dtTemp As New DataTable
        Dim query As String = "SELECT * FROM tbl_area WHERE computer_name = @computer_name;"
        Using con As New MySqlConnection(My.Settings.DBDOORLOCK)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@computer_name", MySqlDbType.VarChar).Value = computer_name
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using
        If dtTemp.Rows.Count = 1 Then
            ID = dtTemp.Rows(0).Item("id").ToString.ToUpper
            Return dtTemp.Rows(0).Item("description").ToString.ToUpper
        End If
        Return String.Empty
    End Function

End Class
