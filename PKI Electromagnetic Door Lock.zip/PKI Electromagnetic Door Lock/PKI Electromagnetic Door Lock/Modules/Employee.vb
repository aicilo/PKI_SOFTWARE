﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class Employee
    Private _idNumber As String
    Public Property IDNumber() As String
        Get
            Return _idNumber
        End Get
        Set(ByVal value As String)
            _idNumber = value
        End Set
    End Property

    Private _fullName As String
    Public Property FullName() As String
        Get
            Return _fullName
        End Get
        Set(ByVal value As String)
            _fullName = value
        End Set
    End Property

    Private _status As String
    Public Property Status() As String
        Get
            Return _status
        End Get
        Set(ByVal value As String)
            _status = value
        End Set
    End Property

    Private _positionDescription As String
    Public Property PositionDescription() As String
        Get
            Return _positionDescription
        End Get
        Set(ByVal value As String)
            _positionDescription = value
        End Set
    End Property




    Sub New()

    End Sub


    Public Function Search() As Boolean
        Dim dtTemp As New DataTable
        Dim query As String = "SELECT * FROM tblemployee WHERE NEW_IDNO = @id_number;"
        Using con As New MySqlConnection(My.Settings.DBPIS)
            con.Open()
            Using cmd As New MySqlCommand(query, con)
                cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = IDNumber
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dtTemp)
                End Using
            End Using
            con.Close()
        End Using
        If dtTemp.Rows.Count = 1 Then
            FullName = dtTemp.Rows(0).Item("EMP_NAME").ToString.Trim
            Status = dtTemp.Rows(0).Item("EMPL_CODE").ToString.Trim
            PositionDescription = dtTemp.Rows(0).Item("POST_DESC").ToString.Trim
            Return True
        End If
        Return False
    End Function


    'convert image to bytearray
    Public Function imgToByteArray(ByVal img As Image) As Byte()
        Using mStream As New MemoryStream()
            img.Save(mStream, img.RawFormat)
            Return mStream.ToArray()
        End Using
    End Function
    'convert bytearray to image
    Public Function byteArrayToImage(ByVal byteArrayIn As Byte()) As Image
        Using mStream As New MemoryStream(byteArrayIn)
            Return Image.FromStream(mStream)
        End Using
    End Function
    'another easy way to convert image to bytearray
    Public Function imgToByteConverter(ByVal inImg As Image) As Byte()
        Dim imgCon As New ImageConverter()
        Return DirectCast(imgCon.ConvertTo(inImg, GetType(Byte())), Byte())
    End Function




End Class
