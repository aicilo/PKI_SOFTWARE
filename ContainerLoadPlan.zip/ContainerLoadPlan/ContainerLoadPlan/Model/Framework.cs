﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ContainerLoadPlan.Model
{
    public class Framework
    {
        private string _validString { get; set; }
        public void TextBoxValidation(System.Windows.Forms.TextBox textBox, string validString)
        {
            _validString = validString;
            textBox.KeyPress += TextValidation;
        }

        private void TextValidation(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
                e.Handled = (_validString.IndexOf(e.KeyChar) == -1);
        }
    }
}
