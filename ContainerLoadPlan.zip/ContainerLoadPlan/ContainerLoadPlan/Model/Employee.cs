﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace ContainerLoadPlan.Model
{
    
    public class Employee
    {
        public string IDNumber { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }

        public bool SearchEmployee()
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(Connection.GetConnectionStringByName("DBEMP")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandText = "SELECT L_NAME, F_NAME FROM tblemployee WHERE NEW_IDNO = @id;";
                    cmd.Parameters.Add("@id", MySqlDbType.VarChar).Value = IDNumber;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            if (dtTemp.Rows.Count == 1)
            {
                LastName = dtTemp.Rows[0]["L_NAME"].ToString();
                FirstName = dtTemp.Rows[0]["F_NAME"].ToString();
                return true;

            }

            return false;
        }

    }
}
