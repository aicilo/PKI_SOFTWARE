﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContainerLoadPlan.Model
{
    public class Global
    {
        public static DataGridView DGVContainer = new DataGridView();
        public static Label LBLTotalPallet = new Label();

        public static List<WorkOrder> WorkOrder = new List<WorkOrder>();

        public static List<Pallet> ScannedPallet = new List<Pallet>();

        public static List<Pallet> PalletList = new List<Pallet>();

        //private static string _validString = string.Empty;
        //public static void TextBoxValidation(System.Windows.Forms.TextBox textBox, string validString)
        //{
        //    _validString = validString;
        //    textBox.KeyPress += TextValidation;
        //}
        //private static void TextValidation(object sender, KeyPressEventArgs e)
        //{
        //    if (e.KeyChar != '\b')
        //        e.Handled = (_validString.IndexOf(e.KeyChar) == -1);
        //}
    }
}
