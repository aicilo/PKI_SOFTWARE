﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;

namespace ContainerLoadPlan.Model
{
    public class Pallet
    {
        public int LengthPosition { get; set; } // 1-24
        public int HeightPosition { get; set; } // 1-2
        public string PalletNumber { get; set; }

        public void AddScanPallet(Pallet pallet)
        {
            Global.ScannedPallet.Add(new Pallet { LengthPosition = pallet.LengthPosition, HeightPosition = pallet.HeightPosition, PalletNumber = pallet.PalletNumber });
        }


        public List<Pallet> LoadPalletInformation(string containerNumber)
        {
            DataTable dtTemp = new DataTable();
            var pallet = new List<Pallet>();
            using (MySqlConnection con = new MySqlConnection(Connection.GetConnectionStringByName("CLP")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandText = "SELECT length_position, height_position, pallet_number FROM tbl_pallet WHERE container_number = @container_number ORDER BY length_position ASC, height_position ASC;";
                    cmd.Parameters.Add("@container_number", MySqlDbType.VarChar).Value = containerNumber;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            foreach (DataRow row in dtTemp.Rows)
            {
                pallet.Add(new Pallet() { LengthPosition = Int16.Parse(row["length_position"].ToString()), HeightPosition = Int16.Parse(row["height_position"].ToString()), PalletNumber = row["pallet_number"].ToString() });
            }

            return pallet;

        }
    }
}
