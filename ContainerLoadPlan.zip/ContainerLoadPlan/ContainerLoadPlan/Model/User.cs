﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContainerLoadPlan.Model
{
    public class User
    {
        public string IdNumber { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }

        public string Type { get; set; }
        public DateTime DateRegistered { get; set; }


        public List<User> GetUsers()
        {

            DataTable dtTemp = new DataTable();
            var users = new List<User>();
            using (MySqlConnection con = new MySqlConnection(Connection.GetConnectionStringByName("CLP")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandText = "SELECT id_number, first_name, last_name, user_type, date_register FROM tbl_user;";
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            foreach (DataRow row in dtTemp.Rows)
            {
                users.Add(new User() { IdNumber = row["id_number"].ToString(), FirstName = row["first_name"].ToString(), LastName = row["last_name"].ToString(), Type = row["user_type"].ToString(), DateRegistered = Convert.ToDateTime(row["date_register"].ToString()) });
            }

            return users;
        }

        public void Register()
       {
            try
            {
                if (UserExist() == false)
                {
                    using (MySqlConnection con = new MySqlConnection(Connection.GetConnectionStringByName("CLP")))
                    {
                        con.Open();
                        using (MySqlCommand cmd = new MySqlCommand())
                        {
                            cmd.Connection = con;
                            cmd.CommandText = "INSERT INTO tbl_user (id_number,first_name,last_name,user_type,date_register) VALUES (@id_number,@first_name,@last_name,@user_type,NOW())";
                            cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = IdNumber;
                            cmd.Parameters.Add("@first_name", MySqlDbType.VarChar).Value = LastName;
                            cmd.Parameters.Add("@last_name", MySqlDbType.VarChar).Value = FirstName;
                            cmd.Parameters.Add("@user_type", MySqlDbType.VarChar).Value = "LOADER";
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Registered successfully!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        con.Close();
                    }
                }
                else
                {
                    MessageBox.Show("User is already exist!", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); 
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private bool UserExist()
        {
            try
            {
                DataTable dtTemp = new DataTable();
                using (MySqlConnection con = new MySqlConnection(Connection.GetConnectionStringByName("CLP")))
                {
                    con.Open();
                    using (MySqlCommand cmd = new MySqlCommand())
                    {
                        cmd.Connection = con;
                        cmd.CommandText = "SELECT * FROM tbl_user WHERE id_number = @id_number;";
                        cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = IdNumber;
                        using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                        {
                            da.Fill(dtTemp);
                        }
                    }
                    con.Close();
                }
                if (dtTemp.Rows.Count == 1)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return false;
        }
    }
}
