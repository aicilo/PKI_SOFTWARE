﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports;
using CrystalDecisions.CrystalReports.Engine;
using ContainerLoadPlan.Template;
using System.Configuration;

namespace ContainerLoadPlan.Model
{
    public class ContainerPlan : WorkOrder
    {

        public string ContainerNumber { get; set; }
        public string SealNumber { get; set; }
        public int TotalPallets { get; set; }
        public DateTime DateArrived { get; set; }
        public DateTime DatePulledOut { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime DateApproved { get; set; }


        public bool Is_Existing_Plan(string invoiceNumber)
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(Connection.GetConnectionStringByName("CLP")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandText = "SELECT container_number, seal_number, destination, total_pallets, date_arrived, date_pulled_out, approved_by, date_approved FROM tbl_plan WHERE invoice_number = @invoice_number;";
                    cmd.Parameters.Add("@invoice_number", MySqlDbType.VarChar).Value = invoiceNumber;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            if (dtTemp.Rows.Count == 1)
            {
                InvoiceNumber = invoiceNumber;
                ContainerNumber = dtTemp.Rows[0]["container_number"].ToString();
                Destination = dtTemp.Rows[0]["destination"].ToString();
                TotalPallets = Int16.Parse(dtTemp.Rows[0]["total_pallets"].ToString());
                SealNumber = dtTemp.Rows[0]["seal_number"].ToString();
                DateArrived = Convert.ToDateTime(dtTemp.Rows[0]["date_arrived"]);
                DatePulledOut = Convert.ToDateTime(dtTemp.Rows[0]["date_pulled_out"]);
                ApprovedBy = dtTemp.Rows[0]["approved_by"].ToString();
                DateApproved = Convert.ToDateTime(dtTemp.Rows[0]["date_approved"]);
                return true;
            }
            return false;
        }


        public bool SaveContainer(ContainerPlan container, List<Pallet> palletList)
        {
            using (MySqlConnection con = new MySqlConnection(Connection.GetConnectionStringByName("CLP")))
            {
                con.Open();
                using (MySqlTransaction tran = con.BeginTransaction())
                {
                    try
                    {
                        if (Is_Existing_Plan(container.InvoiceNumber) == false)
                        {
                            using (MySqlCommand cmd = new MySqlCommand())
                            {
                                cmd.Connection = con;
                                cmd.Transaction = tran;
                                cmd.CommandText = "INSERT INTO tbl_plan (container_number,seal_number,invoice_number,destination,total_pallets,date_arrived,date_pulled_out,approved_by,date_approved) VALUE (@container_number,@seal_number,@invoice_number,@destination,@total_pallets,@date_arrived,@date_pulled_out,@approved_by,NOW());";
                                cmd.Parameters.Add("@container_number", MySqlDbType.VarChar).Value = container.ContainerNumber;
                                cmd.Parameters.Add("@seal_number", MySqlDbType.VarChar).Value = container.SealNumber;
                                cmd.Parameters.Add("@invoice_number", MySqlDbType.VarChar).Value = container.InvoiceNumber;
                                cmd.Parameters.Add("@destination", MySqlDbType.VarChar).Value = container.Destination;
                                cmd.Parameters.Add("@total_pallets", MySqlDbType.VarChar).Value = container.TotalPallets;
                                cmd.Parameters.Add("@date_arrived", MySqlDbType.DateTime).Value = container.DateArrived;
                                cmd.Parameters.Add("@date_pulled_out", MySqlDbType.DateTime).Value = container.DatePulledOut;
                                cmd.Parameters.Add("@approved_by", MySqlDbType.VarChar).Value = container.ApprovedBy;
                                cmd.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            using (MySqlCommand cmd = new MySqlCommand())
                            {
                                cmd.Connection = con;
                                cmd.Transaction = tran;
                                cmd.CommandText = "UPDATE tbl_plan SET container_number = @container_number, seal_number = @seal_number, date_pulled_out = @date_pulled_out, approved_by = @approved_by ,date_approved = NOW() WHERE invoice_number = @invoice_number;";
                                cmd.Parameters.Add("@container_number", MySqlDbType.VarChar).Value = container.ContainerNumber;
                                cmd.Parameters.Add("@seal_number", MySqlDbType.VarChar).Value = container.SealNumber;
                                cmd.Parameters.Add("@invoice_number", MySqlDbType.VarChar).Value = container.InvoiceNumber;
                                cmd.Parameters.Add("@date_pulled_out", MySqlDbType.DateTime).Value = container.DatePulledOut;
                                cmd.Parameters.Add("@approved_by", MySqlDbType.VarChar).Value = container.ApprovedBy;
                                cmd.ExecuteNonQuery();
                            }
                        }


                        foreach (var pallet in palletList)
                        {
                            if (Is_Existing_Pallet(container.ContainerNumber, pallet.PalletNumber) == false)
                            {
                                if (Is_Update_Pallet(container.ContainerNumber, pallet.LengthPosition, pallet.HeightPosition) == false)
                                {
                                    using (MySqlCommand cmd = new MySqlCommand())
                                    {
                                        cmd.Connection = con;
                                        cmd.Transaction = tran;
                                        cmd.CommandText = "INSERT INTO tbl_pallet (container_number,length_position,height_position,pallet_number,added_by,date_added) VALUE (@container_number,@length_position,@height_position,@pallet_number,@added_by,NOW());";
                                        cmd.Parameters.Add("@container_number", MySqlDbType.VarChar).Value = container.ContainerNumber;
                                        cmd.Parameters.Add("@length_position", MySqlDbType.Int16).Value = pallet.LengthPosition;
                                        cmd.Parameters.Add("@height_position", MySqlDbType.Int16).Value = pallet.HeightPosition;
                                        cmd.Parameters.Add("@pallet_number", MySqlDbType.VarChar).Value = pallet.PalletNumber;
                                        cmd.Parameters.Add("@added_by", MySqlDbType.VarChar).Value = container.ApprovedBy;
                                        cmd.ExecuteNonQuery();
                                    }
                                }
                                else
                                {
                                    using (MySqlCommand cmd = new MySqlCommand())
                                    {
                                        cmd.Connection = con;
                                        cmd.Transaction = tran;
                                        cmd.CommandText = "UPDATE tbl_pallet SET pallet_number = @pallet_number, added_by = @added_by, date_added = NOW() WHERE container_number = @container_number AND length_position = @length_position AND height_position = @height_position;";
                                        cmd.Parameters.Add("@container_number", MySqlDbType.VarChar).Value = container.ContainerNumber;
                                        cmd.Parameters.Add("@length_position", MySqlDbType.Int16).Value = pallet.LengthPosition;
                                        cmd.Parameters.Add("@height_position", MySqlDbType.Int16).Value = pallet.HeightPosition;
                                        cmd.Parameters.Add("@pallet_number", MySqlDbType.VarChar).Value = pallet.PalletNumber;
                                        cmd.Parameters.Add("@added_by", MySqlDbType.VarChar).Value = container.ApprovedBy;
                                        cmd.ExecuteNonQuery();
                                    }  
                                }

                                
                            }    
                        }
                        tran.Commit();
                        return true;
                    }
                    catch (MySqlException ex)
                    {
                         MessageBox.Show(ex.Message);
                    }
                }

                con.Close();
            }
           
            return false;
        }


        public bool Is_Existing_Pallet(string containerNumber, string palletNumber)
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(Connection.GetConnectionStringByName("CLP")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandText = "SELECT * FROM tbl_pallet WHERE container_number = @container_number AND pallet_number = @pallet_number;";
                    cmd.Parameters.Add("@container_number", MySqlDbType.VarChar).Value = containerNumber;
                    cmd.Parameters.Add("@pallet_number", MySqlDbType.VarChar).Value = palletNumber;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            if (dtTemp.Rows.Count > 0)
            {
                return true;
            }

            return false;
        }

        public bool Is_Update_Pallet(string containerNumber,int lengthPos,int heightPos)
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(Connection.GetConnectionStringByName("CLP")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandText = "SELECT * FROM tbl_pallet WHERE container_number = @container_number AND length_position = @length_position AND height_position = @height_position;";
                    cmd.Parameters.Add("@container_number", MySqlDbType.VarChar).Value = containerNumber;
                    cmd.Parameters.Add("@length_position", MySqlDbType.VarChar).Value = lengthPos;
                    cmd.Parameters.Add("@height_position", MySqlDbType.VarChar).Value = heightPos;

                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            if (dtTemp.Rows.Count > 0)
            {
                return true;
            }

            return false;
        }

        public bool DeleteContainer(string containerNumber)
        {
            using (MySqlConnection con = new MySqlConnection(Connection.GetConnectionStringByName("CLP")))
            { 
                con.Open();
                using (MySqlTransaction tran = con.BeginTransaction())
                {
                    try
                    {
                        using (MySqlCommand cmd = new MySqlCommand())
                        {
                            cmd.Connection = con;
                            cmd.Transaction = tran;
                            cmd.CommandText = "DELETE FROM tbl_plan WHERE container_number = @container_number;";
                            cmd.Parameters.Add("@container_number", MySqlDbType.VarChar).Value = containerNumber;
                            cmd.ExecuteNonQuery();
                        }
                        using (MySqlCommand cmd = new MySqlCommand())
                        {
                            cmd.Connection = con;
                            cmd.Transaction = tran;
                            cmd.CommandText = "DELETE FROM tbl_pallet WHERE container_number = @container_number;";
                            cmd.Parameters.Add("@container_number", MySqlDbType.VarChar).Value = containerNumber;
                            cmd.ExecuteNonQuery();
                        }
                        tran.Commit();
                        return true;
                    }
                    catch (MySqlException ex)
                    {
                        tran.Rollback();
                        MessageBox.Show(ex.Message);
                        return false;
                    }
                }
            }
        }

        public DataSet dsContainerInformation(string containerNumber)
        {
            DataTable dtTemp = new DataTable();
            Template.dsContainer ds = new Template.dsContainer();

            using (MySqlConnection con = new MySqlConnection(Connection.GetConnectionStringByName("CLP")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandText = "SELECT D.container_number AS `containerNumber`, D.seal_number AS `sealNumber`," +
                    "D.invoice_number AS `invoiceNumber`, D.destination, " +
                    "DATE_FORMAT(D.date_arrived, '%Y-%m-%d %h:%i %p') AS `dateArrived`, " +
                    "DATE_FORMAT(D.date_pulled_out, '%Y-%m-%d %h:%i %p') AS `datePulledOut`, " +
                    "D.approved_by AS `approvedBy`, DATE_FORMAT(D.date_approved, '%Y-%m-%d') AS `dateApproved`, " +
                    "A.length_position AS `lengthPosition`, " +
                    "A.pallet_number AS `pallet_1`, " +
                    "(CASE WHEN C.pallet_number IS NULL THEN B.pallet_number ELSE CONCAT(B.pallet_number,'/',C.pallet_number) END) AS `pallet_2`, " +
                    "(SELECT COUNT(pallet_number) FROM tbl_pallet WHERE container_number = @containerNumber) AS `totalPallets`, " +
                    "(CASE WHEN B.pallet_number IS NOT NULL THEN B.added_by ELSE A.added_by END) AS `addedBy`, " +
                    "(CASE WHEN B.date_added IS NOT NULL THEN DATE_FORMAT(B.date_added, '%Y-%m-%d') ELSE DATE_FORMAT(A.date_added, '%Y-%m-%d') END) AS `dateAdded` " +
                    "FROM tbl_pallet A " +
                    "LEFT JOIN tbl_pallet B ON B.container_number = A.container_number AND B.height_position = 2 AND B.length_position = A.length_position " +
                    "LEFT JOIN tbl_pallet C ON C.container_number = B.container_number AND C.height_position = 3 AND C.length_position = B.length_position " +
                    "INNER JOIN tbl_plan AS D ON D.container_number = A.container_number " +
                    "WHERE A.container_number = @containerNumber GROUP BY A.length_position ORDER BY A.length_position ASC;";
                    cmd.Parameters.Add("@containerNumber", MySqlDbType.VarChar).Value = containerNumber;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                        da.Fill(ds, "dtContainer");
                    }
                }
                con.Close();
                return ds;
            }
        }



     }
}
