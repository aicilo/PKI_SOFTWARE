﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;


namespace ContainerLoadPlan.Model
{
    public class WorkOrder
    {
        public string AreaCode { get; set; }
        public string DeliverySite { get; set; }
        public string InvoiceNumber { get; set; }
        public string Destination { get; set; }


        public List<WorkOrder> WorkOrderList()
        {
            DataTable dtTemp = new DataTable();
            var order = new List<WorkOrder>();
            using (SqlConnection con = new SqlConnection(Connection.GetConnectionStringByName("PCSDB")))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandText = "SELECT [Area Code],[Delivery Site],[Ship Work No],[Final Destination] FROM [PCSDB].[dbo].[vw_22_ifgs_work_no] WHERE [Date Confirmed] IS NULL GROUP BY [Area Code],[Delivery Site],[Ship Work No],[Final Destination] ORDER BY [Ship Work No];";
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            foreach (DataRow row in dtTemp.Rows)
            {
                order.Add(new WorkOrder() { AreaCode = row["Area Code"].ToString(), DeliverySite = row["Delivery Site"].ToString(), InvoiceNumber = row["Ship Work No"].ToString(), Destination = row["Final Destination"].ToString() });
            }
            return order;
        }

        }
}
