﻿namespace ContainerLoadPlan
{
    partial class frmPrintPreview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.crvLoad = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // crvLoad
            // 
            this.crvLoad.ActiveViewIndex = -1;
            this.crvLoad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crvLoad.Cursor = System.Windows.Forms.Cursors.Default;
            this.crvLoad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crvLoad.Location = new System.Drawing.Point(0, 0);
            this.crvLoad.Name = "crvLoad";
            this.crvLoad.ShowCloseButton = false;
            this.crvLoad.ShowCopyButton = false;
            this.crvLoad.ShowExportButton = false;
            this.crvLoad.ShowGotoPageButton = false;
            this.crvLoad.ShowGroupTreeButton = false;
            this.crvLoad.ShowPageNavigateButtons = false;
            this.crvLoad.ShowParameterPanelButton = false;
            this.crvLoad.ShowRefreshButton = false;
            this.crvLoad.ShowTextSearchButton = false;
            this.crvLoad.Size = new System.Drawing.Size(946, 609);
            this.crvLoad.TabIndex = 0;
            this.crvLoad.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // frmPrintPreview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 609);
            this.Controls.Add(this.crvLoad);
            this.Name = "frmPrintPreview";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmPrintPreview";
            this.ResumeLayout(false);

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer crvLoad;
    }
}