﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ContainerLoadPlan.Model;

namespace ContainerLoadPlan
{
    public partial class frmScanPallet : Form
    {
        private string InvoiceNumber;
        private int TotalPallets;
        private Pallet SelectedPallet = null;

        public frmScanPallet(string invoice, int totalPallets, Pallet pallet = null)
        {
            InitializeComponent();
            InvoiceNumber = invoice;
            TotalPallets = totalPallets;
            SelectedPallet = pallet;
            //Global.TextBoxValidation(txtPallet, "0987654321");
           
            this.ShowInTaskbar = false;
        }

       
        private void txtPallet_TextChanged(object sender, EventArgs e)
        {
            //if (txtPallet.TextLength >= 3)
            //{
                

                //txtPallet.Focus();
                //txtPallet.SelectAll();
            //}
            //else
            //{
            //    //txtPallet.Focus();
            //    //txtPallet.SelectAll();
            //}


                      
        }

        private void frmScanPallet_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                DataGridView dgv = Global.DGVContainer;
                dgv.ClearSelection();
                this.Close();
            }
        }

        private void txtPallet_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string strPallet = null;
                if (txtPallet.Text.Length == 14)
                {

                    strPallet = txtPallet.Text.Substring(9, 3);
                }
                else if (txtPallet.Text.Length == 3)
                {
                    strPallet = txtPallet.Text;
                }
                else
                {
                    txtPallet.Clear();
                    return;
                }

                DataGridView dgv = Global.DGVContainer;
                int lengthPos = dgv.Rows.Count;
                Pallet searchLengthPos = Global.ScannedPallet.Find(x => x.LengthPosition.Equals(lengthPos));
                if (searchLengthPos != null) 
                {
                    Pallet searchPallet = Global.ScannedPallet.Find(x => x.PalletNumber.Equals(strPallet));
                    if (searchPallet == null) 
                    {
                        if (SelectedPallet == null)
                        {
                            if (dgv.Rows[lengthPos - 1].Cells[2].Value == null)
                            {
                                var pallet = new Pallet() { LengthPosition = lengthPos, HeightPosition = 2, PalletNumber = strPallet };
                                pallet.AddScanPallet(pallet);
                                dgv.Rows[dgv.Rows.Count - 1].Cells[2].Value = strPallet;
                                dgv.Rows[dgv.Rows.Count - 1].Cells[2].Selected = true;
                            }
                            else
                            {
                                if (lengthPos == 24 && Global.ScannedPallet.Count == 48 && TotalPallets == 49)
                                {
                                    var pallet = new Pallet() { LengthPosition = lengthPos, HeightPosition = 3, PalletNumber = strPallet };
                                    pallet.AddScanPallet(pallet);
                                    dgv.Rows[dgv.Rows.Count - 1].Cells[2].Value = string.Format("{0}/{1}", dgv.Rows[dgv.Rows.Count - 1].Cells[2].Value, strPallet);
                                    dgv.Rows[dgv.Rows.Count - 1].Cells[2].Selected = true;
                                }
                                else if (lengthPos == 23 && Global.ScannedPallet.Count == 46 && TotalPallets == 50)
                                {
                                    var pallet = new Pallet() { LengthPosition = lengthPos, HeightPosition = 3, PalletNumber = strPallet };
                                    pallet.AddScanPallet(pallet);
                                    dgv.Rows[dgv.Rows.Count - 1].Cells[2].Value = string.Format("{0}/{1}", dgv.Rows[dgv.Rows.Count - 1].Cells[2].Value, strPallet);
                                    dgv.Rows[dgv.Rows.Count - 1].Cells[2].Selected = true;
                                }
                                else if (lengthPos == 24 && Global.ScannedPallet.Count == 49 && TotalPallets == 50)
                                {
                                    var pallet = new Pallet() { LengthPosition = lengthPos, HeightPosition = 3, PalletNumber = strPallet };
                                    pallet.AddScanPallet(pallet);
                                    dgv.Rows[dgv.Rows.Count - 1].Cells[2].Value = string.Format("{0}/{1}", dgv.Rows[dgv.Rows.Count - 1].Cells[2].Value, strPallet);
                                    dgv.Rows[dgv.Rows.Count - 1].Cells[2].Selected = true;
                                }
                                else
                                {
                                    var pallet = new Pallet() { LengthPosition = lengthPos + 1, HeightPosition = 1, PalletNumber = strPallet };
                                    pallet.AddScanPallet(pallet);
                                    dgv.Rows.Add(pallet.LengthPosition, strPallet, null);
                                    dgv.Rows[dgv.Rows.Count - 1].Cells[1].Selected = true;
                                }
                            }
                        }
                        else
                        {
                            searchPallet = Global.ScannedPallet.Find(x => x.LengthPosition.Equals(SelectedPallet.LengthPosition) && x.HeightPosition.Equals(SelectedPallet.HeightPosition) && x.PalletNumber.Equals(SelectedPallet.PalletNumber));
                            if (searchPallet != null)
                            {
                                searchPallet.PalletNumber = strPallet;
                                dgv.Rows[SelectedPallet.LengthPosition - 1].Cells[SelectedPallet.HeightPosition].Value = strPallet;
                                dgv.Rows[SelectedPallet.LengthPosition - 1].Cells[SelectedPallet.HeightPosition].Selected = true;
                                this.Hide();
                                MessageBox.Show("The pallet number has been changed.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }

                        }

                    
                    }
                    else
                    {

                        frmNotification notif = new frmNotification("PALLET NUMBER IS ALREADY SCANNED!");
                        notif.ShowDialog();
                   
                    }    
                }
                else
                {
                    var pallet = new Pallet() { LengthPosition = 1, HeightPosition = 1, PalletNumber = strPallet };
                    pallet.AddScanPallet(pallet);
                    dgv.Rows.Add(pallet.LengthPosition, strPallet, null);
                    dgv.Rows[dgv.Rows.Count - 1].Cells[1].Selected = true;
                }

                dgv.FirstDisplayedScrollingRowIndex = dgv.Rows.Count - 1;
                Global.LBLTotalPallet.Text = string.Format("Total No. of Pallets: {0}", Global.ScannedPallet.Count);

                if (Global.ScannedPallet.Count == TotalPallets)
                {
                    this.Close();
                }
                else
                {
                    if (SelectedPallet != null)
                    {
                       
                        this.Close();
                    }
                    else
                    {
                        frmScanInvoice invoice = new frmScanInvoice(InvoiceNumber, TotalPallets);
                        this.Hide();
                        invoice.ShowDialog();
                        this.Close();
                        //this.
                    }
                    
                }
            }
        }






       
    }
}
