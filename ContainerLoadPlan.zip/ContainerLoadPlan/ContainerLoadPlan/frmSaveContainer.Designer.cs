﻿namespace ContainerLoadPlan
{
    partial class frmSaveContainer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtContainerNumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSealNumber = new System.Windows.Forms.TextBox();
            this.dtpArrived = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpPulledOut = new System.Windows.Forms.DateTimePicker();
            this.txtIDNumber = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(559, 64);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label1.Location = new System.Drawing.Point(152, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "SAVE CONTAINER";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel2.Controls.Add(this.label9);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 364);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(559, 25);
            this.panel2.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(7, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(153, 15);
            this.label9.TabIndex = 20;
            this.label9.Text = "Press Escape to close.";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 64);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 300);
            this.panel3.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(558, 64);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 300);
            this.panel4.TabIndex = 4;
            // 
            // txtContainerNumber
            // 
            this.txtContainerNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtContainerNumber.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContainerNumber.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtContainerNumber.Location = new System.Drawing.Point(25, 83);
            this.txtContainerNumber.MaxLength = 11;
            this.txtContainerNumber.Name = "txtContainerNumber";
            this.txtContainerNumber.Size = new System.Drawing.Size(294, 48);
            this.txtContainerNumber.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.label2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label2.Location = new System.Drawing.Point(22, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Container Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.label3.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label3.Location = new System.Drawing.Point(322, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Seal Number";
            // 
            // txtSealNumber
            // 
            this.txtSealNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSealNumber.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSealNumber.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtSealNumber.Location = new System.Drawing.Point(325, 83);
            this.txtSealNumber.MaxLength = 9;
            this.txtSealNumber.Name = "txtSealNumber";
            this.txtSealNumber.Size = new System.Drawing.Size(205, 48);
            this.txtSealNumber.TabIndex = 2;
            // 
            // dtpArrived
            // 
            this.dtpArrived.CalendarForeColor = System.Drawing.Color.DarkSlateGray;
            this.dtpArrived.CalendarTitleForeColor = System.Drawing.Color.DarkSlateGray;
            this.dtpArrived.CustomFormat = "yyyy-MM-dd hh:mm tt";
            this.dtpArrived.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.dtpArrived.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpArrived.Location = new System.Drawing.Point(25, 163);
            this.dtpArrived.Name = "dtpArrived";
            this.dtpArrived.Size = new System.Drawing.Size(177, 23);
            this.dtpArrived.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.label4.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label4.Location = new System.Drawing.Point(22, 189);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 15);
            this.label4.TabIndex = 10;
            this.label4.Text = "Date / Time / Arrived";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.label5.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label5.Location = new System.Drawing.Point(22, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(157, 15);
            this.label5.TabIndex = 12;
            this.label5.Text = "Date / Time / Pulled Out";
            // 
            // dtpPulledOut
            // 
            this.dtpPulledOut.CalendarForeColor = System.Drawing.Color.DarkSlateGray;
            this.dtpPulledOut.CalendarTitleForeColor = System.Drawing.Color.DarkSlateGray;
            this.dtpPulledOut.CustomFormat = "yyyy-MM-dd hh:mm tt";
            this.dtpPulledOut.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.dtpPulledOut.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPulledOut.Location = new System.Drawing.Point(25, 217);
            this.dtpPulledOut.Name = "dtpPulledOut";
            this.dtpPulledOut.Size = new System.Drawing.Size(177, 23);
            this.dtpPulledOut.TabIndex = 11;
            // 
            // txtIDNumber
            // 
            this.txtIDNumber.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F);
            this.txtIDNumber.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtIDNumber.Location = new System.Drawing.Point(25, 307);
            this.txtIDNumber.MaxLength = 6;
            this.txtIDNumber.Name = "txtIDNumber";
            this.txtIDNumber.Size = new System.Drawing.Size(98, 32);
            this.txtIDNumber.TabIndex = 3;
            this.txtIDNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtIDNumber.TextChanged += new System.EventHandler(this.txtIDNumber_TextChanged);
            this.txtIDNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtIDNumber_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.label6.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label6.Location = new System.Drawing.Point(22, 342);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "ID Number";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.label7.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label7.Location = new System.Drawing.Point(126, 342);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 15);
            this.label7.TabIndex = 16;
            this.label7.Text = "Name";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Gainsboro;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label8.Location = new System.Drawing.Point(25, 266);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(5);
            this.label8.Size = new System.Drawing.Size(504, 35);
            this.label8.TabIndex = 17;
            this.label8.Text = "Please scan your Id number to save this container.";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblName
            // 
            this.lblName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblName.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F);
            this.lblName.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblName.Location = new System.Drawing.Point(129, 307);
            this.lblName.Name = "lblName";
            this.lblName.Padding = new System.Windows.Forms.Padding(1);
            this.lblName.Size = new System.Drawing.Size(401, 33);
            this.lblName.TabIndex = 25;
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frmSaveContainer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(559, 389);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtIDNumber);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dtpPulledOut);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtpArrived);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSealNumber);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtContainerNumber);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Name = "frmSaveContainer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmSaveContainer";
            this.Load += new System.EventHandler(this.frmSaveContainer_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmSaveContainer_KeyDown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtContainerNumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSealNumber;
        private System.Windows.Forms.DateTimePicker dtpArrived;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpPulledOut;
        private System.Windows.Forms.TextBox txtIDNumber;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label9;
    }
}