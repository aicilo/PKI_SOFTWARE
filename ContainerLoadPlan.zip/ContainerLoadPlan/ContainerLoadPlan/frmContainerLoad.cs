﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using ContainerLoadPlan.Model;
using System.Configuration;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;

namespace ContainerLoadPlan
{
    public partial class frmContainerLoad : Form
    {
        public frmContainerLoad()
        {
            InitializeComponent();

              
            dgvContainer.MultiSelect = false;
            dgvContainer.SelectionMode = DataGridViewSelectionMode.CellSelect;
            dgvContainer.DefaultCellStyle.SelectionBackColor = Color.DarkTurquoise;
            dgvContainer.DefaultCellStyle.SelectionForeColor = Color.White;


            Global.DGVContainer = dgvContainer;
            Global.LBLTotalPallet = lblTotalPallet;

            var order = new WorkOrder();
            var workOrderList = order.WorkOrderList();
            var listOfAreaCode = workOrderList.GroupBy(x => x.AreaCode).Select(y => y.First());
            foreach (var area in listOfAreaCode)
            {
                cboAreaCode.Items.Add(area.AreaCode);
            }
            
        }

              

        private void frmContainerLoad_Load(object sender, EventArgs e)
        {
            
            Rectangle cellRectangle = new Rectangle();
            cellRectangle = dgvContainer.GetCellDisplayRectangle(1, -1, true);
            Point displayPoint = new Point(cellRectangle.X + 1, cellRectangle.Y + 1);
            Label description = new Label();
            description.Size = new Size(196, 43);
            description.BackColor = Color.DarkSlateGray;
            description.ForeColor = Color.White;
            description.Location = displayPoint;
            description.Text = "PALLET NUMBER INSIDE THE CONTAINER";
            description.TextAlign = ContentAlignment.MiddleCenter;
            description.Font = new Font("Arial Rounded MT", 7 ,FontStyle.Bold);

            dgvContainer.Controls.Add(description);
        }

        private void cboAreaCode_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cboDeliverySite.Items.Clear();
            cboInvoice.Items.Clear();
            Clear();
            var order = new WorkOrder();
            var workOrderList = order.WorkOrderList();
            var listOfDeliverySite = workOrderList.FindAll(x => x.AreaCode.Equals(cboAreaCode.Text));
            foreach (var site in listOfDeliverySite.GroupBy(x => x.DeliverySite).Select(x => x.First()).ToList())
            {
                cboDeliverySite.Items.Add(site.DeliverySite);
            }
        }

        private void cboDeliverySite_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cboInvoice.Items.Clear();
            Clear();
            var order = new WorkOrder();
            var workOrderList = order.WorkOrderList();
            var listOfShippingWorkNumber = workOrderList.FindAll(x => x.AreaCode.Equals(cboAreaCode.Text) && x.DeliverySite.Equals(cboDeliverySite.Text));
            foreach (var shipping in listOfShippingWorkNumber.GroupBy(x => x.InvoiceNumber).Select(x => x.First()).ToList())
            {
                cboInvoice.Items.Add(shipping.InvoiceNumber);
            }
        }


        private void Clear()
        {
            btnScanCrateNo.Text = "READY TO SCAN";
            pnlContainerInfo.Visible = false;
            lblDestination.Text = string.Empty;
            dgvContainer.Rows.Clear();
            cboTotalPallets.SelectedIndex = -1;
            Global.ScannedPallet.Clear();
            lblTotalPallet.Text = string.Format("Total No. of Pallets: {0}", Global.ScannedPallet.Count);
        }
        private void cboInvoice_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Clear();
            var order = new WorkOrder();
            var workOrderList = order.WorkOrderList();
            var destination = workOrderList.Find(x => x.AreaCode.Equals(cboAreaCode.Text) && x.DeliverySite.Equals(cboDeliverySite.Text) && x.InvoiceNumber.Equals(cboInvoice.Text));
            if (destination != null)
            {
                lblDestination.Text = destination.Destination;
            }
            else
            {
                lblDestination.Text = string.Empty;
            }


            var plan = new ContainerLoadPlan.Model.ContainerPlan();
            plan.InvoiceNumber = cboInvoice.Text;
            if (plan.Is_Existing_Plan(cboInvoice.Text) == true)
            {
                pnlContainerInfo.Visible = true;
                lblContainerNumber.Text = plan.ContainerNumber;
                lblSealNumber.Text = plan.SealNumber;
                cboTotalPallets.Text = plan.TotalPallets.ToString();
                var pallet = new Pallet();
                List<Pallet> ListOfPallets = pallet.LoadPalletInformation(plan.ContainerNumber);

                foreach (var p in ListOfPallets)
                {
                    pallet.AddScanPallet(new Pallet() { LengthPosition = p.LengthPosition, HeightPosition = p.HeightPosition, PalletNumber = p.PalletNumber });
                  
                    if (p.HeightPosition == 1)
                    {
                        dgvContainer.Rows.Add();
                        dgvContainer.Rows[dgvContainer.Rows.Count - 1].Cells[0].Value = p.LengthPosition;
                        dgvContainer.Rows[dgvContainer.Rows.Count - 1].Cells[1].Value = p.PalletNumber;
                        dgvContainer.Rows[dgvContainer.Rows.Count - 1].Cells[1].Selected = true;
                    }
                    else if(p.HeightPosition == 2)
                    {
                        dgvContainer.Rows[dgvContainer.Rows.Count - 1].Cells[2].Value = p.PalletNumber;
                        dgvContainer.Rows[dgvContainer.Rows.Count - 1].Cells[2].Selected = true;
                    }
                    else if (p.HeightPosition == 3)
                    {
                        dgvContainer.Rows[dgvContainer.Rows.Count - 1].Cells[2].Value = string.Format("{0}/{1}",dgvContainer.Rows[dgvContainer.Rows.Count - 1].Cells[2].Value, p.PalletNumber);
                        dgvContainer.Rows[dgvContainer.Rows.Count - 1].Cells[2].Selected = true;
                    }

                }

                if (ListOfPallets.Count == plan.TotalPallets)
                {
                    btnScanCrateNo.Text = "PRINT";
                }
                else 
                {
                    btnScanCrateNo.Text = "CONTINUE SCANNING";
           
                }
                cboTotalPallets.Enabled = false;

            }
            else 
            {
                btnScanCrateNo.Text = "READY TO SCAN";
                cboTotalPallets.Enabled = true;
            }
            lblTotalPallet.Text = string.Format("Total No. of Pallets: {0}", Global.ScannedPallet.Count);

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            if (Global.DGVContainer.Rows.Count > 0)
            {
                var msg = MessageBox.Show("Are you sure you want to reset scanned pallet?", "Reset", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (msg == System.Windows.Forms.DialogResult.Yes)
                {
                    Global.ScannedPallet.Clear();
                    Global.DGVContainer.Rows.Clear();
                    Global.LBLTotalPallet.Text = string.Format("Total No. of Pallets: {0}", Global.ScannedPallet.Count);
                    if (pnlContainerInfo.Visible == true)
                    {
                        var container = new ContainerPlan();
                        if (container.DeleteContainer(lblContainerNumber.Text) == true)
                        {
                            pnlContainerInfo.Visible = false;
                            cboAreaCode.SelectedIndex = -1;
                            cboDeliverySite.Items.Clear();
                            cboInvoice.Items.Clear();
                            cboTotalPallets.SelectedIndex = -1;
                            lblDestination.Text = string.Empty;
                        }
                    }
                    btnScanCrateNo.Text = "READY TO SCAN";
                }
            }
           
        }
 
        private void frmContainerLoad_KeyDown(object sender, KeyEventArgs e)
        {
            if (!string.IsNullOrEmpty(cboInvoice.Text) && !string.IsNullOrEmpty(cboTotalPallets.Text))
            {
                if (e.Modifiers == Keys.Control)
                {
                    if (e.KeyCode == Keys.S)
                    {
                        if (Global.ScannedPallet.Count == 0)
                        {
                            frmNotification notif = new frmNotification("CONTAINER IS EMPTY.");
                            notif.ShowDialog();
                        }
                        else
                        {
                            frmSaveContainer save = new frmSaveContainer(cboInvoice.Text, lblDestination.Text, Int16.Parse(cboTotalPallets.Text));
                            save.ShowDialog();
                            if (!string.IsNullOrEmpty(save.container.ContainerNumber))
                            {
                                pnlContainerInfo.Visible = true;
                                lblContainerNumber.Text = save.container.ContainerNumber;
                                lblSealNumber.Text = save.container.SealNumber;
                                if (Global.ScannedPallet.Count == Int16.Parse(cboTotalPallets.Text))
                                {
                                    btnScanCrateNo.Text = "PRINT";
                                }

                            }
                        }

                    }
                    else if (e.KeyCode == Keys.R)
                    {
                        frmUserRegistration user = new frmUserRegistration();
                        user.ShowDialog();
                    }
                    
                }
            }
            
           
            
        }

        private void btnScanCrateNo_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cboAreaCode.Text) && !string.IsNullOrEmpty(cboDeliverySite.Text) && !string.IsNullOrEmpty(cboInvoice.Text) && !string.IsNullOrEmpty(cboTotalPallets.Text))
            {
                if (btnScanCrateNo.Text == "READY TO SCAN" || btnScanCrateNo.Text == "CONTINUE SCANNING")
                {
                    if (!string.IsNullOrEmpty(cboAreaCode.Text) && !string.IsNullOrEmpty(cboDeliverySite.Text) && !string.IsNullOrEmpty(cboInvoice.Text))
                    {
                        frmScanInvoice scanInvoice = new frmScanInvoice(cboInvoice.Text, Int16.Parse(cboTotalPallets.Text));
                        scanInvoice.ShowDialog();

                        if (Global.ScannedPallet.Count == Int16.Parse(cboTotalPallets.Text))
                        {
                            btnScanCrateNo.Text = "SAVE";
                        }
                        else if (Global.ScannedPallet.Count > 0)
                        {
                            btnScanCrateNo.Text = "CONTINUE SCANNING";
                        }
                        else
                        {
                            btnScanCrateNo.Text = "READY TO SCAN";
                        }

                    }
                }
                else if (btnScanCrateNo.Text == "PRINT")
                {
                    var container = new ContainerPlan();
                    var msg = MessageBox.Show("Do you want to see the print preview?", "Print Preview", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    if (msg == System.Windows.Forms.DialogResult.Yes)
                    {
                        var preview = new frmPrintPreview(container.dsContainerInformation(lblContainerNumber.Text));
                        preview.ShowDialog();
                    }
                    else if (msg == System.Windows.Forms.DialogResult.No)
                    {
                        ReportDocument crt = new ReportDocument();
                        try
                        {
                            DataSet dsContainer = container.dsContainerInformation(lblContainerNumber.Text);
                            crt.Load(Path.Combine(Application.StartupPath, "Template", "ContainerReport.rpt"));
                            crt.SetDataSource(dsContainer);
                            crt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperA4;
                            //crt.PrintOptions.PrinterName = "FX ApeosPort C2060  - Admin";
                            crt.PrintOptions.PaperSource = CrystalDecisions.Shared.PaperSource.Upper;
                            crt.PrintToPrinter(1, false, 0, 0);
                            MessageBox.Show("Container load plan is now printing on your default printer.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    cboAreaCode.Enabled = true;
                    cboDeliverySite.Enabled = true;
                    cboInvoice.Enabled = true;
                    cboTotalPallets.Enabled = false;  
                }
                else if (btnScanCrateNo.Text == "SAVE")
                {
                    frmSaveContainer save = new frmSaveContainer(cboInvoice.Text, lblDestination.Text, Int16.Parse(cboTotalPallets.Text));
                    save.ShowDialog();
                    if (!string.IsNullOrEmpty(save.container.ContainerNumber))
                    {
                        pnlContainerInfo.Visible = true;
                        lblContainerNumber.Text = save.container.ContainerNumber;
                        lblSealNumber.Text = save.container.SealNumber;
                        btnScanCrateNo.Text = "PRINT";

                        cboAreaCode.Enabled = true;
                        cboDeliverySite.Enabled = true;
                        cboInvoice.Enabled = true;
                        cboTotalPallets.Enabled = false;  
                    }
                }
            }
            else
            {
                frmNotification notif = new frmNotification("REQUIRED FIELDS ARE MISSING.");
                notif.ShowDialog();
            }

            //cboAreaCode.Enabled = true;
            //cboDeliverySite.Enabled = true;
            //cboInvoice.Enabled = true;
            //cboTotalPallets.Enabled = true;
                       
        }

        private void dgvContainer_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            if (dgvContainer.Rows.Count > 0)
            {
                cboTotalPallets.Enabled = false;  
            }
        }

        private void dgvContainer_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (dgvContainer.Rows.Count == 0) 
            {
                cboTotalPallets.Enabled = true;
            }
              
        }

        private void dgvContainer_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && (e.ColumnIndex == 1 || e.ColumnIndex == 2))
            {
                var selectedCell = dgvContainer.CurrentCell.Value;
                if (selectedCell != null)
                {
                    string value = selectedCell.ToString();
                    var msg = MessageBox.Show(string.Format("Do you want to replace {0}?", value), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (msg == System.Windows.Forms.DialogResult.Yes)
                    {
                        var pallet = new Pallet();
                        pallet.LengthPosition = Int32.Parse(dgvContainer.Rows[e.RowIndex].Cells["LengthPosition"].Value.ToString());
                        pallet.HeightPosition = e.ColumnIndex;
                        pallet.PalletNumber = value;


                        frmScanInvoice scanInvoice = new frmScanInvoice(cboInvoice.Text, Int16.Parse(cboTotalPallets.Text), pallet);
                        scanInvoice.ShowDialog();
                    }
                }
            }
            
            
        }

      

    }
}
