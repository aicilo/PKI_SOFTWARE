﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ContainerLoadPlan.Model;

namespace ContainerLoadPlan
{
    public partial class frmSaveContainer : Form
    {
        public ContainerPlan container = new ContainerPlan();
  
        public frmSaveContainer(string invoiceNumber, string destination, int totalPallets)
        {
            InitializeComponent();

            var frmWrk = new Framework();
            frmWrk.TextBoxValidation(txtContainerNumber, "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0987654321");
            frmWrk = new Framework();
            frmWrk.TextBoxValidation(txtSealNumber, "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0987654321");
            frmWrk = new Framework();
            frmWrk.TextBoxValidation(txtIDNumber, "0987654321");


            this.ShowInTaskbar = false;
            if (container.Is_Existing_Plan(invoiceNumber))
            {
                txtContainerNumber.Text = container.ContainerNumber;
                txtSealNumber.Text = container.SealNumber;
                dtpArrived.Value = container.DateArrived;
                //dtpPulledOut.Value = container.DatePulledOut;
                dtpPulledOut.Value = DateTime.Now;

                dtpArrived.Enabled = false;
                txtContainerNumber.Enabled = false;
                txtSealNumber.Enabled = false;

            }
            else
            {
                container.InvoiceNumber = invoiceNumber;
                container.Destination = destination;
                container.TotalPallets = totalPallets;
                txtIDNumber.Focus();
            }

            
            
            
        }

        private void frmSaveContainer_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        private void txtIDNumber_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (txtIDNumber.TextLength == 6)
                {
                    var user = new User();
                    var userList = user.GetUsers();

                    var selectUser = userList.Find(x => x.IdNumber.Equals(txtIDNumber.Text));

                    if (selectUser != null)
                    {
                        lblName.Text = string.Format("{0} {1}.", selectUser.FirstName, selectUser.LastName.Substring(0,1));
                        container.ContainerNumber = txtContainerNumber.Text;
                        container.SealNumber = txtSealNumber.Text;
                        container.DateArrived = dtpArrived.Value;
                        container.DatePulledOut = dtpPulledOut.Value;
                        container.ApprovedBy = lblName.Text;

                        if (txtContainerNumber.Text.Length >= 5 && txtSealNumber.Text.Length > 0)
                        {
                            var plan = new ContainerPlan();
                            if (plan.SaveContainer(container, Global.ScannedPallet))
                            {
                                MessageBox.Show("Save successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information); 
                                this.Close();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please enter container number and seal number.","",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                            txtIDNumber.Clear();
                            lblName.Text = "";
                            if (string.IsNullOrEmpty(txtContainerNumber.Text))
                            {
                                txtContainerNumber.Focus();
                            }
                            else
                            {
                                txtSealNumber.Focus();
                            }

                        }

                    }
                    else
                    {
                        frmNotification notif = new frmNotification("ACCOUNT NOT FOUND! PLEASE TRY AGAIN.");
                        notif.ShowDialog();
                        txtIDNumber.Focus();
                        txtIDNumber.SelectAll();
                    }
                }
            }
        }

        private void frmSaveContainer_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(container.ContainerNumber))
            {
                txtIDNumber.Focus();
            }

        }

        private void txtIDNumber_TextChanged(object sender, EventArgs e)
        {
                //if (txtIDNumber.TextLength == 6)
                //{
                //    var user = new User();
                //    var userList = user.GetUsers();

                //    var selectUser = userList.Find(x => x.IdNumber.Equals(txtIDNumber.Text));

                //    if (selectUser != null)
                //    {
                //        lblName.Text = string.Format("{0} {1}.", selectUser.FirstName, selectUser.LastName.Substring(0, 1));
                //        container.ContainerNumber = txtContainerNumber.Text;
                //        container.SealNumber = txtSealNumber.Text;
                //        container.DateArrived = dtpArrived.Value;
                //        container.DatePulledOut = dtpPulledOut.Value;
                //        container.ApprovedBy = lblName.Text;

                //        if (txtContainerNumber.Text.Length >= 5 && txtSealNumber.Text.Length > 0)
                //        {
                //            var plan = new ContainerPlan();
                //            if (plan.SaveContainer(container, Global.ScannedPallet))
                //            {
                //                MessageBox.Show("Save successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //                this.Close();
                //            }
                //        }
                //        else
                //        {
                //            MessageBox.Show("Please enter container number and seal number.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                //        }

                //    }
                //    else
                //    {
                //        frmNotification notif = new frmNotification("ACCOUNT NOT FOUND! PLEASE TRY AGAIN.");
                //        notif.ShowDialog();
                //        txtIDNumber.Focus();
                //        txtIDNumber.SelectAll();
                //    }
                //}
                //else
                //{
                //    //txtIDNumber.Focus();
                //    //txtIDNumber.SelectAll();
                //}
        }
        
    }
}
