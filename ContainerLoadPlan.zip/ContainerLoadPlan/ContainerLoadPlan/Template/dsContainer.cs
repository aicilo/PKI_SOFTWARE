﻿namespace ContainerLoadPlan.Template {
    
    
    public partial class dsContainer {
    }
}
namespace ContainerLoadPlan.Template {
    
    
    public partial class dsContainer {
    }
}
