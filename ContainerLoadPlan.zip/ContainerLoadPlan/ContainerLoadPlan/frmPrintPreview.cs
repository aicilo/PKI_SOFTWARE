﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ContainerLoadPlan.Model;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;
using System.Configuration;
namespace ContainerLoadPlan
{
    public partial class frmPrintPreview : Form
    {
        public frmPrintPreview(DataSet dsContainer)
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            
            ReportDocument crt = new ReportDocument();
            try
            {
                crt.Load(Path.Combine(Application.StartupPath, "Template", "ContainerReport.rpt"));
                crt.SetDataSource(dsContainer);
                crt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperA4;
                crvLoad.ReportSource = crt;
                crvLoad.Zoom(75);
            }
            catch (Exception)
            {
              
            }
                        
        }
    }
}
