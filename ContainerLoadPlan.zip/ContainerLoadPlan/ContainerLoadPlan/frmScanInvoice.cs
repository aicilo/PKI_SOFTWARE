﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ContainerLoadPlan.Model;

namespace ContainerLoadPlan
{
    public partial class frmScanInvoice : Form
    {

        private string InvoiceNumber;
        private int TotalPallets;
        private Pallet SelectedPallet = null;
        public frmScanInvoice(string invoice, int totalPallets, Pallet pallet = null)
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            InvoiceNumber = invoice;
            TotalPallets = totalPallets;
            SelectedPallet = pallet;
        }

        private void frmScanInvoice_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        private void txtInvoice_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtInvoice_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (txtInvoice.TextLength == 11)
                {
                    if (txtInvoice.Text == InvoiceNumber)
                    {
                        frmScanPallet scan = new frmScanPallet(InvoiceNumber, TotalPallets, SelectedPallet);
                        this.Hide();
                        scan.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        frmNotification notif = new frmNotification("INCORRECT INVOICE NUMBER!");
                        notif.ShowDialog();
                        //INVALID
                    }
                    txtInvoice.Focus();
                    txtInvoice.SelectAll();
                }
                else
                {
                    txtInvoice.Focus();
                    txtInvoice.SelectAll();    
                }
            }
        }
    }
}
