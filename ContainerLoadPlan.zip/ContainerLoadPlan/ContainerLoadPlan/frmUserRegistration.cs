﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ContainerLoadPlan.Model;

namespace ContainerLoadPlan
{
    public partial class frmUserRegistration : Form
    {
        public frmUserRegistration()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            var frmWrk = new Framework();
            frmWrk.TextBoxValidation(txtIDNumber, "0987654321");
        }

   

        private void txtIDNumber_TextChanged(object sender, EventArgs e)
        {
            if (txtIDNumber.TextLength == 6)
            {
                Employee emp = new Employee();
                emp.IDNumber = txtIDNumber.Text.Trim();
                if (emp.SearchEmployee())
                {
                    User user = new User();
                    user.IdNumber = emp.IDNumber;
                    user.LastName = emp.LastName;
                    user.FirstName = emp.FirstName;
                    user.Register();
                    this.Close();
                }
                else
                {
                    frmNotification notif = new frmNotification("EMPLOYEE RECORD NOT FOUND!");
                    notif.ShowDialog();
                }

            }
            else if (txtIDNumber.TextLength > 6)
            {
                txtIDNumber.Focus();
                txtIDNumber.SelectAll();
            }
        }

        private void frmUserRegistration_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }


    }
}
