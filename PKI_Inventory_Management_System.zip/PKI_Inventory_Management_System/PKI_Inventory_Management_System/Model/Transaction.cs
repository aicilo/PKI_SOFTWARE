﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;

namespace PKI_Inventory_Management_System.Model
{
    public class Transaction : Item
    {
        public int TransactionId { get; set; }
        public string StockAction { get; set; }
        public int Quantity { get; set; }

        public string TransactFrom { get; set; }
        public string TransactTo { get; set; }
        public DateTime TransactDate { get; set; }



        public List<Transaction> GetHistory()
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = @"SELECT A.id, A.transaction_date, B.name AS `item_name`, A.quantity, B.unit_code, A.stock_action, A.transaction_to, A.transaction_from 
                                        FROM tbl_transaction AS A INNER JOIN tbl_items AS B ON A.item_id = B.id 
                                        WHERE B.site_code = @site_code ORDER BY A.transaction_date DESC;";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@site_code", MySqlDbType.VarChar).Value = SiteCode;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }


            var transaction = new List<Transaction>();
            foreach (DataRow row in dtTemp.Rows)
            {
                transaction.Add(new Transaction { TransactionId = Int32.Parse(row["id"].ToString()), TransactDate = Convert.ToDateTime(row["transaction_date"]), Name = row["item_name"].ToString(), Quantity = Int32.Parse(row["quantity"].ToString()), Unit = row["unit_code"].ToString(), StockAction = row["stock_action"].ToString(), TransactTo = row["transaction_to"].ToString(), TransactFrom = row["transaction_from"].ToString() });
            }

            return transaction;
        }



        public bool NewTransaction() 
        {
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlTransaction trans = con.BeginTransaction())
                {
                    try
                    {
                        using (MySqlCommand cmd = new MySqlCommand())
                        {
                            cmd.Connection = con;
                            cmd.CommandType = System.Data.CommandType.Text;
                            cmd.Transaction = trans;

                            cmd.CommandText = @"INSERT INTO tbl_transaction (item_id, quantity, stock_action, transaction_to, transaction_from, transaction_date) 
                                                VALUES (@item_id, @quantity, @stock_action, @transaction_to, @transaction_from, NOW());";
                            cmd.Parameters.Add("@item_id", MySqlDbType.VarChar).Value = Id;
                            cmd.Parameters.Add("@quantity", MySqlDbType.VarChar).Value = Quantity;
                            cmd.Parameters.Add("@stock_action", MySqlDbType.VarChar).Value = StockAction;
                            cmd.Parameters.Add("@transaction_to", MySqlDbType.VarChar).Value = TransactTo;
                            cmd.Parameters.Add("@transaction_from", MySqlDbType.VarChar).Value = TransactFrom;
                            cmd.ExecuteNonQuery();
                        }

                        using (MySqlCommand cmd = new MySqlCommand())
                        {
                            cmd.Connection = con;
                            cmd.CommandType = System.Data.CommandType.Text;
                            cmd.Transaction = trans;
                            if (StockAction == "STOCK ISSUE" || StockAction == "DAMAGE" || StockAction == "LOSS")
                            {
                                cmd.CommandText = "UPDATE tbl_items SET stock = stock - @quantity WHERE id = @item_id";
                            }
                            else
                            {
                                cmd.CommandText = "UPDATE tbl_items SET stock = stock + @quantity WHERE id = @item_id";
                            }
                            cmd.Parameters.Add("@quantity", MySqlDbType.VarChar).Value = Quantity;
                            cmd.Parameters.Add("@item_id", MySqlDbType.VarChar).Value = Id;

                            cmd.ExecuteNonQuery();
                        }

                        trans.Commit();
                        return true;
                    }
                    catch (MySqlException ex)
                    {

                        trans.Rollback();
                        MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }

                con.Close();
            }


            return false;
        }


        public bool NewTransaction(List<Transaction> transac)
        {
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlTransaction trans = con.BeginTransaction())
                {
                    try
                    {
                        foreach (var tran in transac)
                        {
                            using (MySqlCommand cmd = new MySqlCommand())
                            {
                                cmd.Connection = con;
                                cmd.CommandType = System.Data.CommandType.Text;
                                cmd.Transaction = trans;

                                cmd.CommandText = @"INSERT INTO tbl_transaction (item_id, quantity, stock_action, transaction_to, transaction_from, transaction_date) 
                                                VALUES (@item_id, @quantity, @stock_action, @transaction_to, @transaction_from, NOW());";
                                cmd.Parameters.Add("@item_id", MySqlDbType.VarChar).Value = tran.Id;
                                cmd.Parameters.Add("@quantity", MySqlDbType.VarChar).Value = tran.Quantity;
                                cmd.Parameters.Add("@stock_action", MySqlDbType.VarChar).Value = tran.StockAction;
                                cmd.Parameters.Add("@transaction_to", MySqlDbType.VarChar).Value = tran.TransactTo;
                                cmd.Parameters.Add("@transaction_from", MySqlDbType.VarChar).Value = tran.TransactFrom;
                                cmd.ExecuteNonQuery();
                            }

                            using (MySqlCommand cmd = new MySqlCommand())
                            {
                                cmd.Connection = con;
                                cmd.CommandType = System.Data.CommandType.Text;
                                cmd.Transaction = trans;
                                if (tran.StockAction == "STOCK ISSUE" || tran.StockAction == "DAMAGE" || tran.StockAction == "LOSS")
                                {
                                    cmd.CommandText = "UPDATE tbl_items SET stock = stock - @quantity WHERE id = @item_id";
                                }
                                else
                                {
                                    cmd.CommandText = "UPDATE tbl_items SET stock = stock + @quantity WHERE id = @item_id";
                                }
                                cmd.Parameters.Add("@quantity", MySqlDbType.VarChar).Value = tran.Quantity;
                                cmd.Parameters.Add("@item_id", MySqlDbType.VarChar).Value = tran.Id;

                                cmd.ExecuteNonQuery();
                            }
                        }
                        

                        trans.Commit();
                        return true;
                    }
                    catch (MySqlException ex)
                    {

                        trans.Rollback();
                        MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }

                con.Close();
            }


            return false;
        }

    }
}
