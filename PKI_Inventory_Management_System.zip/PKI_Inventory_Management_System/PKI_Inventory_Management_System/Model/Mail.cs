﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Net;
using MySql.Data.MySqlClient;

namespace PKI_Inventory_Management_System.Model
{
    public class Mail
    {

        

        private void Send(string sendTo, string subject, string message) 
        {
            using (var client = new SmtpClient("edi-mail.pki.com.ph"))
            {
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                var mail = new MailMessage();
                mail.From = new MailAddress("no-reply@pki.lip","PKI Inventory Management System");
                mail.To.Add(sendTo.ToLower());
                mail.IsBodyHtml = true;
                mail.Subject = subject;
                mail.Body = message;
                client.Send(mail);
            }
        }

        public void RequestVerificationCode(string idNumber, string emailAddress)
        {
            Random random = new Random();
            const string chars = "0123456789";
            string code = new string(Enumerable.Repeat(chars, 6).Select(s => s[random.Next(s.Length)]).ToArray());

            string msg = "<span style='font-size:11.0pt;font-family:Times New Roman;'>";
            msg += "Hi there!<br><br>";
            msg += "Please enter this email verification code on PKI Inventory Management System<br>";
            msg += "to complete the verification process.<br><br>";
            msg += "If you did not request this Email verification code on PKI Inventory Management System, you may ignore this email.<br></span><br>";
            msg += string.Format("<span style='font-size:18.0pt;font-family:Times New Roman;color:#008B8B';><b>{0}</b></span>", code);

            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = "INSERT INTO tbl_verification (`code`, `id_number`, `date_request`) VALUES (@code, @id_number, NOW());";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@code", MySqlDbType.VarChar).Value = code;
                    cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = idNumber;
                    cmd.ExecuteNonQuery();
                    Send(emailAddress, "Verification code for forgot password", msg);
                }
                con.Close();
            }
        }

        public bool CorrectVerificationCode(string idNumber, string code)
        {
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = "SELECT * FROM tbl_verification WHERE code = @code AND id_number = @id_number ORDER BY date_request LIMIT 1";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@code", MySqlDbType.VarChar).Value = code;
                    cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = idNumber;
                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            return true;
                        }  
                    }
                    
                }
                con.Close();
            }

            return false;
        }

        public void LowStockAlertNotification(List<Item> items)
        {
            var checkItem = new Item();
            foreach (var item in items)
            {
                checkItem = item.GetLowStockByItemId(item.Id);
                if (checkItem != null)
	            {
                    string msg = "<span style='font-size:11.0pt;font-family:Times New Roman;'>";
                    msg += "Hello,<br><br>";
                    msg += "You receive this alert because one of your item current stock is lower than the<br>";
                    msg += "\"" + "Low Stock Alert" + "\"" + " threshold you have set.<br><br>";
                    msg += "<b><span style='font-size:11.0pt;font-family:Times New Roman;'>Item Name:</span></b> " + checkItem.Name.ToString() + "<br>";
                    msg += "<b><span style='font-size:11.0pt;font-family:Times New Roman;'>Current Stock:</span></b> " + string.Format("{0} {1}.", checkItem.Stock.ToString(), checkItem.Unit.ToLower()) + "<br>";
                    msg += "<b><span style='font-size:11.0pt;font-family:Times New Roman;'>Low Stock Alert:</span></b> " + string.Format("{0} {1}.", checkItem.LowStockAlert.ToString(), checkItem.Unit.ToLower()) + "<br>";
                    msg += "<br><br><br>This is a system-generated e-mail. Please do not reply.";

                    var user = new User();
                    foreach (var mail in user.GetActiveUser(Global.SelectedSite.Code))
                    {
                        Send(mail.EmailAddress, "Low Stock Alert Notification", msg);
                    } 
	            } 
               
            }
            
        }


    }
}
