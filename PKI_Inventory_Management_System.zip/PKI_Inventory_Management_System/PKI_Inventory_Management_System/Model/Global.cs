﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.View;
using System.Runtime.InteropServices;

namespace PKI_Inventory_Management_System.Model
{
    public class Global
    {
        public static frmContainer Container = new frmContainer();
        public static DataGridView RequestItems = new DataGridView();

        public static User CurrentUser = new User();
        public static List<Site> CurrentUserSitesList = new List<Site>();
        public static Site SelectedSite = new Site();
        public static List<Item> ItemsList = new List<Item>();
        public static List<Unit> UnitsList = new List<Unit>();
        public static List<Category> CategoriesList = new List<Category>();

        public static List<Item> SelectedItems = new List<Item>();

        public static List<Role> Roles = new List<Role>();

        [DllImport("user32.dll", EntryPoint = "SendMessage")]
        static extern IntPtr SendMessage(IntPtr hWnd, int msg, int wParam, [MarshalAs(UnmanagedType.LPWStr)] string IParam);
        private const int EM_SETCUEBANNER = 0x1501; // for TextBox
        private const int CB_SETCUEBANNER = 0x1703; // 'for ComboBox
        public static void WaterMark(string strMark, TextBox txtBox)
        {
            SendMessage(txtBox.Handle, EM_SETCUEBANNER, 1, strMark);
        }
        public static void WaterMark(string strMark, ComboBox cboBox)
        {
            SendMessage(cboBox.Handle, CB_SETCUEBANNER, 1, strMark);
        }
        private static string _validString = string.Empty;
        public static void TextBoxValidation(System.Windows.Forms.TextBox textBox, string validString)
        {
            _validString = validString;
            textBox.KeyPress += TextValidation;
        }
        private static void TextValidation(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
                e.Handled = (_validString.IndexOf(e.KeyChar) == -1);
        }




    }

 }
