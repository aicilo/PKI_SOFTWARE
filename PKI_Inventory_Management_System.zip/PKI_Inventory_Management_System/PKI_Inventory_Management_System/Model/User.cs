﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;
using System.Windows.Forms;



namespace PKI_Inventory_Management_System.Model
{
    public class User : Employee
    {
        public string Password { get; set; }
        public string EmailAddress { get; set; }
        public bool Active { get; set; }
        public DateTime DateRegistered { get; set; }
        public int UserRole { get; set; }
        public int AccessSites {get; private set;}

        

        public bool Login()
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {           
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = "SELECT id_number, full_name, email_address FROM tbl_users WHERE `id_number` = @id_number AND `password` = @password;";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@id_number",MySqlDbType.VarChar).Value = IDNumber;
                    cmd.Parameters.Add("@password",MySqlDbType.VarChar).Value = Password;

                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            if (dtTemp.Rows.Count == 1)
            {
                var user = new User();
                user.IDNumber = dtTemp.Rows[0]["id_number"].ToString();
                user.FullName = dtTemp.Rows[0]["full_name"].ToString();
                user.EmailAddress = dtTemp.Rows[0]["email_address"].ToString();
                Global.CurrentUser = user;
                return true;
            }
            return false;
        }

        public bool CheckUserExist()
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB"))) 
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand()) 
                {
                    cmd.CommandText = "SELECT id_number, full_name, email_address FROM tbl_users WHERE `id_number` = @id_number";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = IDNumber;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            if (dtTemp.Rows.Count == 1)
            {
                IDNumber = dtTemp.Rows[0]["id_number"].ToString();
                FullName = dtTemp.Rows[0]["full_name"].ToString();
                EmailAddress = dtTemp.Rows[0]["email_address"].ToString();
                return true;
            }
            return false;
        }

        public bool ChangePassword() 
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
                {
                    con.Open();
                    using (MySqlCommand cmd = new MySqlCommand())
                    {
                        cmd.CommandText = "UPDATE tbl_users SET `password` = @password WHERE id_number = @id_number;";
                        cmd.Connection = con;
                        cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = IDNumber;
                        cmd.Parameters.Add("@password", MySqlDbType.VarChar).Value = Password;
                        cmd.ExecuteNonQuery();
                    }
                    con.Close();
                    return true;
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
           
        }

        public List<User> GetActiveUser(string site_code)
        {
            var users = new List<User>();
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = @"SELECT A.id_number, B.full_name, B.email_address FROM tbl_users_site AS A
                                        INNER JOIN tbl_users AS B ON A.id_number = B.id_number
                                        WHERE A.site_code = @site_code AND A.role = 1 AND A.active = 1
                                        AND B.email_address IS NOT NULL;";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@site_code", MySqlDbType.VarChar).Value = site_code;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            foreach (DataRow row in dtTemp.Rows)
            {
                users.Add(new User() { IDNumber = row["id_number"].ToString(), FullName = row["full_name"].ToString(), EmailAddress = row["email_address"].ToString() });
            }

            return users;
        }


        public List<User> Users() 
        {
            var users = new List<User>();
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = @"SELECT A.id_number, A.full_name, A.email_address, A.date_registered, COUNT(B.id_number) AS `access_sites` 
                                      FROM tbl_users AS A LEFT JOIN tbl_users_site AS B ON A.id_number = B.id_number GROUP BY B.id_number;";
                    cmd.Connection = con;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }

            foreach (DataRow row in dtTemp.Rows)
            {
                users.Add(new User() { IDNumber = row["id_number"].ToString(), FullName = row["full_name"].ToString(), EmailAddress = row["email_address"].ToString(), DateRegistered = Convert.ToDateTime(row["date_registered"].ToString()), AccessSites = int.Parse(row["access_sites"].ToString()) });
            }

            return users;
        }

        public bool AddUser() 
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
                {
                    con.Open();
                    using (MySqlCommand cmd = new MySqlCommand())
                    {
                        cmd.CommandText = @"INSERT INTO `tbl_users` (`id_number`,`password`,`full_name`,`email_address`,`date_registered`)
                                            VALUES (@id_number,@password,@full_name,@email_address,NOW())";
                        cmd.Connection = con;
                        cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = IDNumber;
                        cmd.Parameters.Add("@password", MySqlDbType.VarChar).Value = IDNumber;
                        cmd.Parameters.Add("@full_name", MySqlDbType.VarChar).Value = FullName;
                        cmd.Parameters.Add("@email_address", MySqlDbType.VarChar).Value = EmailAddress;
                        cmd.ExecuteNonQuery();
                    }
                    con.Close();
                }
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return false;
        }


    }
}
