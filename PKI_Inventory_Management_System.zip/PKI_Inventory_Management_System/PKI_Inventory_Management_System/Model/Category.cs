﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PKI_Inventory_Management_System.Model
{
    public class Category
    {
        public string Code { get; set; }
        public string Description { get; set; }

        public void GetCategories()
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = "SELECT code, description FROM tbl_categories ORDER BY description ASC;";
                    cmd.Connection = con;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }

            var category = new List<Category>();
            foreach (DataRow row in dtTemp.Rows)
            {
                category.Add(new Category { Code = row["code"].ToString(), Description = row["description"].ToString() });
            }

            Global.CategoriesList = category;
        }




        public string GenerateCode() 
        {
            string code = string.Empty;
            try
            {
                DataTable dtTemp = new DataTable();
                using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
                {
                    con.Open();
                    using (MySqlCommand cmd = new MySqlCommand())
                    {
                        cmd.CommandText = "SELECT CASE WHEN MAX(code) IS NULL THEN '001' ELSE LPAD(MAX(code) + 1,'3',0) END AS `auto_generate_code` FROM tbl_categories;";
                        cmd.Connection = con;
                        using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                        {
                            da.Fill(dtTemp);
                        }
                    }
                    con.Close();
                }
                code = dtTemp.Rows[0]["auto_generate_code"].ToString();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message,"",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }


            return code;
        }

        public bool AddCategory() 
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
                {
                    con.Open();
                    using (MySqlCommand cmd = new MySqlCommand())
                    {
                        cmd.CommandText = "INSERT INTO tbl_categories (`code`,`description`,`added_by`,`date_added`) VALUES (@code,@description,@added_by,NOW());";
                        cmd.Connection = con;
                        cmd.Parameters.Add("@code", MySqlDbType.VarChar).Value = GenerateCode();
                        cmd.Parameters.Add("@description", MySqlDbType.VarChar).Value = Description;
                        cmd.Parameters.Add("@added_by", MySqlDbType.VarChar).Value = Global.CurrentUser.FullName;
                        cmd.ExecuteNonQuery();
                    }
                    con.Close();
                }
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return false;
        }

    }
}
