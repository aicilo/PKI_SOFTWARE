﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace PKI_Inventory_Management_System.Model
{
    public class Role
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public List<Role> AllRoles()
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = @"SELECT id, description FROM tbl_role;";
                    cmd.Connection = con;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            var roles = new List<Role>();
            foreach (DataRow row in dtTemp.Rows)
            {
                roles.Add(new Role { Id = int.Parse(row["id"].ToString()), Description = row["description"].ToString() });
            }

            return roles;
        }
    }
}
