﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;

namespace PKI_Inventory_Management_System.Model
{
    public class Item
    {
        public int Id { get; set; }
        public string SiteCode { get; set; }
        public string Barcode { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public string Unit { get; set; }
        public int Stock { get; set; }
        public int LowStockAlert { get; set; }
        public bool Active { get; set; }


        public string GenerateBarcode()
        {
            Random random = new Random();
            const string chars = "0123456789";
            string code = new string(Enumerable.Repeat(chars, 13).Select(s => s[random.Next(s.Length)]).ToArray());
            return code;
        }

        public void GetItems()
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    //cmd.CommandText = "SELECT A.id, A.site_code, A.barcode, A.`name`, A.description, B.description AS `unit_code`, A.stock, A.low_stock_alert, A.active FROM tbl_items AS A LEFT JOIN tbl_units AS B ON A.unit_code = B.`code` WHERE A.site_code = @site_code;";
                    cmd.CommandText = @"SELECT B.id, B.site_code, B.name, CASE WHEN D.description IS NULL THEN 'NOT SET' ELSE D.description END AS `category`, 
                                        B.description, C.description AS `unit`, B.stock, B.low_stock_alert, 
                                        B.barcode, B.active, DATE_FORMAT(B.date_added,'%Y-%m-%d %l:%i %p') AS `date_added`
                                        FROM tbl_item_categories AS A
                                        RIGHT JOIN tbl_items AS B ON A.item_id = B.id 
                                        LEFT JOIN tbl_units AS C ON B.unit_code = C.code
                                        LEFT JOIN tbl_categories AS D ON A.category_code = D.code
                                        WHERE B.site_code = @site_code ORDER BY B.name;";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@site_code", MySqlDbType.VarChar).Value = SiteCode;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }

            var items = new List<Item>();
            foreach (DataRow row in dtTemp.Rows)
            {
                items.Add(new Item { Id = Convert.ToInt32(row["id"].ToString()), SiteCode = row["site_code"].ToString(), Barcode = row["barcode"].ToString(), Name = row["name"].ToString(), Category = row["category"].ToString(), Description = row["description"].ToString(), Unit = row["unit"].ToString(), Stock = Convert.ToInt32(row["stock"].ToString()), LowStockAlert = Convert.ToInt32(row["low_stock_alert"].ToString()), Active = Convert.ToBoolean(row["active"]) });
            }
            
            Global.ItemsList = items;
        }

        public void AddNewItem()
        {
            if (BarcodeExist() == false)
            {
                using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
                {
                    con.Open();
                    using (MySqlCommand cmd = new MySqlCommand())
                    {
                        cmd.CommandText = "INSERT INTO tbl_items (site_code, barcode, name, description, unit_code, stock, low_stock_alert, active, date_added) VALUES (@site_code, @barcode, @name, @description, @unit_code, @stock, @low_stock_alert, @active, NOW());";
                        cmd.Connection = con;
                        cmd.Parameters.Add("@site_code", MySqlDbType.VarChar).Value = SiteCode;
                        cmd.Parameters.Add("@barcode", MySqlDbType.VarChar).Value = Barcode;
                        cmd.Parameters.Add("@name", MySqlDbType.VarChar).Value = Name;
                        cmd.Parameters.Add("@description", MySqlDbType.VarChar).Value = (Description.Trim() == string.Empty) ? null : Description.Trim();
                        cmd.Parameters.Add("@unit_code", MySqlDbType.VarChar).Value = Unit;
                        cmd.Parameters.Add("@stock", MySqlDbType.Int32).Value = Stock;
                        cmd.Parameters.Add("@low_stock_alert", MySqlDbType.Int32).Value = LowStockAlert;
                        cmd.Parameters.Add("@active", MySqlDbType.Int16).Value = 1;
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("New item has been added successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    con.Close();
                }
            }
            
        }

        public bool BarcodeExist()
        {
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = "SELECT * FROM tbl_items WHERE site_code = @site_code AND barcode = @barcode;";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@site_code", MySqlDbType.VarChar).Value = SiteCode;
                    cmd.Parameters.Add("@barcode", MySqlDbType.VarChar).Value = Barcode;
                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            MessageBox.Show("Barcode is already exist.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return true;
                        }
                    }

                }
                con.Close();
            }
            return false;
        }

        public Item GetLowStockByItemId(int itemId)
        {
            var item = new Item();
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = @"SELECT site_code, barcode, name, unit_code, stock, low_stock_alert 
                                        FROM tbl_items WHERE stock < low_stock_alert AND id = @itemId;";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@itemId", MySqlDbType.VarChar).Value = itemId;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            if (dtTemp.Rows.Count == 1)
            {
                item.SiteCode = dtTemp.Rows[0]["site_code"].ToString();
                item.Barcode = dtTemp.Rows[0]["barcode"].ToString();
                item.Name = dtTemp.Rows[0]["name"].ToString();
                item.Unit = dtTemp.Rows[0]["unit_code"].ToString();
                item.Stock = Int32.Parse(dtTemp.Rows[0]["stock"].ToString());
                item.LowStockAlert = Int32.Parse(dtTemp.Rows[0]["low_stock_alert"].ToString());
            }
            else 
            {
                item = null;
            }
            return item;

        }
    }
}
