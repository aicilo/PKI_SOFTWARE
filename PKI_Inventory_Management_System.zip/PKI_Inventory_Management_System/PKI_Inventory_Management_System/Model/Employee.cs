﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace PKI_Inventory_Management_System.Model
{
    public class Employee
    {
        public string IDNumber { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }

        public string FullName { get; set; }
        public string Section { get; set; }
        public string Status { get; set; } //Regular, Project etc..

    
        public void GetEmployeeInformation()
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("PIS")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = @"SELECT L_NAME, F_NAME, EMP_NAME, SECT_DESC, EMPL_DESC  FROM dbemployee.tblemployee WHERE NEW_IDNO = @id_number;";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = IDNumber;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            if (dtTemp.Rows.Count == 1)
            {
                LastName = dtTemp.Rows[0]["L_NAME"].ToString();
                FirstName = dtTemp.Rows[0]["F_NAME"].ToString();

                FullName = dtTemp.Rows[0]["EMP_NAME"].ToString();
                Section = dtTemp.Rows[0]["SECT_DESC"].ToString();
                Status = dtTemp.Rows[0]["EMPL_DESC"].ToString();
            }
        }

    }
}
