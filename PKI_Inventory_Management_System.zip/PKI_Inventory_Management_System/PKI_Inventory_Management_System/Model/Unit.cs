﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace PKI_Inventory_Management_System.Model
{
    public class Unit
    {
        public string Code { get; set; }
        public string Description { get; set; }

        public void GetUnits()
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = "SELECT code, description FROM tbl_units ORDER BY description ASC;";
                    cmd.Connection = con;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }

            var units = new List<Unit>();
            foreach (DataRow row in dtTemp.Rows)
            {
                units.Add(new Unit { Code = row["code"].ToString(), Description = row["description"].ToString()});
            }

            Global.UnitsList = units;
        }

    }
}
