﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;


namespace PKI_Inventory_Management_System.Model
{
    public class DatabaseAccess
    {
        //public static string GetConnectionStringByProvider(string providerName)
        //{
        //    string returnValue = null;

        //    ConnectionStringSettingsCollection settings = ConfigurationManager.ConnectionStrings; 
        //    if (settings != null)
        //    {
        //        foreach (ConnectionStringSettings cs in settings)
        //        {
        //            if (cs.ProviderName == providerName)
        //                returnValue = cs.ConnectionString;
        //            break;
        //        }
        //    }
        //    return returnValue;
        //}
        public static string GetConnectionStringByName(string name)
        {
            string returnValue = null;
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings[name];
            if (settings != null) 
            {
                returnValue = settings.ConnectionString;            
            }
            return returnValue;
        }
    }
}
