﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;


namespace PKI_Inventory_Management_System.Model
{
    public class Site : User
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string SectionCode { get; set; }
        public int UsersCount { get; private set; }
        public int IsActive { get; set; }

     

        public void GetUserSites(string idNumber)
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    //cmd.CommandText = "SELECT B.site_code, A.`name` AS `site_name`, A.description, A.section_code, B.role FROM tbl_sites AS A INNER JOIN tbl_users_site AS B ON A.`code` = B.site_code WHERE B.id_number = @id_number AND B.active = 1;";
                    cmd.CommandText = "SELECT B.site_code, A.`name` AS `site_name`, A.description, A.section_code, C.description AS `section_description`, B.role FROM tbl_sites AS A INNER JOIN tbl_users_site AS B ON A.`code` = B.site_code LEFT JOIN tbl_sections AS C ON C.code =  A.section_code WHERE B.id_number = @id_number AND B.active = 1;";
                    
                    cmd.Connection = con;
                    cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = idNumber;

                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
                        
            var sites = new List<Site>();
            foreach (DataRow row in dtTemp.Rows)
            {
                sites.Add(new Site { Code = row["site_code"].ToString(), Name = row["site_name"].ToString(), Description = row["description"].ToString(), SectionCode = row["section_code"].ToString(), Section = row["section_description"].ToString(), UserRole = Convert.ToInt16(row["role"].ToString()) });                
            }

            Global.CurrentUserSitesList = sites;
        }

        public List<Site> SitesInformation()
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = @"SELECT A.code, A.name, A.description, A.section_code, C.description AS `section_description`, COUNT(B.id_number) AS `users` FROM tbl_sites AS A
                                        LEFT JOIN tbl_users_site AS B ON A.code = B.site_code LEFT JOIN tbl_sections AS C ON A.section_code = C.code
                                        GROUP BY A.code ORDER BY A.code, A.name;";
                    cmd.Connection = con;

                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }
            var sites = new List<Site>();
            foreach (DataRow row in dtTemp.Rows)
            {
                sites.Add(new Site { Code = row["code"].ToString(), Name = row["name"].ToString(), Description = row["description"].ToString(), SectionCode = row["section_code"].ToString(), Section = row["section_description"].ToString(), UsersCount = Convert.ToInt16(row["users"].ToString()) });
            }

            return sites;
        }



        public List<Site> UsersSiteList()
        {
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = @"SELECT site_code, role, active FROM tbl_users_site WHERE id_number = @id_number;";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = IDNumber;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();

            }
            var user_sites = new List<Site>();

            foreach (DataRow row in dtTemp.Rows)
            {
                user_sites.Add(new Site { Code = row["site_code"].ToString(), UserRole = int.Parse(row["role"].ToString()), IsActive = Convert.ToInt16(row["active"].ToString()) });
            }

            return user_sites;
        }

        public void AddUserSite()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
                {
                    con.Open();
                    using (MySqlCommand cmd = new MySqlCommand())
                    {
                        cmd.CommandText = "INSERT INTO tbl_users_site (`id_number`,`site_code`,`role`,`active`) VALUES (@id_number,@site_code,@role,1);";
                        cmd.Connection = con;
                        cmd.Parameters.Add("@id_number", MySqlDbType.VarChar).Value = IDNumber;
                        cmd.Parameters.Add("@site_code", MySqlDbType.VarChar).Value = Code;
                        cmd.Parameters.Add("@role", MySqlDbType.VarChar).Value = UserRole;
                        cmd.ExecuteNonQuery();
                    }
                    con.Close();
                }
            }
            catch (MySqlException ex)
            {
                 MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }

        public bool CreateSite() 
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
                {
                    con.Open();
                    using (MySqlCommand cmd = new MySqlCommand())
                    {
                        cmd.CommandText = @"INSERT INTO `tbl_sites` (`code`,`name`,`description`,`section_code`,`created_by`,`date_created`)
                                            VALUES (@code,@name,@description,@section_code,@created_by,NOW());";
                        cmd.Connection = con;
                        cmd.Parameters.Add("@code", MySqlDbType.VarChar).Value = GetAutoCode(SectionCode);
                        cmd.Parameters.Add("@name", MySqlDbType.VarChar).Value = Name;
                        cmd.Parameters.Add("@description", MySqlDbType.VarChar).Value = Description;

                        cmd.Parameters.Add("@section_code", MySqlDbType.VarChar).Value = SectionCode;
                        cmd.Parameters.Add("@created_by", MySqlDbType.VarChar).Value = Global.CurrentUser.FullName;

                        cmd.ExecuteNonQuery();
                    }
                    con.Close();
                }
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return false;

        }

        public string GetAutoCode(string SectionCode)
        {
            string code = string.Empty;
            try
            {
                DataTable dtTemp = new DataTable();
                using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
                {
                    con.Open();
                    using (MySqlCommand cmd = new MySqlCommand())
                    {
                        cmd.CommandText = @"SELECT CASE WHEN MAX(code) IS NULL THEN CONCAT(@section_code,'01') ELSE CONCAT(@section_code, LPAD(SUBSTRING(code, LENGTH(code), 2) + 1, 2,'0')) END AS `auto_generate_code` FROM tbl_sites WHERE section_code = @section_code";
                        cmd.Connection = con;
                        cmd.Parameters.Add("@section_code", MySqlDbType.VarChar).Value = SectionCode;
                        using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                        {
                            da.Fill(dtTemp);
                        }
                    }
                    con.Close();
                }
                code = dtTemp.Rows[0]["auto_generate_code"].ToString();
            }
            catch (Exception ex)
            {
                 MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return code;
        }
    }
}
