﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;


namespace PKI_Inventory_Management_System.Model
{
    public class Section
    {
        public string Code { get; set; }
        public string Description { get; set; }

        public List<Section> GetSections()
        {
            
            DataTable dtTemp = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DatabaseAccess.GetConnectionStringByName("MYDB")))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = "SELECT code, description FROM tbl_sections ORDER BY description;";
                    cmd.Connection = con;
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dtTemp);
                    }
                }
                con.Close();
            }

            var sections = new List<Section>();
            foreach (DataRow row in dtTemp.Rows)
            {
                sections.Add(new Section { Code = row["code"].ToString(), Description = row["description"].ToString() });
            }

            return sections;
        }
    }
}
