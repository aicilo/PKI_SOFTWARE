﻿namespace PKI_Inventory_Management_System.View
{
    partial class frmContainer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmContainer));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.picAskQuestion = new System.Windows.Forms.PictureBox();
            this.picLogout = new System.Windows.Forms.PictureBox();
            this.pnlBody = new System.Windows.Forms.Panel();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.pnlControlAccess = new System.Windows.Forms.Panel();
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pnlSettings = new System.Windows.Forms.Panel();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnUsersAccount = new System.Windows.Forms.Button();
            this.pnlReports = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnInformationSites = new System.Windows.Forms.Button();
            this.pnlManageItems = new System.Windows.Forms.Panel();
            this.frmStocks = new System.Windows.Forms.Button();
            this.btnItems = new System.Windows.Forms.Button();
            this.btnCategories = new System.Windows.Forms.Button();
            this.btnManageItems = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.picShowAndHide = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAskQuestion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogout)).BeginInit();
            this.pnlControlAccess.SuspendLayout();
            this.pnlMenu.SuspendLayout();
            this.pnlSettings.SuspendLayout();
            this.pnlReports.SuspendLayout();
            this.pnlManageItems.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picShowAndHide)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.picAskQuestion);
            this.panel1.Controls.Add(this.picLogout);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1097, 45);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(596, 36);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // picAskQuestion
            // 
            this.picAskQuestion.Dock = System.Windows.Forms.DockStyle.Right;
            this.picAskQuestion.Image = ((System.Drawing.Image)(resources.GetObject("picAskQuestion.Image")));
            this.picAskQuestion.Location = new System.Drawing.Point(1007, 0);
            this.picAskQuestion.Name = "picAskQuestion";
            this.picAskQuestion.Size = new System.Drawing.Size(45, 45);
            this.picAskQuestion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picAskQuestion.TabIndex = 1;
            this.picAskQuestion.TabStop = false;
            this.picAskQuestion.DoubleClick += new System.EventHandler(this.picAskQuestion_DoubleClick);
            // 
            // picLogout
            // 
            this.picLogout.Dock = System.Windows.Forms.DockStyle.Right;
            this.picLogout.Image = ((System.Drawing.Image)(resources.GetObject("picLogout.Image")));
            this.picLogout.Location = new System.Drawing.Point(1052, 0);
            this.picLogout.Name = "picLogout";
            this.picLogout.Size = new System.Drawing.Size(45, 45);
            this.picLogout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picLogout.TabIndex = 0;
            this.picLogout.TabStop = false;
            // 
            // pnlBody
            // 
            this.pnlBody.BackColor = System.Drawing.Color.White;
            this.pnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBody.Location = new System.Drawing.Point(260, 45);
            this.pnlBody.Name = "pnlBody";
            this.pnlBody.Size = new System.Drawing.Size(837, 587);
            this.pnlBody.TabIndex = 2;
            // 
            // imageList
            // 
            this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList.Images.SetKeyName(0, "Left");
            this.imageList.Images.SetKeyName(1, "Right");
            // 
            // pnlControlAccess
            // 
            this.pnlControlAccess.Controls.Add(this.pnlMenu);
            this.pnlControlAccess.Controls.Add(this.panel4);
            this.pnlControlAccess.Controls.Add(this.panel2);
            this.pnlControlAccess.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlControlAccess.Location = new System.Drawing.Point(0, 45);
            this.pnlControlAccess.Name = "pnlControlAccess";
            this.pnlControlAccess.Size = new System.Drawing.Size(260, 587);
            this.pnlControlAccess.TabIndex = 3;
            // 
            // pnlMenu
            // 
            this.pnlMenu.AutoScroll = true;
            this.pnlMenu.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pnlMenu.Controls.Add(this.btnLogOut);
            this.pnlMenu.Controls.Add(this.panel7);
            this.pnlMenu.Controls.Add(this.pnlSettings);
            this.pnlMenu.Controls.Add(this.btnSettings);
            this.pnlMenu.Controls.Add(this.btnUsersAccount);
            this.pnlMenu.Controls.Add(this.pnlReports);
            this.pnlMenu.Controls.Add(this.btnReports);
            this.pnlMenu.Controls.Add(this.btnInformationSites);
            this.pnlMenu.Controls.Add(this.pnlManageItems);
            this.pnlMenu.Controls.Add(this.btnManageItems);
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMenu.Location = new System.Drawing.Point(0, 29);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(231, 558);
            this.pnlMenu.TabIndex = 2;
            // 
            // btnLogOut
            // 
            this.btnLogOut.BackColor = System.Drawing.Color.Teal;
            this.btnLogOut.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLogOut.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.ForeColor = System.Drawing.Color.White;
            this.btnLogOut.Location = new System.Drawing.Point(0, 712);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.btnLogOut.Size = new System.Drawing.Size(214, 51);
            this.btnLogOut.TabIndex = 10;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogOut.UseVisualStyleBackColor = false;
            // 
            // panel7
            // 
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(0, 763);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(214, 44);
            this.panel7.TabIndex = 9;
            // 
            // pnlSettings
            // 
            this.pnlSettings.Controls.Add(this.button12);
            this.pnlSettings.Controls.Add(this.button13);
            this.pnlSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSettings.Location = new System.Drawing.Point(0, 597);
            this.pnlSettings.Name = "pnlSettings";
            this.pnlSettings.Size = new System.Drawing.Size(214, 115);
            this.pnlSettings.TabIndex = 8;
            this.pnlSettings.Visible = false;
            // 
            // button12
            // 
            this.button12.Dock = System.Windows.Forms.DockStyle.Top;
            this.button12.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(0, 51);
            this.button12.Name = "button12";
            this.button12.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.button12.Size = new System.Drawing.Size(214, 51);
            this.button12.TabIndex = 4;
            this.button12.Text = "Change Password";
            this.button12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Dock = System.Windows.Forms.DockStyle.Top;
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(0, 0);
            this.button13.Name = "button13";
            this.button13.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.button13.Size = new System.Drawing.Size(214, 51);
            this.button13.TabIndex = 3;
            this.button13.Text = "Account Profile";
            this.button13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button13.UseVisualStyleBackColor = true;
            // 
            // btnSettings
            // 
            this.btnSettings.BackColor = System.Drawing.Color.Teal;
            this.btnSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSettings.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettings.ForeColor = System.Drawing.Color.White;
            this.btnSettings.Location = new System.Drawing.Point(0, 546);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.btnSettings.Size = new System.Drawing.Size(214, 51);
            this.btnSettings.TabIndex = 7;
            this.btnSettings.Text = "Settings";
            this.btnSettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettings.UseVisualStyleBackColor = false;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnUsersAccount
            // 
            this.btnUsersAccount.BackColor = System.Drawing.Color.Teal;
            this.btnUsersAccount.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnUsersAccount.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.btnUsersAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUsersAccount.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUsersAccount.ForeColor = System.Drawing.Color.White;
            this.btnUsersAccount.Location = new System.Drawing.Point(0, 495);
            this.btnUsersAccount.Name = "btnUsersAccount";
            this.btnUsersAccount.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.btnUsersAccount.Size = new System.Drawing.Size(214, 51);
            this.btnUsersAccount.TabIndex = 6;
            this.btnUsersAccount.Text = "Users Account";
            this.btnUsersAccount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUsersAccount.UseVisualStyleBackColor = false;
            this.btnUsersAccount.Click += new System.EventHandler(this.btnUsersAccount_Click);
            // 
            // pnlReports
            // 
            this.pnlReports.Controls.Add(this.button6);
            this.pnlReports.Controls.Add(this.button7);
            this.pnlReports.Controls.Add(this.button8);
            this.pnlReports.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlReports.Location = new System.Drawing.Point(0, 324);
            this.pnlReports.Name = "pnlReports";
            this.pnlReports.Size = new System.Drawing.Size(214, 171);
            this.pnlReports.TabIndex = 5;
            this.pnlReports.Visible = false;
            // 
            // button6
            // 
            this.button6.Dock = System.Windows.Forms.DockStyle.Top;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(0, 102);
            this.button6.Name = "button6";
            this.button6.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.button6.Size = new System.Drawing.Size(214, 51);
            this.button6.TabIndex = 5;
            this.button6.Text = "Low Stock Report";
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Dock = System.Windows.Forms.DockStyle.Top;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(0, 51);
            this.button7.Name = "button7";
            this.button7.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.button7.Size = new System.Drawing.Size(214, 51);
            this.button7.TabIndex = 4;
            this.button7.Text = "Items Received Report";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Dock = System.Windows.Forms.DockStyle.Top;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(0, 0);
            this.button8.Name = "button8";
            this.button8.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.button8.Size = new System.Drawing.Size(214, 51);
            this.button8.TabIndex = 3;
            this.button8.Text = "Inventory Report";
            this.button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // btnReports
            // 
            this.btnReports.BackColor = System.Drawing.Color.Teal;
            this.btnReports.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnReports.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.btnReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReports.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReports.ForeColor = System.Drawing.Color.White;
            this.btnReports.Location = new System.Drawing.Point(0, 273);
            this.btnReports.Name = "btnReports";
            this.btnReports.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.btnReports.Size = new System.Drawing.Size(214, 51);
            this.btnReports.TabIndex = 4;
            this.btnReports.Text = "Reports";
            this.btnReports.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReports.UseVisualStyleBackColor = false;
            this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
            // 
            // btnInformationSites
            // 
            this.btnInformationSites.BackColor = System.Drawing.Color.Teal;
            this.btnInformationSites.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnInformationSites.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.btnInformationSites.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInformationSites.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInformationSites.ForeColor = System.Drawing.Color.White;
            this.btnInformationSites.Location = new System.Drawing.Point(0, 222);
            this.btnInformationSites.Name = "btnInformationSites";
            this.btnInformationSites.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.btnInformationSites.Size = new System.Drawing.Size(214, 51);
            this.btnInformationSites.TabIndex = 11;
            this.btnInformationSites.Text = "Information Sites";
            this.btnInformationSites.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInformationSites.UseVisualStyleBackColor = false;
            this.btnInformationSites.Click += new System.EventHandler(this.btnInformationSites_Click);
            // 
            // pnlManageItems
            // 
            this.pnlManageItems.Controls.Add(this.frmStocks);
            this.pnlManageItems.Controls.Add(this.btnItems);
            this.pnlManageItems.Controls.Add(this.btnCategories);
            this.pnlManageItems.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlManageItems.Location = new System.Drawing.Point(0, 51);
            this.pnlManageItems.Name = "pnlManageItems";
            this.pnlManageItems.Size = new System.Drawing.Size(214, 171);
            this.pnlManageItems.TabIndex = 3;
            this.pnlManageItems.Visible = false;
            // 
            // frmStocks
            // 
            this.frmStocks.Dock = System.Windows.Forms.DockStyle.Top;
            this.frmStocks.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.frmStocks.FlatAppearance.BorderSize = 0;
            this.frmStocks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.frmStocks.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.frmStocks.ForeColor = System.Drawing.Color.White;
            this.frmStocks.Location = new System.Drawing.Point(0, 102);
            this.frmStocks.Name = "frmStocks";
            this.frmStocks.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.frmStocks.Size = new System.Drawing.Size(214, 51);
            this.frmStocks.TabIndex = 5;
            this.frmStocks.Text = "Stocks";
            this.frmStocks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.frmStocks.UseVisualStyleBackColor = true;
            this.frmStocks.Click += new System.EventHandler(this.frmStocks_Click);
            // 
            // btnItems
            // 
            this.btnItems.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnItems.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnItems.FlatAppearance.BorderSize = 0;
            this.btnItems.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItems.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItems.ForeColor = System.Drawing.Color.White;
            this.btnItems.Location = new System.Drawing.Point(0, 51);
            this.btnItems.Name = "btnItems";
            this.btnItems.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.btnItems.Size = new System.Drawing.Size(214, 51);
            this.btnItems.TabIndex = 4;
            this.btnItems.Text = "Items";
            this.btnItems.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnItems.UseVisualStyleBackColor = true;
            this.btnItems.Click += new System.EventHandler(this.btnItems_Click);
            // 
            // btnCategories
            // 
            this.btnCategories.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCategories.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCategories.FlatAppearance.BorderSize = 0;
            this.btnCategories.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCategories.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCategories.ForeColor = System.Drawing.Color.White;
            this.btnCategories.Location = new System.Drawing.Point(0, 0);
            this.btnCategories.Name = "btnCategories";
            this.btnCategories.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.btnCategories.Size = new System.Drawing.Size(214, 51);
            this.btnCategories.TabIndex = 3;
            this.btnCategories.Text = "Categories";
            this.btnCategories.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCategories.UseVisualStyleBackColor = true;
            this.btnCategories.Click += new System.EventHandler(this.btnCategories_Click);
            // 
            // btnManageItems
            // 
            this.btnManageItems.BackColor = System.Drawing.Color.Teal;
            this.btnManageItems.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnManageItems.FlatAppearance.BorderColor = System.Drawing.Color.DarkSlateGray;
            this.btnManageItems.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageItems.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageItems.ForeColor = System.Drawing.Color.White;
            this.btnManageItems.Location = new System.Drawing.Point(0, 0);
            this.btnManageItems.Name = "btnManageItems";
            this.btnManageItems.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.btnManageItems.Size = new System.Drawing.Size(214, 51);
            this.btnManageItems.TabIndex = 2;
            this.btnManageItems.Text = "Manage Items";
            this.btnManageItems.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManageItems.UseVisualStyleBackColor = false;
            this.btnManageItems.Click += new System.EventHandler(this.btnManageItems_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(231, 29);
            this.panel4.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel2.Controls.Add(this.picShowAndHide);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(231, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(29, 587);
            this.panel2.TabIndex = 3;
            // 
            // picShowAndHide
            // 
            this.picShowAndHide.Dock = System.Windows.Forms.DockStyle.Top;
            this.picShowAndHide.Image = ((System.Drawing.Image)(resources.GetObject("picShowAndHide.Image")));
            this.picShowAndHide.Location = new System.Drawing.Point(0, 0);
            this.picShowAndHide.Name = "picShowAndHide";
            this.picShowAndHide.Size = new System.Drawing.Size(29, 29);
            this.picShowAndHide.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picShowAndHide.TabIndex = 0;
            this.picShowAndHide.TabStop = false;
            this.picShowAndHide.Click += new System.EventHandler(this.picShowAndHide_Click);
            // 
            // frmContainer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1097, 632);
            this.Controls.Add(this.pnlBody);
            this.Controls.Add(this.pnlControlAccess);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmContainer";
            this.Text = "frmContainer";
            this.Load += new System.EventHandler(this.frmContainer_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAskQuestion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogout)).EndInit();
            this.pnlControlAccess.ResumeLayout(false);
            this.pnlMenu.ResumeLayout(false);
            this.pnlSettings.ResumeLayout(false);
            this.pnlReports.ResumeLayout(false);
            this.pnlManageItems.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picShowAndHide)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox picAskQuestion;
        private System.Windows.Forms.PictureBox picLogout;
        private System.Windows.Forms.ImageList imageList;
        public System.Windows.Forms.Panel pnlBody;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlControlAccess;
        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel pnlSettings;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnUsersAccount;
        private System.Windows.Forms.Panel pnlReports;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Panel pnlManageItems;
        private System.Windows.Forms.Button frmStocks;
        private System.Windows.Forms.Button btnItems;
        private System.Windows.Forms.Button btnCategories;
        private System.Windows.Forms.Button btnManageItems;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox picShowAndHide;
        private System.Windows.Forms.Button btnInformationSites;
    }
}