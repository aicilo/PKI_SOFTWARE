﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmAlertMessage : Form
    {
        BackgroundWorker bgw = new BackgroundWorker();
        public Alert Notification { get; set; }
        public frmAlertMessage()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            bgw.WorkerReportsProgress = true;
            bgw.WorkerSupportsCancellation = true;
                       
            bgw.DoWork += new DoWorkEventHandler(DoWork);
            bgw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(RunWorkerCompleted);
            bgw.RunWorkerAsync();
            
        }

        public enum Alert { OutOfStock, NotAvailable, NotFound  }
            

        private void RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
           this.Close();                    
        }

        private void DoWork(object sender, DoWorkEventArgs e)
        {
            if (!bgw.CancellationPending)
            {
                System.Threading.Thread.Sleep(1000);
                
            }
            else if (bgw.CancellationPending)
            {
                e.Cancel = true;
            }
        }

        private void frmAlertMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                bgw.CancelAsync();
            }
        }

        private void frmAlertMessage_Load(object sender, EventArgs e)
        {
            if (Notification == Alert.OutOfStock)
            {
                lblMessage.Text = "OUT OF STOCK";
            }
            else if (Notification == Alert.NotAvailable)
            {
                lblMessage.Text = "NOT AVAILABLE";
            }
            else if (Notification == Alert.NotFound)
            {
                lblMessage.Text = "ITEM NOT FOUND";
            }
        }

       

         
    }
}
