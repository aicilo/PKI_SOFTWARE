﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmSplashScreen : Form
    {


        delegate void RunningBar(int length);

        BackgroundWorker bgw = new BackgroundWorker();
        public frmSplashScreen()
        {
            InitializeComponent();

            this.ShowInTaskbar = false;
            pnlRunningBar.Width = 0;
            


            bgw.WorkerReportsProgress = true;
            bgw.WorkerSupportsCancellation = true;
            bgw.DoWork += new DoWorkEventHandler(DoWork);
            bgw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(RunWorkerCompleted);
            bgw.RunWorkerAsync();
        }

        private void RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (pnlRunningBar.Width <= pnlLoadingBar.Width)
            {
               
                bgw.RunWorkerAsync();
            }
            else
            {
                var frm = new frmMain();
                frm.Show();

                this.Hide();
            }
         
        }

        private void DoWork(object sender, DoWorkEventArgs e)
        {
            var intLoadingBar = pnlLoadingBar.Width;
            if (!bgw.CancellationPending) 
            {
                AddBarWidth(10);
                System.Threading.Thread.Sleep(30);
            }
            else if (bgw.CancellationPending)
            {
                e.Cancel = true;
            }
        }

        private void AddBarWidth(int length)
        {
            if (pnlRunningBar.InvokeRequired)
            {
                RunningBar r = new RunningBar(AddBarWidth);
                this.Invoke(r, new object[] { length });
            }
            else 
            {
                this.pnlRunningBar.Width += length;
            }

        }



    }
}
