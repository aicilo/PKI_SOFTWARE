﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmItems : Form
    {
        public frmItems()
        {
            InitializeComponent();
            Global.WaterMark("Search", txtSearch);
        }

        private void lnklblNewItem_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmAddNewItem newItem = new frmAddNewItem();
            newItem.ShowDialog();
            RefreshItems();
        }

        private void lnklblManageStock_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmManageStock manageStock = new frmManageStock();
            manageStock.ShowDialog();
            RefreshItems();
        }

        private void RefreshItems()
        {
            dgvItems.Rows.Clear();
            var item = new Item();
            item.SiteCode = Global.SelectedSite.Code;
            item.GetItems();

            foreach (var list in Global.ItemsList)
            {
                dgvItems.Rows.Add(false, list.Id, list.Name, list.Category, list.Description, list.Unit, list.Stock, list.LowStockAlert, list.Barcode, (list.Active == true) ? false : true);
            }
            dgvItems.ClearSelection();
            txtSearch.Clear();
            lblTotal.Text = string.Format("Total: {0}", dgvItems.Rows.Count);
        }

        private void SearchItem()
        {

            List<Item> searchItem = Global.ItemsList.FindAll(x => x.Name.ToUpper().Contains(txtSearch.Text.ToUpper()) || x.Category.ToUpper().Contains(txtSearch.Text.ToUpper()) || x.Unit.ToUpper().Contains(txtSearch.Text.ToUpper()) || x.Description.ToUpper().Contains(txtSearch.Text.ToUpper()) || x.Barcode.ToUpper().Contains(txtSearch.Text.ToUpper()));
            if (searchItem.Count > 0)
            {
                dgvItems.Rows.Clear();
                foreach (var list in searchItem)
                {
                    dgvItems.Rows.Add(false, list.Id, list.Name, list.Category, list.Description, list.Unit, list.Stock, list.LowStockAlert, list.Barcode, (list.Active == true) ? false : true);
                }
            }
            else
            {
                dgvItems.Rows.Clear();

            }
            dgvItems.ClearSelection();
            lblTotal.Text = string.Format("Total: {0}", dgvItems.Rows.Count);


            foreach (var item in Global.SelectedItems)
            {
                foreach (DataGridViewRow row in dgvItems.Rows)
                {
                    if (Int32.Parse(row.Cells["Id"].Value.ToString()) == item.Id)
                    {
                        row.Cells["Selected"].Value = true;
                    }
                }
            }
        }

        private void frmItems_Load(object sender, EventArgs e)
        {
            RefreshItems();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            SearchItem();
        }

        private void lnklblSetItemCategory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (dgvItems.Columns["Selected"].Visible == false)
            {
                dgvItems.Columns["Selected"].Visible = true;
                btnCommand.Text = "Set";
                btnCommand.Visible = true;
                btnCancel.Visible = true;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (dgvItems.Columns["Selected"].Visible == true)
            {
                dgvItems.Columns["Selected"].Visible = false;
                btnCommand.Visible = false;
                btnCancel.Visible = false;
                Global.SelectedItems = null;
            }
        }



        private void dgvItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvItems.CommitEdit(DataGridViewDataErrorContexts.Commit);
            dgvItems.ClearSelection();

        }
        

        private void dgvItems_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvItems.Rows.Count > 0)
            {
                if (e.ColumnIndex == 0)
                {
                    int id = Int32.Parse(dgvItems.Rows[e.RowIndex].Cells["Id"].Value.ToString());
                    bool isSelected = Boolean.Parse(dgvItems.Rows[e.RowIndex].Cells["Selected"].Value.ToString());
                    Item searchItem = Global.SelectedItems.Find(x => x.Id.Equals(id));


                    if (isSelected == true)
                    {
                        Global.SelectedItems.Add(new Item() { Id = id });
                    }
                    else
                    {
                        Global.SelectedItems.RemoveAll(r => r.Id == id);
                    }
                }


            }
        }

        
    }
}
