﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmInformationSites : Form
    {
        public frmInformationSites()
        {
            InitializeComponent();
            RefreshSites();
            Global.WaterMark("Search", txtSearch);

        }

        private List<Site> SiteList = new List<Site>();
        private void RefreshSites()
        {
            dgvSites.Rows.Clear();
            var site = new Site();
            SiteList = site.SitesInformation();

            foreach (var s in SiteList)
            {
                dgvSites.Rows.Add(s.Code, s.Name, s.Description, s.SectionCode, s.UsersCount);
            }
            dgvSites.ClearSelection();
            txtSearch.Clear();
            lblTotal.Text = string.Format("Total: {0}", dgvSites.Rows.Count);
        }

        private void SearchSites()
        {

            var searchSite = SiteList.FindAll(x => x.Name.ToUpper().Contains(txtSearch.Text.ToUpper()) || x.Code.ToUpper().Equals(txtSearch.Text.ToUpper()));
            if (searchSite.Count > 0)
            {
                dgvSites.Rows.Clear();
                foreach (var s in searchSite)
                {
                    dgvSites.Rows.Add(s.Code, s.Name, s.Description, s.SectionCode, s.UsersCount);
                }
            }
            else
            {
                dgvSites.Rows.Clear();
            }

            dgvSites.ClearSelection();
            lblTotal.Text = string.Format("Total: {0}", dgvSites.Rows.Count);


        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            SearchSites();
        }

        private void lnklblCreateSite_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var createSite = new frmCreateSite();
            createSite.ShowDialog();
            RefreshSites();
        }

 
    }
}
