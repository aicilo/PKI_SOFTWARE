﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmStocks : Form
    {
        public frmStocks()
        {
            InitializeComponent();
            Global.WaterMark("Search", txtSearch);

        }

        private void lnklblManageStock_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmManageStock manageStock = new frmManageStock();
            manageStock.ShowDialog();
            ReloadTransaction();
        }

        private void ReloadTransaction()
        {
            dgvTransaction.Rows.Clear();
            var trans = new Transaction();
            trans.SiteCode = Global.SelectedSite.Code;
            
            foreach (var history in trans.GetHistory())
            {
                string quantity;
                if (history.StockAction == "STOCK ISSUE" || history.StockAction == "DAMAGE" || history.StockAction == "LOSS")
                {
                    quantity = string.Format("-{0} {1}.", history.Quantity, history.Unit.ToLower());
                }
                else
                {
                    quantity = string.Format("{0} {1}.", history.Quantity, history.Unit.ToLower());
                }
                dgvTransaction.Rows.Add(history.TransactionId, history.TransactDate.ToString("yyyy-MM-dd hh:mm:ss tt"), history.Name, quantity , history.StockAction);
                
            }
            dgvTransaction.ClearSelection();
            txtSearch.Clear();
        }

        private void frmStocks_Load(object sender, EventArgs e)
        {
            ReloadTransaction();
        }
    }
}
