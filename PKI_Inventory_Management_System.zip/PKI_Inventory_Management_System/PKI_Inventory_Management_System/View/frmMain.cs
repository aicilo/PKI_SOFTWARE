﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmMain : Form
    {
        List<User> user = new List<User>();
        public frmMain()
        {
            InitializeComponent();

            DateTime dateUpdate = new DateTime(2022,08,06);
            this.Text = string.Format("PKI Inventory Management System ver. {0}", dateUpdate.ToString("yy.MM.dd"));
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var user = new User();
            user.IDNumber = txtIDNumber.Text;
            user.Password = txtPassword.Text;
            if (user.Login())
            {
                var sites = new Site();
                sites.GetUserSites(user.IDNumber);

                if (Global.CurrentUserSitesList.Count > 0)
                {
                    this.Controls.Clear();
                    frmContainer frm = new frmContainer();
                    frm.Dock = DockStyle.Fill;
                    frm.TopLevel = false;
                    this.Controls.Add(frm);
                    frm.Show();
                }
                else
                {
                    MessageBox.Show("Account not activated", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("Incorrect id number or password.","",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtPassword.Clear();
                txtIDNumber.Focus();
                txtIDNumber.SelectAll();
            }
                                
        }

        private void lnklblForgotPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmResetPassword reset = new frmResetPassword();
            reset.ShowDialog();

            txtPassword.Clear();
            txtIDNumber.Focus();
            txtIDNumber.SelectAll();

        }

        private void txtIDNumber_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (!string.IsNullOrEmpty(txtIDNumber.Text) && !string.IsNullOrEmpty(txtPassword.Text))
                {
                    btnLogin.PerformClick();
                }
                else
                {
                    if (string.IsNullOrEmpty(txtIDNumber.Text))
                    {
                        txtIDNumber.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtPassword.Text))
                    {
                        txtPassword.Focus();
                    }
                }
            }
        }

      
    }
}
