﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmScanID : Form
    {
        public frmScanID()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            Global.TextBoxValidation(txtIDNumber, "0123456789");
        }

        private void frmScanID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        private void txtIDNumber_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (!string.IsNullOrEmpty(txtIDNumber.Text))
                {
                    Employee emp = new Employee();
                    emp.IDNumber = txtIDNumber.Text;
                    emp.GetEmployeeInformation();
                    if (emp.FullName != null)
                    {
                        List<Transaction> transactionList = new List<Transaction>();
                        List<Item> items = new List<Item>();

                        foreach (DataGridViewRow row in Global.RequestItems.Rows)
                        {
                            items.Add(new Item() { Id = Int32.Parse(row.Cells["ItemId"].Value.ToString()) });
                            transactionList.Add(new Transaction()
                            {
                                Id = Int32.Parse(row.Cells["ItemId"].Value.ToString()),
                                Quantity = Int32.Parse(row.Cells["Quantity"].Value.ToString()),
                                StockAction = "STOCK ISSUE",
                                TransactTo = emp.FullName,
                                TransactFrom = Global.CurrentUser.FullName
                            });
                        }

                        var trans = new Transaction();
                        if (trans.NewTransaction(transactionList))
                        {
                            this.Hide();
                            MessageBox.Show("Transaction has been completed successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Global.RequestItems = null;

                            var mail = new Mail();
                            mail.LowStockAlertNotification(items);
                            this.Close();
                        }

                    }
                    else
                    {
                        MessageBox.Show("Invalid id number", "Scan ID Number", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtIDNumber.Focus();
                        txtIDNumber.SelectAll();
                    }
                }
                else
                {
                    MessageBox.Show("Please enter the receiver id number to complete the transaction.", "Scan/Enter ID Number", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtIDNumber.Focus();
                    txtIDNumber.SelectAll();
                }
                              
            }
        }


    }
}
