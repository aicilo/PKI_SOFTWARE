﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmManageStock : Form
    {
        Item selectedItem = null;

        public frmManageStock()
        {
            InitializeComponent();
            Global.WaterMark("Search", txtSearch);
            Global.WaterMark("Select Reason", cboStockAction);
            

            Global.WaterMark("0", txtQuantity);

            Global.TextBoxValidation(txtQuantity, "1234567890");
            txtQuantity.Visible = false;
            CreateCustomDatagridviewDropdown();
            cboStockAction.Visible = false;

            btnSave.Enabled = false;

        }

        private DataGridView dgvSearchList = new DataGridView();
        private void CreateCustomDatagridviewDropdown()
        {
            var item = new Item();
            item.SiteCode = Global.SelectedSite.Code;
            item.GetItems();
            
            DataGridView dgv = new DataGridView();
            dgv.Name = "CustomDGV";
            //dgv.Size = new Size(pnlSearchContainer.Width, 108);
            dgv.Size = new Size(pnlSearchContainer.Width, 0);

            dgv.BackgroundColor = Color.WhiteSmoke;
            dgv.BorderStyle = BorderStyle.Fixed3D;

            dgv.AllowUserToAddRows = false;
            

            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.ColumnHeadersVisible = false;

            dgv.RowHeadersVisible = false;
            dgv.RowTemplate.Height = 35;
            dgv.RowTemplate.Resizable = DataGridViewTriState.False;
            
            dgv.MultiSelect = false;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.TabIndex = 0;
            dgv.Location = new Point(pnlSearchContainer.Left, pnlSearchContainer.Bottom);
            this.Controls.Add(dgv);
            this.Controls["CustomDGV"].BringToFront();


            dgv.Columns.Add("Id", "Id");
            dgv.Columns.Add("ItemName", "ItemName");

            dgv.Columns["Id"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv.Columns["Id"].DefaultCellStyle.Font = new Font("Tahoma", 10, FontStyle.Regular);
            dgv.Columns["Id"].DefaultCellStyle.Padding = new Padding(5);
            dgv.Columns["Id"].Resizable = DataGridViewTriState.False;
            dgv.Columns["Id"].ReadOnly = false;
            dgv.Columns["Id"].Width = 50;


            dgv.Columns["ItemName"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv.Columns["ItemName"].DefaultCellStyle.Font = new Font("Tahoma", 10, FontStyle.Regular);
            dgv.Columns["ItemName"].DefaultCellStyle.Padding = new Padding(5);
            dgv.Columns["ItemName"].Resizable = DataGridViewTriState.False;
            dgv.Columns["ItemName"].ReadOnly = true;
            dgv.Columns["ItemName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dgv.DefaultCellStyle.BackColor = Color.WhiteSmoke;
            dgv.Visible = false;
            //dgv.MouseLeave -= dgv_MouseLeave;
            dgv.MouseLeave += dgv_MouseLeave;
            dgv.CellClick += dgv_SelectCell;

            dgvSearchList = dgv;
        }

        private void dgv_SelectCell(object sender, DataGridViewCellEventArgs e)
        {
            cboStockAction.SelectedIndex = -1;
            var dgv = (DataGridView)sender;
            txtSearch.Text = dgv.Rows[dgv.SelectedRows[0].Index].Cells["ItemName"].Value.ToString();
            dgv.Visible = false;

            Item searchItem = Global.ItemsList.Find(x => x.Id.Equals(dgv.Rows[0].Cells["Id"].Value));
            if (searchItem != null)
            {
                var unit = new Unit();
                unit.GetUnits();
                unit = Global.UnitsList.Find(x => x.Description.Equals(searchItem.Unit));
                lblItemName.Text = searchItem.Name;
                lblItemDescription.Text = searchItem.Description;
                lblCurrentStock.Text = string.Format("{0} {1}.", searchItem.Stock.ToString(), (unit != null) ? unit.Code : string.Empty);
                lblUnit.Text = (unit != null) ? string.Format("{0}.", unit.Code) : string.Empty;
                txtQuantity.Visible = true;
                cboStockAction.Visible = true;
                btnSave.Enabled = true;


                selectedItem = new Item();
                selectedItem.Id = searchItem.Id;
                selectedItem.Stock = searchItem.Stock;
            }

        }

        private void dgv_MouseLeave(object sender, EventArgs e)
        {
            var dgv = (DataGridView)sender;
            dgv.Visible = false;
            txtSearch.Focus();
            txtSearch.SelectionLength = txtSearch.Text.Length;
        }

        private void frmManageStock_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                CloseApplication(); 
            }
        }

        private void CloseApplication()
        {
            var msg = MessageBox.Show("Are you sure you want to cancel?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (msg == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            CloseApplication();
        }

        private void frmManageStock_Load(object sender, EventArgs e)
        {


        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            selectedItem = null;
            lblItemName.Text = string.Empty;
            lblItemDescription.Text = string.Empty;
            lblCurrentStock.Text = string.Empty;
            lblUnit.Text = string.Empty;
            txtQuantity.Text = string.Empty;
            cboStockAction.SelectedIndex = -1;
            txtQuantity.Visible = false;
            cboStockAction.Visible = false;
            btnSave.Enabled = false;


            if (!string.IsNullOrEmpty(txtSearch.Text))
            {
               
                List<Item> searchItem = Global.ItemsList.FindAll(x => x.Name.ToUpper().Contains(txtSearch.Text.ToUpper()));
                if (searchItem.Count > 0)
                {
                    dgvSearchList.Rows.Clear();
                    dgvSearchList.Height = 0;
                    foreach (var item in searchItem)
                    {
                        dgvSearchList.Rows.Add(item.Id, item.Name);
                        if (dgvSearchList.Height < 108)
                        {
                            dgvSearchList.Height += dgvSearchList.RowTemplate.Height;
                        }
                        
                    }
                    dgvSearchList.Visible = true;
                    dgvSearchList.ClearSelection();
                }
                else
                {
                    dgvSearchList.Rows.Clear();
                    dgvSearchList.Height = 0;
                }
            }
            else
            {
                dgvSearchList.Visible = false;
            }
            
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            txtQuantity.Text = (txtQuantity.Text == string.Empty) ? string.Empty : Int32.Parse(txtQuantity.Text).ToString();
            txtQuantity.SelectionStart = txtQuantity.Text.Length;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            
            if (cboStockAction.Items.Contains(cboStockAction.Text))
            {
                if (selectedItem != null)
                {
                    var trans = new Transaction();
                    trans.Id = selectedItem.Id;
                    trans.StockAction = cboStockAction.Text;
                    trans.Quantity = (string.IsNullOrEmpty(txtQuantity.Text)) ? 0 : Int32.Parse(txtQuantity.Text);
                    trans.TransactTo = Global.CurrentUser.FullName;
                    trans.TransactFrom = Global.CurrentUser.FullName;
                     
                    if ((trans.StockAction == "DAMAGE" || trans.StockAction == "LOSS") && (selectedItem.Stock < trans.Quantity) || trans.Quantity == 0)
                    {
                        MessageBox.Show("Invalid quantity.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                    else
                    {
                        if (trans.NewTransaction())
                        {
                            MessageBox.Show("Transaction has been completed.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();
                        }
                    }

                }
            }
            else
            {
                MessageBox.Show("Invalid reason.","",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

       

    
    }
}
