﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmScanBarcode : Form
    {
        public frmScanBarcode()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
        }

        private void frmScanBarcode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
            else if (e.KeyCode == Keys.Enter)
            {
                SearchItem();
            }
        }

        private void SearchItem()
        {
            if (txtBarcode.TextLength != 0)
            {
                frmAlertMessage frm = new frmAlertMessage();
                Item searchItem = Global.ItemsList.Find(x => x.Barcode.ToUpper().Equals(txtBarcode.Text));
                if (searchItem != null)
                {

                    if (searchItem.Active == false)
                    {
                        frm.Notification = frmAlertMessage.Alert.NotAvailable;
                        frm.ShowDialog();
                        txtBarcode.SelectAll();
                    }
                    else if (searchItem.Stock == 0)
                    {
                        frm.Notification = frmAlertMessage.Alert.OutOfStock;
                        frm.ShowDialog();
                        txtBarcode.SelectAll();
                    }
                    else
                    {
                        if (searchItem != null)
                        {
                            if (searchItem.Stock < Int32.Parse(nudQuantity.Value.ToString()))
                            {
                                frm.Notification = frmAlertMessage.Alert.OutOfStock;
                                frm.ShowDialog();
                                txtBarcode.SelectAll();
                            }
                            else
	                        {
                                searchItem.Stock -= Int32.Parse(nudQuantity.Value.ToString());
                                string[] requestItem = new string[5] { searchItem.Id.ToString(), searchItem.Barcode.ToString(), searchItem.Name.ToString(), searchItem.Unit.ToString(), nudQuantity.Value.ToString() };
                                Global.RequestItems.Rows.Add(requestItem);
                                Global.RequestItems.FirstDisplayedScrollingRowIndex = Global.RequestItems.Rows.Count - 1;
                                Global.RequestItems.ClearSelection();
	                        }
                            
                        
                        }
                        nudQuantity.Value = 1;
                        txtBarcode.Clear();
                        txtBarcode.Focus();
                        txtBarcode.SelectAll();
                    }

                }
                else
                {
                    frm.Notification = frmAlertMessage.Alert.NotFound;
                    frm.ShowDialog();
                    txtBarcode.Focus();
                    txtBarcode.SelectAll();
                }
            }
            
        }
    }
}
