﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmCategories : Form
    {
        public frmCategories()
        {
            InitializeComponent();
            Global.WaterMark("Search", txtSearch);
        }

        private void RefreshCategory()
        {
            dgvCategories.Rows.Clear();
            var category = new Category();
            category.GetCategories();

            foreach (var list in Global.CategoriesList)
            {
                dgvCategories.Rows.Add(list.Code, list.Description);
            }
            dgvCategories.ClearSelection();
            txtSearch.Clear();
            lblTotal.Text = string.Format("Total: {0}", dgvCategories.Rows.Count);
        }

        private void SearchCategory()
        {

            List<Category> searchCategory = Global.CategoriesList.FindAll(x => x.Code.ToUpper().Contains(txtSearch.Text.ToUpper()) || x.Description.ToUpper().Contains(txtSearch.Text.ToUpper()));
            if (searchCategory.Count > 0)
            {
                dgvCategories.Rows.Clear();
                foreach (var list in searchCategory)
                {
                    dgvCategories.Rows.Add(list.Code, list.Description);
                }
            }
            else
            {
                dgvCategories.Rows.Clear();                    
            }
            dgvCategories.ClearSelection();
            lblTotal.Text = string.Format("Total: {0}", dgvCategories.Rows.Count);
        }

        private void frmCategories_Load(object sender, EventArgs e)
        {
            RefreshCategory();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            SearchCategory();
        }

        private void lnklblNewCategory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var category = new frmCreateCategory();
            category.ShowDialog();
            RefreshCategory();
        }
    }
}
