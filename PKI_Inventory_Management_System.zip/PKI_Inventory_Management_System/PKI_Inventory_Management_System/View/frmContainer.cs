﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmContainer : Form
    {

        public frmContainer()
        {
            InitializeComponent();
            Model.Global.Container = this;

            pnlControlAccess.Width = 29;
            picShowAndHide.Image = imageList.Images["Right"];
            frmSitesList frm = new frmSitesList();
            DisplayForm(frm);


            
        }

       

        public void DisplayForm(Form frm)
        {
            if (!this.pnlBody.Controls.ContainsKey(frm.Name))
            {
                pnlBody.Controls.Clear();
                frm.Dock = DockStyle.Fill;
                frm.TopLevel = false;
                //frm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                this.pnlBody.Controls.Add(frm);
                frm.Show();
            }

           
        }



        private void picAskQuestion_DoubleClick(object sender, EventArgs e)
        {
            frmAskQuestion frm = new frmAskQuestion();
            frm.ShowDialog();
        }
       

        private void picShowAndHide_Click(object sender, EventArgs e)
        {
            if (Global.SelectedSite.UserRole == 2 || Global.SelectedSite.UserRole == 3)
            {
                if (pnlControlAccess.Width <= 29)
                {
                    pnlControlAccess.Width = 260;
                    picShowAndHide.Image = imageList.Images["Left"];

                    if (Global.SelectedSite.UserRole == 3)
                    {
                        btnInformationSites.Visible = true;
                    }
                    else
                    {
                        btnInformationSites.Visible = false;
                    }

                }
                else
                {
                    pnlControlAccess.Width = 29;
                    picShowAndHide.Image = imageList.Images["Right"];

                    frmIssuance frm = new frmIssuance();
                    Global.Container.DisplayForm(frm);
                }


            }
            else if (Global.SelectedSite.UserRole == 1)
            {
                MessageBox.Show("You are not authorized to access!", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Please select your site that you want to access", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void btnManageItems_Click(object sender, EventArgs e)
        {
            if (pnlManageItems.Visible == false)
            {
                pnlManageItems.Visible = true;
                btnManageItems.BackColor = Color.Gold;
                btnManageItems.ForeColor = Color.Black;
            }
            else
            {
                pnlManageItems.Visible = false;
                btnManageItems.BackColor = Color.Teal;
                btnManageItems.ForeColor = Color.White;
            }
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            if (pnlReports.Visible == false)
            {
                pnlReports.Visible = true;
                btnReports.BackColor = Color.Gold;
                btnReports.ForeColor = Color.Black;
            }
            else
            {
                pnlReports.Visible = false;
                btnReports.BackColor = Color.Teal;
                btnReports.ForeColor = Color.White;
            }
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            if (pnlSettings.Visible == false)
            {
                pnlSettings.Visible = true;
                btnSettings.BackColor = Color.Gold;
                btnSettings.ForeColor = Color.Black;
            }
            else
            {
                pnlSettings.Visible = false;
                btnSettings.BackColor = Color.Teal;
                btnSettings.ForeColor = Color.White;
            }
        }

        private void btnItems_Click(object sender, EventArgs e)
        {
            frmItems frm = new frmItems();
            Global.Container.DisplayForm(frm);
        }

        private void frmStocks_Click(object sender, EventArgs e)
        {
            frmStocks frm = new frmStocks();
            Global.Container.DisplayForm(frm);
        }

        private void btnCategories_Click(object sender, EventArgs e)
        {
            frmCategories frm = new frmCategories();
            Global.Container.DisplayForm(frm);
        }

        private void btnUsersAccount_Click(object sender, EventArgs e)
        {
            frmUsersAccount frm = new frmUsersAccount();
            Global.Container.DisplayForm(frm);
        }

        private void btnInformationSites_Click(object sender, EventArgs e)
        {
            frmInformationSites frm = new frmInformationSites();
            Global.Container.DisplayForm(frm);
        }

        private void frmContainer_Load(object sender, EventArgs e)
        {
            var role = new Role();
            Global.Roles = role.AllRoles();
        }

  
    }
}
