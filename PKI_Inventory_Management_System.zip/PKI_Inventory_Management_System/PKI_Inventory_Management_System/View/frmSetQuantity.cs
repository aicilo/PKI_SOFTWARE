﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmSetQuantity : Form
    {
        public int Quantity { get; set; }
        public int Stock { get; set; }
        public frmSetQuantity()
        {
            InitializeComponent();
            nudQuantity.Select(0, nudQuantity.Value.ToString().Length);
            this.ShowInTaskbar = false;

        }

        public frmSetQuantity(int quantity)
        {
            InitializeComponent();
            nudQuantity.Value = quantity;
            nudQuantity.Select(0, nudQuantity.Value.ToString().Length);
        }

        private void frmSetQuantity_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
            else if (e.KeyCode == Keys.Enter)
            {
                btnRequest.PerformClick();
            }
            else if (e.Modifiers == Keys.Control)
            {
                //if (System.Text.RegularExpressions.Regex.IsMatch(e.KeyCode.ToString(), "[0-9]"))
                //{
                //    string key = e.KeyCode.ToString();
                //    if (key.Length > 1)
                //    {
                //        key = key.Replace("NumPad", "").Replace("D", "");
                //        int value = Int32.Parse(key);
                //        if (value > 0)
                //        {
                //            nudQuantity.Value = value;
                //            nudQuantity.Select(nudQuantity.Value.ToString().Length, 1);
                //        }

                //    }


                //}
            }
     
        }

        private void nudQuantity_ValueChanged(object sender, EventArgs e)
        {
             nudQuantity.Select(nudQuantity.Value.ToString().Length, 1);
        }

        private void btnRequest_Click(object sender, EventArgs e)
        {
            Quantity = Int32.Parse(nudQuantity.Value.ToString());
            this.Close();
        }

        private void frmSetQuantity_Load(object sender, EventArgs e)
        {
            nudQuantity.Maximum = Stock;
        }



       
    }
}
