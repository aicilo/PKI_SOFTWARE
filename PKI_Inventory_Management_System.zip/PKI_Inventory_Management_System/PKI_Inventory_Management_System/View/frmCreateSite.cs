﻿using PKI_Inventory_Management_System.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmCreateSite : Form
    {
        List<Section> SectionList = new List<Section>();
        public frmCreateSite()
        {
            InitializeComponent();

            var sections = new Section();
            SectionList = sections.GetSections();
            foreach (var section in SectionList)
            {
                cboSectionCode.Items.Add(section.Code);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cboSectionCode_SelectionChangeCommitted(object sender, EventArgs e)
        {
            lblSection.Text = SectionList.Find(x => x.Code.Equals(cboSectionCode.Text)).Description;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            var create_site = new Site();
            create_site.SectionCode = cboSectionCode.Text;
            create_site.Name = txtName.Text.ToUpper().TrimStart().Trim();
            create_site.Description = txtDescription.Text.ToUpper();
            if (!string.IsNullOrEmpty(create_site.SectionCode)) 
            {
                if (!string.IsNullOrEmpty(create_site.Name)) 
                {
                    if (create_site.CreateSite())
                    {
                        MessageBox.Show("Site has been created successfully.", "Create Site", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    } 
                }
                else
                {
                    MessageBox.Show("Site name is a required field.", "Create Site", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

            }
            else
            {
                MessageBox.Show("Please fill out the required fields.", "Create Site", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
