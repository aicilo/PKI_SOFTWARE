﻿using PKI_Inventory_Management_System.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmCreateCategory : Form
    {
        public frmCreateCategory()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var category = new Category();
            category.Description = txtDescription.Text.TrimStart().TrimEnd();
            if (!string.IsNullOrEmpty(category.Description))
            {
                if (category.AddCategory())
                {
                    MessageBox.Show("Added successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Please enter the category description.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtDescription.Clear();
                txtDescription.Focus();
            }
        }

  
    }
}
