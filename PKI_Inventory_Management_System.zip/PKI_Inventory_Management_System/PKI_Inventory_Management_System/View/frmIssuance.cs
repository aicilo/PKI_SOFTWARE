﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model; 

namespace PKI_Inventory_Management_System.View
{
    public partial class frmIssuance : Form
    {
        public frmIssuance()
        {
            InitializeComponent();
            Global.WaterMark("Search", txtSearch);

        }

        private void LoadItems()
        {
            flpItems.Controls.Clear();
            foreach (var item in Global.ItemsList)
            {
                Create(item);
            }
        }

        private void SearchItem()
        {

            List<Item> searchItem = Global.ItemsList.FindAll(x => x.Name.ToUpper().Contains(txtSearch.Text.ToUpper()) || x.Barcode.Equals(txtSearch.Text.ToUpper()));
            if (searchItem.Count > 0)
            {
                flpItems.Controls.Clear();
                foreach (var item in searchItem)
                {
                    Create(item);
                }
            }
            
        }

        private void Create(Item item)
        {
            Panel container = new Panel();
            container.Size = new Size(162, 162);
            container.BackColor = Color.White;
            container.BorderStyle = BorderStyle.FixedSingle;

            Label name = new Label();
            name.Text = item.Name;
            name.Dock = DockStyle.Fill;
            name.BackColor = Color.White;
            name.ForeColor = Color.Black;
            name.Font = new Font("Arial Rounded MT", 10, FontStyle.Bold);
            name.TextAlign = ContentAlignment.MiddleCenter;
            container.Controls.Add(name);

            Label status = new Label();

            if (item.Active == true)
            {
                if (item.Stock > 0)
                {
                    status.Text = string.Format("AVAILABLE: {0}", item.Stock);
                    status.BackColor = Color.Teal;
                }
                else
                {
                    status.Text = "OUT OF STOCK";
                    status.BackColor = Color.Firebrick;
                }
                status.ForeColor = Color.White;
            }
            else
            {
                status.Text = "NOT AVAILABLE";
                status.BackColor = Color.FromArgb(64,64,64);
                status.ForeColor = Color.LightGray;

            }

            status.Dock = DockStyle.Bottom;
            status.Font = new Font("Arial Rounded MT", 8, FontStyle.Bold);
            status.TextAlign = ContentAlignment.MiddleCenter;
            container.Controls.Add(status);
            
            flpItems.Controls.Add(container);
            name.Click += (sender, e) => SelectedItem(sender, e, item);

        }

        private void SelectedItem(object sender, EventArgs e, Item item)
        {
            Label name = (Label)sender;
     
            if (item.Stock > 0 && item.Active == true)
            {
                name.BackColor = Color.Azure;
                frmSetQuantity frm = new frmSetQuantity();
                frm.Stock = item.Stock;
                frm.ShowDialog();
                name.BackColor = Color.White;

                int quantity = frm.Quantity;

                if (quantity > 0)
                {
                    Item selectedItem = Global.ItemsList.Find(x => x.Id.Equals(item.Id));
                    if (selectedItem != null)
                    {
                        if (selectedItem.Stock >= quantity)
                        {
                            selectedItem.Stock -= quantity;
                            string[] requestItem = new string[5] { item.Id.ToString(), item.Barcode.ToString(), item.Name.ToString(), item.Unit.ToString(), quantity.ToString() };
                            dgvRequest.Rows.Add(requestItem);
                            dgvRequest.FirstDisplayedScrollingRowIndex = dgvRequest.Rows.Count - 1;
                            lblTotalQuantity.Text = TotalQuantity().ToString();
                            LoadItems();

                        }
                        
                    }

                    
                }

                if (txtSearch.TextLength > 0)
                {
                    txtSearch.Clear();
                }

                frm.Dispose();
                dgvRequest.ClearSelection();
            }
            

        }

        private int TotalQuantity()
        {
            int total = 0;
            foreach (DataGridViewRow row in dgvRequest.Rows)
            {
                total += Int32.Parse(row.Cells["Quantity"].Value.ToString());
            }
            return total;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            SearchItem();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
             List<DataGridViewRow> toBeDeleted = new List<DataGridViewRow>();
             foreach (DataGridViewRow row in dgvRequest.SelectedRows)
             {
                 toBeDeleted.Add(row);
             }
             foreach (DataGridViewRow row in toBeDeleted)
             {
                 var msg = MessageBox.Show(string.Format("Are you sure you want to remove {0} ({1})?", row.Cells["ItemName"].Value.ToString(), row.Cells["Quantity"].Value.ToString()), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                 if (msg == System.Windows.Forms.DialogResult.Yes)
                 {
                     Item selectedItem = Global.ItemsList.Find(x => x.Id.Equals(Int32.Parse(row.Cells["ItemId"].Value.ToString())));
                     if (selectedItem != null)
                     {
                         selectedItem.Stock += Int32.Parse(row.Cells["Quantity"].Value.ToString());
                         dgvRequest.Rows.Remove(row);
                         LoadItems();
                     }

                 }
             }
             dgvRequest.ClearSelection();
             lblTotalQuantity.Text = TotalQuantity().ToString();
        }

        private void dgvRequest_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            List<DataGridViewRow> toBeUpdateQuantity = new List<DataGridViewRow>();
            foreach (DataGridViewRow row in dgvRequest.SelectedRows)
            {
                toBeUpdateQuantity.Add(row);
            }
            foreach (DataGridViewRow row in toBeUpdateQuantity)
            {
                frmSetQuantity frm = new frmSetQuantity(Int32.Parse(row.Cells["Quantity"].Value.ToString()));
                Item selectedItem = Global.ItemsList.Find(x => x.Id.Equals(Int32.Parse(row.Cells["ItemId"].Value.ToString())));
                if (selectedItem != null)
                {
                    frm.Stock = selectedItem.Stock + Int32.Parse(row.Cells["Quantity"].Value.ToString());
                    frm.ShowDialog();
                    int quantity = frm.Quantity;
                    if (quantity > 0)
                    {
                        selectedItem.Stock = frm.Stock - quantity;
                        row.Cells["Quantity"].Value = quantity;
                        dgvRequest.FirstDisplayedScrollingRowIndex = row.Index;
                        lblTotalQuantity.Text = TotalQuantity().ToString();
                        LoadItems();
                    }
                }
                                
                
            }
            dgvRequest.ClearSelection();
        }

        private void btnBarcode_Click(object sender, EventArgs e)
        {
            Global.RequestItems = dgvRequest;
            frmScanBarcode frm = new frmScanBarcode();
            frm.ShowDialog();

            LoadItems();
        }

        private void dgvRequest_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            lblTotalQuantity.Text = TotalQuantity().ToString();
        }

        private void frmIssuance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                dgvRequest.ClearSelection();
            }
        }

        private void btnProceed_Click(object sender, EventArgs e)
        {
            if (dgvRequest.Rows.Count > 0)
            {
                Global.RequestItems = dgvRequest;
                frmScanID frm = new frmScanID();
                frm.ShowDialog();
                if (Global.RequestItems == null)
                {
                    dgvRequest.Rows.Clear();
                    txtSearch.Clear();
                    lblTotalQuantity.Text = "0";
                }
                LoadItems();
            }
            
        }

        private void frmIssuance_Load(object sender, EventArgs e)
        {
            var site = Global.SelectedSite;
            var item = new Item();
            item.SiteCode = site.Code;
            item.GetItems();
            LoadItems();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (dgvRequest.Rows.Count > 0)
            {
                var msg = MessageBox.Show("Are you sure you want to cancel?", "Cancellation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (msg == System.Windows.Forms.DialogResult.Yes)
                {
                    var site = Global.SelectedSite;
                    var item = new Item();
                    item.SiteCode = site.Code;
                    item.GetItems();
                    dgvRequest.Rows.Clear();
                    txtSearch.Clear();
                    lblTotalQuantity.Text = "0";
                    LoadItems();

                }
            }
            
        }

    }
}
