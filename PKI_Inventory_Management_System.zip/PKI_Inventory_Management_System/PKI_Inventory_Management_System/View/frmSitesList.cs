﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmSitesList : Form
    {
        

        public frmSitesList()
        {
            InitializeComponent();
        }

        private void Create(Site area)
        {
            Panel container = new Panel();
            container.Size = new Size(329, 197);
            container.BorderStyle = BorderStyle.FixedSingle;
            container.BackColor = Color.Azure;


            Label description = new Label();
            description.Text = area.Description;
            description.Font = new Font("Arial Rounded MT", 8, FontStyle.Regular);                                                                                              
            description.ForeColor = Color.DimGray;
            description.Height = 40;
            description.AutoSize = false;
            description.Dock = DockStyle.Fill;
            description.TextAlign = ContentAlignment.TopLeft;
            description.Padding = new Padding(5);
            container.Controls.Add(description);

            Label name = new Label();
            name.Text = area.Name;
            name.Font = new Font("Arial Rounded MT", 11, FontStyle.Bold);
            name.BackColor = Color.DimGray;
            name.ForeColor = Color.Gold;
            name.Height = 40;
            name.AutoSize = false;
            name.Dock = DockStyle.Top;
            name.TextAlign = ContentAlignment.MiddleCenter;
            container.Controls.Add(name);

            Label code = new Label();
            code.Text = area.Code;
            code.Font = new Font("Arial Rounded MT", 19, FontStyle.Bold);
            code.ForeColor = Color.DarkSlateGray;
            code.Height = 40;
            code.AutoSize = false;
            code.Dock = DockStyle.Top;
            code.TextAlign = ContentAlignment.MiddleCenter;
            container.Controls.Add(code);

            flpBody.Controls.Add(container);


            code.Click += (sender, e) => SelectedSite(sender, e, area);
            name.Click += (sender, e) => SelectedSite(sender, e, area);
            description.Click += (sender, e) => SelectedSite(sender, e, area);


            //container.MouseEnter += (sender, e) => label_MouseHover(sender, e, container);
            ////name.MouseHover += (sender, e) => label_MouseHover(sender, e, container);
            ////description.MouseHover += (sender, e) => label_MouseHover(sender, e, container);

            //container.MouseLeave += (sender, e) => label_MouseLeave(sender, e, container);
            ////name.MouseLeave += (sender, e) => label_MouseLeave(sender, e, container);
            ////description.MouseLeave += (sender, e) => label_MouseLeave(sender, e, container);


        }


       
        private void SelectedSite(object sender, EventArgs e, Site area)
        {
            Global.SelectedSite = area;
            
            frmIssuance frm = new frmIssuance();
            Global.Container.DisplayForm(frm);
            //MessageBox.Show(Global.SelectedSite.Code);
        }

        private void frmSitesList_Load(object sender, EventArgs e)
        {
            flpBody.Controls.Clear();
           
            foreach (var site in Global.CurrentUserSitesList)
            {
                Create(site);
            }
        }


    }
}
