﻿using PKI_Inventory_Management_System.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmSiteAccessSetting : Form
    {

        private string IdNumber; 
        public frmSiteAccessSetting(string id)
        {
            InitializeComponent();

            if (Global.SelectedSite.UserRole == 3)
            {
                var sites = new Site();
                Global.CurrentUserSitesList = sites.SitesInformation();
                foreach (var site in Global.CurrentUserSitesList)
                {
                    cboSiteCode.Items.Add(site.Code);
                }
            }
            else
            {
                foreach (var site in Global.CurrentUserSitesList)
                {
                    cboSiteCode.Items.Add(site.Code);
                }
            }
            IdNumber = id;
        }

        private void AddedSitesRefresh()
        {
            dgvSites.Rows.Clear();
            var userAccess = new Site();
            userAccess.IDNumber = IdNumber;
            foreach (Site access in userAccess.UsersSiteList())
            {
                dgvSites.Rows.Add(null, access.Code, Global.Roles.Find(x => x.Id.Equals(access.UserRole)).Description);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cboSiteCode_SelectionChangeCommitted(object sender, EventArgs e)
        {
            var selected = Global.CurrentUserSitesList.Find(x => x.Code.Equals(cboSiteCode.Text));
            lblName.Text = selected.Name;
            lblDescription.Text = selected.Description;
            lblSection.Text = selected.Section;
            cboUserType.Items.Clear();
            if (Global.SelectedSite.UserRole == 3)
            {
                foreach (var role in Global.Roles)
                {
                    cboUserType.Items.Add(role.Description);
                }
            }
            else
            {
                if (selected.UserRole == 1)
                {
                    cboUserType.Items.Add(Global.Roles.Find(x => x.Id.Equals(1)).Description); cboUserType.SelectedIndex = 0;
                }
                else
                {
                    foreach (var role in Global.Roles.FindAll(x => x.Id != 3))
                    {
                        cboUserType.Items.Add(role.Description);
                    }
                }
            }
            
        }

        private void frmSiteAccessSetting_Load(object sender, EventArgs e)
        {
            AddedSitesRefresh();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cboSiteCode.Text) && !string.IsNullOrEmpty(cboUserType.Text))
            {
                var site = new Site();
                site.IDNumber = IdNumber;
                site.Code = cboSiteCode.Text;
                site.UserRole = Global.Roles.Find(x => x.Description.Equals(cboUserType.Text)).Id;
                site.AddUserSite();
                AddedSitesRefresh();
            }
            
        }


    }
}
