﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmAddNewItem : Form
    {
        public frmAddNewItem()
        {
            InitializeComponent();

            Global.WaterMark("0", txtCurrentStock);
            Global.TextBoxValidation(txtCurrentStock, "1234567890");

            Global.WaterMark("0", txtLowStockAlert);
            Global.TextBoxValidation(txtLowStockAlert, "1234567890");


            var unitList = new Unit();
            unitList.GetUnits();

            foreach (var unit in Global.UnitsList)
            {
                cboUnit.Items.Add(unit.Description);
            }
        }

        private void frmAddNewItem_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                CloseApplication();
            }
        }

        private void CloseApplication()
        {
            var msg = MessageBox.Show("Are you sure you want to cancel?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (msg == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            CloseApplication();
        }

        private void btnGenerateBarcode_Click(object sender, EventArgs e)
        {
            var barcode = new Item();
            txtBarcode.Text = barcode.GenerateBarcode();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var item = new Item();
            item.SiteCode = Global.SelectedSite.Code;
            item.Barcode = txtBarcode.Text.Trim();
            item.Name = txtItemName.Text;
            item.Description = txtDescription.Text;
            item.Stock = (string.IsNullOrEmpty(txtCurrentStock.Text)) ? 0 : Int32.Parse(txtCurrentStock.Text);
            item.LowStockAlert = (string.IsNullOrEmpty(txtLowStockAlert.Text)) ? 0 : Int32.Parse(txtLowStockAlert.Text);
            var unit = Global.UnitsList.Find(x => x.Description.Equals(cboUnit.Text));
            if (txtBarcode.Text.Trim().Length < 5)
            {
                MessageBox.Show("Invalid barcode. Please enter atleast 5 characters long.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtBarcode.Focus();
                txtBarcode.SelectAll();
            }
            else if (string.IsNullOrEmpty(txtItemName.Text.Trim())) 
            {
                MessageBox.Show("Please enter the item name.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtItemName.Focus();
            }
            else
            {
                if (unit != null)
                {
                    item.Unit = unit.Code;
                    item.AddNewItem();
                    Reset();
                }
                else
                {
                    MessageBox.Show("Invalid unit.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            

        }


        private void Reset()
        {
            txtBarcode.Clear();
            txtItemName.Clear();
            txtDescription.Clear();
            txtCurrentStock.Clear();
            txtLowStockAlert.Clear();
            cboUnit.SelectedIndex = -1;
            txtBarcode.Focus();
        }
    }
}
