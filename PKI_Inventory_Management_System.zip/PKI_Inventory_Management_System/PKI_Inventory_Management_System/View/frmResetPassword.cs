﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmResetPassword : Form
    {
        public frmResetPassword()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            Global.WaterMark("ID Number", txtIDNumber);
            Global.TextBoxValidation(txtIDNumber, "0987654321");
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            if (txtIDNumber.Text.Trim().Length == 6)
            {
                User user = new User();
                user.IDNumber = txtIDNumber.Text;
                if (user.CheckUserExist() == true)
                {
                    this.Hide();
                    frmVerificationCode verify = new frmVerificationCode(user.IDNumber, user.EmailAddress);
                    verify.ShowDialog();
                    this.Close();
                }
                else 
                {
                    MessageBox.Show("Invalid id number.","",MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtIDNumber.Clear();
                    txtIDNumber.Focus();
                }

            }
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
