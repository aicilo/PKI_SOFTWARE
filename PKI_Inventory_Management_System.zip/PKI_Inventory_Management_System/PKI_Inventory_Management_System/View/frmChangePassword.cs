﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmChangePassword : Form
    {
        private string IdNumber;
        public frmChangePassword(string idNumber)
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            Global.WaterMark("New password", txtNewPassword);
            Global.WaterMark("Confirm password", txtConfirmPassword);
            IdNumber = idNumber;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNewPassword.Text) && !string.IsNullOrEmpty(txtConfirmPassword.Text))
            {
                if (txtNewPassword.Text == txtConfirmPassword.Text)
                {
                    var user = new User();
                    user.IDNumber = IdNumber;
                    user.Password = txtNewPassword.Text;
                    if (user.ChangePassword())
                    {
                        MessageBox.Show("Your password has been changed successfully." + Environment.NewLine + "Use your new password to log in.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();                        
                    }
                }
                else 
                {
                    MessageBox.Show("The password confirmation does not match.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtConfirmPassword.Focus();
                    txtConfirmPassword.SelectAll();
                }
            }
            else 
            {
                if (string.IsNullOrEmpty(txtNewPassword.Text))
                {
                    txtNewPassword.Focus();
                    MessageBox.Show("Please enter your new password.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (string.IsNullOrEmpty(txtConfirmPassword.Text))
                {
                    txtConfirmPassword.Focus();
                    MessageBox.Show("Please confirm your password.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                
            }
        }
    }
}
