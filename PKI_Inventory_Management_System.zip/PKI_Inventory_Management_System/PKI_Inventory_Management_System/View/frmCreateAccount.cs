﻿using PKI_Inventory_Management_System.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmCreateAccount : Form
    {
        public frmCreateAccount()
        {
            InitializeComponent();
        }
        private void CloseApplication()
        {
            if (!string.IsNullOrEmpty(txtIDNumber.Text))
            {
                var msg = MessageBox.Show("Are you sure you want to cancel?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (msg == System.Windows.Forms.DialogResult.Yes)
                {
                    this.Close();
                }
            }
            else
            {
                this.Close();

            }
           
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            CloseApplication();
        }

        private void frmCreateAccount_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                CloseApplication();
            }
        }

        private void txtIDNumber_TextChanged(object sender, EventArgs e)
        {
            if (txtIDNumber.Text.Length <= 6)
            {
                var emp = new Employee();
                emp.IDNumber = txtIDNumber.Text;
                emp.GetEmployeeInformation();
                if (!string.IsNullOrEmpty(emp.FullName))
                {
                    lblName.Text = emp.FullName;
                    lblSection.Text = emp.Section;
                    lblStatus.Text = emp.Status;
                    txtEmailAddress.Focus();

                    txtEmailAddress.Text = string.Format("{0}-{1}@pki.lip", emp.FirstName.Substring(0, 1).ToLower().Trim(), emp.LastName.ToLower().Trim());
                    MessageBox.Show("Email is auto generated, please correct if is it wrong.","",MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    lblName.Text = emp.FullName;
                    lblSection.Text = emp.Section;
                    lblStatus.Text = emp.Status;
                    txtEmailAddress.Clear();
                }
               
            }
            


        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            var new_user = new User();
            new_user.IDNumber = txtIDNumber.Text;
            new_user.FullName = lblName.Text;
            new_user.EmailAddress = txtEmailAddress.Text.TrimStart().Trim();
            if (!string.IsNullOrEmpty(new_user.FullName))
            {
                if (!string.IsNullOrEmpty(new_user.EmailAddress) && new_user.EmailAddress.Contains("@pki.lip") && new_user.EmailAddress.Length >= 13)
                {
                    if (new_user.AddUser())
                    {
                        MessageBox.Show("Account has been created successfully.", "Create Account", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid email address", "Create Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                
            }
            else
            {
                MessageBox.Show("Please fill out the required fields.","Create Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }
    }
}
