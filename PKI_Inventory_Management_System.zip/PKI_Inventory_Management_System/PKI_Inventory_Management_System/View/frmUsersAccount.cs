﻿using PKI_Inventory_Management_System.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PKI_Inventory_Management_System.View
{
    public partial class frmUsersAccount : Form
    {
        public frmUsersAccount()
        {
            InitializeComponent();
            Global.WaterMark("Search",txtSearch);
            LoadList();
        }

        private void lnklblCreateAccount_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmCreateAccount frm = new frmCreateAccount();
            frm.ShowDialog();
            LoadList();

        }

      

        List<User> Users = new List<User>();
        private void LoadList()
        {
            dgvUsers.Rows.Clear();
            var users = new User();
            this.Users = users.Users();
            foreach (var user in this.Users)
            {
                dgvUsers.Rows.Add(user.IDNumber, user.FullName, user.EmailAddress, user.DateRegistered.ToString("yyyy-MM-dd"), user.AccessSites);
                dgvUsers.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvUsers.Columns[4].DefaultCellStyle.Font = new Font("Consolas", 12, FontStyle.Bold);
                
            }
            dgvUsers.ClearSelection();
            lblTotal.Text = string.Format("Total: {0}", dgvUsers.Rows.Count);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            var search = Users.FindAll(x => x.FullName.Contains(txtSearch.Text.ToUpper().Trim()) || x.IDNumber.Equals(txtSearch.Text.ToUpper().Trim()));
            if (search != null)
            {
                dgvUsers.Rows.Clear();
                foreach (var user in search)
                {
                    dgvUsers.Rows.Add(user.IDNumber, user.FullName, user.EmailAddress, user.DateRegistered.ToString("yyyy-MM-dd"), user.AccessSites);
                }
            }
            else
            {
                dgvUsers.Rows.Clear();
            }
            dgvUsers.ClearSelection();
            lblTotal.Text = string.Format("Total: {0}", dgvUsers.Rows.Count);

        }

        private void dgvUsers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == 4)
            {
                frmSiteAccessSetting frm = new frmSiteAccessSetting(dgvUsers.Rows[e.RowIndex].Cells[0].Value.ToString());
                frm.ShowDialog();
                LoadList();
            }
        }
    }
}
