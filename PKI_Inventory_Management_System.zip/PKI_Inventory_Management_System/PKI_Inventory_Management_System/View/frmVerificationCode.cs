﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PKI_Inventory_Management_System.Model;
namespace PKI_Inventory_Management_System.View
{
    public partial class frmVerificationCode : Form
    {
        private string IdNumber;
        public frmVerificationCode(string idNumber, string email_address)
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            var email = new Mail();
            email.RequestVerificationCode(idNumber ,email_address);

            Global.WaterMark("######", txtCode);
            Global.TextBoxValidation(txtCode, "0987654321");
            IdNumber = idNumber;

            lblMessage.Text = string.Format("Please enter the verification code that was sent to {0}.",email_address);
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            var verification = new Mail();
            if (verification.CorrectVerificationCode(IdNumber, txtCode.Text))
            {
                this.Hide();
                frmChangePassword changePassword = new frmChangePassword(IdNumber);
                changePassword.ShowDialog();
                this.Close();

                
            }
            else
            {
                MessageBox.Show("Incorrect verification code.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtCode.Clear();
                txtCode.Focus();
            }
           
        }

        private void frmVerificationCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }


    }
}
